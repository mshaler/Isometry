
  # Dynamic Pivot Table Design

  This is a code bundle for Dynamic Pivot Table Design. The original project is available at https://www.figma.com/design/26IGYEk7p8XMHw6VCKabyW/Dynamic-Pivot-Table-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  