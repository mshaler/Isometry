import { HeaderDimension, DataCell } from '../types/pivot';

export const allDimensions: HeaderDimension[] = [
  {
    id: 'folder',
    type: 'folder',
    name: 'Folders',
    values: ['Documents', 'Photos', 'Projects']
  },
  {
    id: 'subfolder',
    type: 'subfolder',
    name: 'Subfolders',
    values: ['Work', 'Personal', 'Archive', 'Backup']
  },
  {
    id: 'tag',
    type: 'tag',
    name: 'Tags',
    values: ['Important', 'Draft', 'Final', 'Review']
  },
  {
    id: 'year',
    type: 'year',
    name: 'Years',
    values: ['2023', '2024', '2025']
  },
  {
    id: 'month',
    type: 'month',
    name: 'Months',
    values: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
  },
  {
    id: 'day',
    type: 'day',
    name: 'Days',
    values: Array.from({ length: 31 }, (_, i) => `${i + 1}`)
  }
];

// Generate mock data with some randomness and some empty cells
export function generateMockData(
  rowDimensions: HeaderDimension[],
  colDimensions: HeaderDimension[]
): Map<string, number | null> {
  const data = new Map<string, number | null>();

  function generateCombinations(dimensions: HeaderDimension[], index: number, current: string[]): string[][] {
    if (index >= dimensions.length) {
      return [current];
    }

    const results: string[][] = [];
    for (const value of dimensions[index].values) {
      results.push(...generateCombinations(dimensions, index + 1, [...current, value]));
    }
    return results;
  }

  const rowCombinations = generateCombinations(rowDimensions, 0, []);
  const colCombinations = generateCombinations(colDimensions, 0, []);

  for (const rowPath of rowCombinations) {
    for (const colPath of colCombinations) {
      const key = `${rowPath.join('|')}::${colPath.join('|')}`;
      // 30% chance of empty cell, otherwise random value between 1-100
      const isEmpty = Math.random() < 0.3;
      data.set(key, isEmpty ? null : Math.floor(Math.random() * 100) + 1);
    }
  }

  return data;
}

export function getCellKey(rowPath: string[], colPath: string[]): string {
  return `${rowPath.join('|')}::${colPath.join('|')}`;
}
