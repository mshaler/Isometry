import { PivotTable } from './components/PivotTable';

export default function App() {
  return (
    <div className="size-full">
      <PivotTable />
    </div>
  );
}