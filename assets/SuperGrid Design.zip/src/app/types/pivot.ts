export type HeaderType = 'folder' | 'subfolder' | 'tag' | 'year' | 'month' | 'day';

export interface Header {
  id: string;
  type: HeaderType;
  label: string;
}

export interface HeaderDimension {
  id: string;
  type: HeaderType;
  name: string;
  values: string[];
}

export interface DataCell {
  rowPath: string[];
  colPath: string[];
  value: number | null;
}

export interface SpanInfo {
  span: number;
  label: string;
}

export interface CellSize {
  width: number;
  height: number;
}
