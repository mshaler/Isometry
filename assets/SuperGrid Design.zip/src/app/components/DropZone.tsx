import { useDrop } from 'react-dnd';
import { HeaderDimension } from '../types/pivot';

interface DropZoneProps {
  area: 'row' | 'column';
  onDrop: (dimension: HeaderDimension, sourceArea: 'row' | 'column') => void;
  children: React.ReactNode;
  className?: string;
}

export function DropZone({ area, onDrop, children, className = '' }: DropZoneProps) {
  const [{ isOver, canDrop }, drop] = useDrop({
    accept: 'HEADER',
    drop: (item: { dimension: HeaderDimension; sourceArea: 'row' | 'column' }) => {
      onDrop(item.dimension, item.sourceArea);
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
      canDrop: monitor.canDrop(),
    }),
  });

  return (
    <div
      ref={drop}
      className={`
        p-3 rounded-lg border-2 border-dashed transition-colors
        ${isOver && canDrop ? 'border-blue-500 bg-blue-50' : 'border-gray-300 bg-white'}
        ${className}
      `}
    >
      {children}
    </div>
  );
}