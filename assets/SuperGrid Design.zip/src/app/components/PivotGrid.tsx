import { useState, useRef, useEffect } from 'react';
import { HeaderDimension } from '../types/pivot';
import { getCellKey } from '../utils/mockData';

interface PivotGridProps {
  rowDimensions: HeaderDimension[];
  colDimensions: HeaderDimension[];
  data: Map<string, number | null>;
  hideEmptyRows: boolean;
  hideEmptyCols: boolean;
}

interface SpanInfo {
  span: number;
  label: string;
}

export function PivotGrid({
  rowDimensions,
  colDimensions,
  data,
  hideEmptyRows,
  hideEmptyCols,
}: PivotGridProps) {
  const [headerWidth, setHeaderWidth] = useState(120);
  const [headerHeight, setHeaderHeight] = useState(32);
  const [cellWidth, setCellWidth] = useState(100);
  const [cellHeight, setCellHeight] = useState(32);
  const [scrollLeft, setScrollLeft] = useState(0);
  const [scrollTop, setScrollTop] = useState(0);
  
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  
  const [resizing, setResizing] = useState<{
    type: 'header-width' | 'header-height' | 'cell-all';
    startX: number;
    startY: number;
    startWidth: number;
    startHeight: number;
  } | null>(null);

  // Generate all combinations
  function generateCombinations(dimensions: HeaderDimension[], index: number, current: string[]): string[][] {
    if (index >= dimensions.length) {
      return [current];
    }
    const results: string[][] = [];
    for (const value of dimensions[index].values) {
      results.push(...generateCombinations(dimensions, index + 1, [...current, value]));
    }
    return results;
  }

  const rowCombinations = rowDimensions.length > 0 ? generateCombinations(rowDimensions, 0, []) : [[]];
  const colCombinations = colDimensions.length > 0 ? generateCombinations(colDimensions, 0, []) : [[]];

  // Filter empty rows/columns
  const visibleRows = rowCombinations.filter(rowPath => {
    if (!hideEmptyRows) return true;
    return colCombinations.some(colPath => {
      const key = getCellKey(rowPath, colPath);
      const value = data.get(key);
      return value !== null && value !== undefined;
    });
  });

  const visibleCols = colCombinations.filter(colPath => {
    if (!hideEmptyCols) return true;
    return visibleRows.some(rowPath => {
      const key = getCellKey(rowPath, colPath);
      const value = data.get(key);
      return value !== null && value !== undefined;
    });
  });

  // Calculate spans for headers
  function calculateSpans(dimensions: HeaderDimension[], combinations: string[][]): SpanInfo[][] {
    const spans: SpanInfo[][] = [];
    
    for (let dimIdx = 0; dimIdx < dimensions.length; dimIdx++) {
      const spanRow: SpanInfo[] = [];
      let i = 0;
      
      while (i < combinations.length) {
        const currentValue = combinations[i][dimIdx];
        let span = 1;
        
        // Count consecutive same values where all previous dimensions match
        while (
          i + span < combinations.length &&
          combinations[i + span][dimIdx] === currentValue
        ) {
          // Check if all previous dimensions still match
          let prevMatch = true;
          for (let prevDim = 0; prevDim < dimIdx; prevDim++) {
            if (combinations[i + span][prevDim] !== combinations[i][prevDim]) {
              prevMatch = false;
              break;
            }
          }
          if (!prevMatch) break;
          span++;
        }
        
        spanRow.push({ span, label: currentValue });
        i += span;
      }
      
      spans.push(spanRow);
    }
    
    return spans;
  }

  const rowSpans = rowDimensions.length > 0 ? calculateSpans(rowDimensions, visibleRows) : [];
  const colSpans = colDimensions.length > 0 ? calculateSpans(colDimensions, visibleCols) : [];

  // Handle scroll
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.currentTarget;
    setScrollLeft(target.scrollLeft);
    setScrollTop(target.scrollTop);
  };

  // Mouse event handlers for resizing
  useEffect(() => {
    if (!resizing) return;

    const handleMouseMove = (e: MouseEvent) => {
      if (!resizing) return;

      if (resizing.type === 'header-width') {
        const delta = e.clientX - resizing.startX;
        setHeaderWidth(Math.max(60, resizing.startWidth + delta));
      } else if (resizing.type === 'header-height') {
        const delta = e.clientY - resizing.startY;
        setHeaderHeight(Math.max(24, resizing.startHeight + delta));
      } else if (resizing.type === 'cell-all') {
        const deltaX = e.clientX - resizing.startX;
        const deltaY = e.clientY - resizing.startY;
        setCellWidth(Math.max(40, resizing.startWidth + deltaX));
        setCellHeight(Math.max(24, resizing.startHeight + deltaY));
      }
    };

    const handleMouseUp = () => {
      setResizing(null);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [resizing]);

  if (rowDimensions.length === 0 || colDimensions.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-400 text-sm">
        Add dimensions to both rows and columns to see data
      </div>
    );
  }

  const totalRowHeaderWidth = headerWidth * rowDimensions.length;
  const totalColHeaderHeight = headerHeight * colDimensions.length;

  return (
    <div className="relative w-full h-full overflow-hidden">
      {/* LAYER 1: Lower layer - Simple scrollable spreadsheet */}
      <div
        ref={scrollContainerRef}
        onScroll={handleScroll}
        className="absolute inset-0 overflow-auto"
        style={{ zIndex: 1 }}
      >
        <table className="border-collapse" style={{ tableLayout: 'fixed' }}>
          <thead>
            {/* Simple ungrouped column headers (one row per dimension) */}
            {colDimensions.map((dim, dimIdx) => (
              <tr key={`simple-col-${dimIdx}`}>
                {/* Empty corner cells */}
                {rowDimensions.map((_, rowDimIdx) => (
                  <th
                    key={`corner-${dimIdx}-${rowDimIdx}`}
                    className="border border-gray-300 bg-gray-200"
                    style={{ width: headerWidth, height: headerHeight, minWidth: headerWidth, maxWidth: headerWidth }}
                  />
                ))}
                {/* Simple column header cells (one per combination) */}
                {visibleCols.map((colPath, colIdx) => (
                  <th
                    key={`simple-col-header-${dimIdx}-${colIdx}`}
                    className="border border-gray-300 bg-gray-100 px-2 py-1 text-sm whitespace-nowrap"
                    style={{ width: cellWidth, height: headerHeight, minWidth: cellWidth, maxWidth: cellWidth }}
                  >
                    {colPath[dimIdx]}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {visibleRows.map((rowPath, rowIdx) => (
              <tr key={`row-${rowIdx}`}>
                {/* Simple ungrouped row headers (one cell per dimension) */}
                {rowDimensions.map((dim, dimIdx) => (
                  <th
                    key={`simple-row-header-${rowIdx}-${dimIdx}`}
                    className="border border-gray-300 bg-gray-50 px-2 py-1 text-sm text-left whitespace-nowrap"
                    style={{ width: headerWidth, height: cellHeight, minWidth: headerWidth, maxWidth: headerWidth }}
                  >
                    {rowPath[dimIdx]}
                  </th>
                ))}
                {/* Data cells */}
                {visibleCols.map((colPath, colIdx) => {
                  const key = getCellKey(rowPath, colPath);
                  const value = data.get(key);
                  
                  return (
                    <td
                      key={`cell-${rowIdx}-${colIdx}`}
                      className="border border-gray-300 px-2 py-1 text-sm text-right hover:bg-gray-50"
                      style={{ width: cellWidth, height: cellHeight, minWidth: cellWidth, maxWidth: cellWidth }}
                    >
                      {value !== null && value !== undefined ? value : ''}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* LAYER 2: Upper layer - Floating grouped headers with spanning */}
      <div className="absolute top-0 left-0 pointer-events-none" style={{ zIndex: 10 }}>
        {/* Grouped column headers */}
        {colDimensions.map((dim, dimIdx) => {
          let cumulativeOffset = 0;
          return colSpans[dimIdx]?.map((spanInfo, spanIdx) => {
            const element = (
              <div
                key={`grouped-col-${dimIdx}-${spanIdx}`}
                className="absolute bg-gray-100 border border-gray-300 px-2 py-1 text-sm whitespace-nowrap font-medium flex items-center justify-center pointer-events-auto"
                style={{
                  left: totalRowHeaderWidth + (cumulativeOffset * cellWidth),
                  top: dimIdx * headerHeight,
                  width: cellWidth * spanInfo.span,
                  height: headerHeight,
                  zIndex: 11,
                  boxSizing: 'border-box',
                  transform: `translateX(-${scrollLeft}px)`,
                }}
              >
                {spanInfo.label}
              </div>
            );
            cumulativeOffset += spanInfo.span;
            return element;
          });
        })}

        {/* Grouped row headers */}
        {rowDimensions.map((dim, dimIdx) => {
          let cumulativeOffset = 0;
          return rowSpans[dimIdx]?.map((spanInfo, spanIdx) => {
            const element = (
              <div
                key={`grouped-row-${dimIdx}-${spanIdx}`}
                className="absolute bg-gray-100 border border-gray-300 px-2 py-1 text-sm text-left whitespace-nowrap font-medium flex items-center pointer-events-auto"
                style={{
                  left: dimIdx * headerWidth,
                  top: totalColHeaderHeight + (cumulativeOffset * cellHeight),
                  width: headerWidth,
                  height: cellHeight * spanInfo.span,
                  zIndex: 12,
                  boxSizing: 'border-box',
                  transform: `translateY(-${scrollTop}px)`,
                }}
              >
                {spanInfo.label}
              </div>
            );
            cumulativeOffset += spanInfo.span;
            return element;
          });
        })}

        {/* Empty Quarter - Top-left corner with dimension labels (HIGHEST Z-INDEX) */}
        <div
          className="absolute top-0 left-0 bg-gray-200 border border-gray-300 flex items-start justify-start p-2 pointer-events-auto"
          style={{
            width: totalRowHeaderWidth,
            height: totalColHeaderHeight,
            zIndex: 30,
            boxSizing: 'border-box',
          }}
        >
          <div className="text-xs text-gray-500">
            {rowDimensions.map(d => d.name).join(' / ')}
            <br />
            vs
            <br />
            {colDimensions.map(d => d.name).join(' / ')}
          </div>
          {/* Resize handle for header width */}
          <div
            className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize hover:bg-blue-400 transition-colors pointer-events-auto"
            onMouseDown={(e) => {
              e.preventDefault();
              setResizing({
                type: 'header-width',
                startX: e.clientX,
                startY: e.clientY,
                startWidth: headerWidth,
                startHeight: headerHeight,
              });
            }}
          />
          {/* Resize handle for header height */}
          <div
            className="absolute bottom-0 left-0 right-0 h-1 cursor-row-resize hover:bg-blue-400 transition-colors pointer-events-auto"
            onMouseDown={(e) => {
              e.preventDefault();
              setResizing({
                type: 'header-height',
                startX: e.clientX,
                startY: e.clientY,
                startWidth: headerWidth,
                startHeight: headerHeight,
              });
            }}
          />
        </div>

        {/* Resize handle for all data cells (bottom-right corner) */}
        <div
          className="absolute w-3 h-3 cursor-nwse-resize hover:bg-blue-400 border-l border-t border-gray-400 bg-white pointer-events-auto"
          style={{
            left: totalRowHeaderWidth + (visibleCols.length * cellWidth) - scrollLeft - 3,
            top: totalColHeaderHeight + (visibleRows.length * cellHeight) - scrollTop - 3,
          }}
          onMouseDown={(e) => {
            e.preventDefault();
            setResizing({
              type: 'cell-all',
              startX: e.clientX,
              startY: e.clientY,
              startWidth: cellWidth,
              startHeight: cellHeight,
            });
          }}
        />
      </div>
    </div>
  );
}