import { useState, useMemo } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { HeaderDimension } from '../types/pivot';
import { allDimensions, generateMockData } from '../utils/mockData';
import { DraggableHeader } from './DraggableHeader';
import { DropZone } from './DropZone';
import { PivotGrid } from './PivotGrid';
import { ArrowLeftRight, Eye, EyeOff } from 'lucide-react';
import { Button } from './ui/button';

export function PivotTable() {
  // Initial configuration
  const [rowDimensions, setRowDimensions] = useState<HeaderDimension[]>([
    allDimensions.find(d => d.type === 'folder')!,
    allDimensions.find(d => d.type === 'subfolder')!,
    allDimensions.find(d => d.type === 'tag')!,
  ]);

  const [colDimensions, setColDimensions] = useState<HeaderDimension[]>([
    allDimensions.find(d => d.type === 'year')!,
    allDimensions.find(d => d.type === 'month')!,
    allDimensions.find(d => d.type === 'day')!,
  ]);

  const [hideEmptyRows, setHideEmptyRows] = useState(false);
  const [hideEmptyCols, setHideEmptyCols] = useState(false);

  // Generate data based on current dimensions
  const data = useMemo(() => {
    return generateMockData(rowDimensions, colDimensions);
  }, [rowDimensions, colDimensions]);

  // Available dimensions (not currently in use)
  const availableDimensions = allDimensions.filter(
    d => !rowDimensions.some(rd => rd.id === d.id) && !colDimensions.some(cd => cd.id === d.id)
  );

  const handleDropToRow = (dimension: HeaderDimension, sourceArea: 'row' | 'column') => {
    if (sourceArea === 'column') {
      setColDimensions(prev => prev.filter(d => d.id !== dimension.id));
      setRowDimensions(prev => [...prev, dimension]);
    } else {
      // Reordering within rows - handled by removing and re-adding
      setRowDimensions(prev => {
        const filtered = prev.filter(d => d.id !== dimension.id);
        return [...filtered, dimension];
      });
    }
  };

  const handleDropToColumn = (dimension: HeaderDimension, sourceArea: 'row' | 'column') => {
    if (sourceArea === 'row') {
      setRowDimensions(prev => prev.filter(d => d.id !== dimension.id));
      setColDimensions(prev => [...prev, dimension]);
    } else {
      // Reordering within columns
      setColDimensions(prev => {
        const filtered = prev.filter(d => d.id !== dimension.id);
        return [...filtered, dimension];
      });
    }
  };

  const handleRemoveFromRow = (dimensionId: string) => {
    setRowDimensions(prev => prev.filter(d => d.id !== dimensionId));
  };

  const handleRemoveFromColumn = (dimensionId: string) => {
    setColDimensions(prev => prev.filter(d => d.id !== dimensionId));
  };

  const handleTranspose = () => {
    const temp = rowDimensions;
    setRowDimensions(colDimensions);
    setColDimensions(temp);
  };

  const handleDropToAvailable = (dimension: HeaderDimension, sourceArea: 'row' | 'column') => {
    if (sourceArea === 'row') {
      setRowDimensions(prev => prev.filter(d => d.id !== dimension.id));
    } else {
      setColDimensions(prev => prev.filter(d => d.id !== dimension.id));
    }
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="h-screen flex flex-col bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <h1 className="text-2xl font-bold text-gray-900">SuperGrid</h1>
        </div>

        {/* Configuration Panel - Vertical Axes Drop Zones */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="grid grid-cols-4 gap-4 mb-4">
            {/* Available Dimensions */}
            <div>
              <label className="text-sm font-semibold text-gray-700 mb-2 block">
                Available
              </label>
              <DropZone area="row" onDrop={handleDropToAvailable} className="h-[200px]">
                <div className="flex flex-col gap-2 h-full overflow-y-auto">
                  {availableDimensions.length === 0 ? (
                    <div className="text-sm text-gray-400 italic">Drop here to remove</div>
                  ) : (
                    availableDimensions.map(dim => (
                      <DraggableHeader
                        key={dim.id}
                        dimension={dim}
                        area="row"
                        onRemove={() => {}}
                        fullWidth
                      />
                    ))
                  )}
                </div>
              </DropZone>
            </div>

            {/* Row Dimensions */}
            <div>
              <label className="text-sm font-semibold text-gray-700 mb-2 block">
                Rows
              </label>
              <DropZone area="row" onDrop={handleDropToRow} className="h-[200px]">
                <div className="flex flex-col gap-2 h-full overflow-y-auto">
                  {rowDimensions.length === 0 ? (
                    <div className="text-sm text-gray-400 italic">Drop dimensions here</div>
                  ) : (
                    rowDimensions.map(dim => (
                      <DraggableHeader
                        key={dim.id}
                        dimension={dim}
                        area="row"
                        onRemove={() => handleRemoveFromRow(dim.id)}
                        fullWidth
                      />
                    ))
                  )}
                </div>
              </DropZone>
            </div>

            {/* Column Dimensions */}
            <div>
              <label className="text-sm font-semibold text-gray-700 mb-2 block">
                Columns
              </label>
              <DropZone area="column" onDrop={handleDropToColumn} className="h-[200px]">
                <div className="flex flex-col gap-2 h-full overflow-y-auto">
                  {colDimensions.length === 0 ? (
                    <div className="text-sm text-gray-400 italic">Drop dimensions here</div>
                  ) : (
                    colDimensions.map(dim => (
                      <DraggableHeader
                        key={dim.id}
                        dimension={dim}
                        area="column"
                        onRemove={() => handleRemoveFromColumn(dim.id)}
                        fullWidth
                      />
                    ))
                  )}
                </div>
              </DropZone>
            </div>

            {/* Z Dimension (placeholder for future use) */}
            <div>
              <label className="text-sm font-semibold text-gray-700 mb-2 block">
                Z
              </label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-3 h-[200px] bg-gray-50 flex items-start">
                <div className="text-sm text-gray-400 italic">Future feature</div>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex gap-4 pt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleTranspose}
              className="gap-2"
            >
              <ArrowLeftRight className="w-4 h-4" />
              Transpose
            </Button>
            <Button
              variant={hideEmptyRows ? 'default' : 'outline'}
              size="sm"
              onClick={() => setHideEmptyRows(!hideEmptyRows)}
              className="gap-2"
            >
              {hideEmptyRows ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {hideEmptyRows ? 'Show' : 'Hide'} Empty Rows
            </Button>
            <Button
              variant={hideEmptyCols ? 'default' : 'outline'}
              size="sm"
              onClick={() => setHideEmptyCols(!hideEmptyCols)}
              className="gap-2"
            >
              {hideEmptyCols ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {hideEmptyCols ? 'Show' : 'Hide'} Empty Columns
            </Button>
          </div>
        </div>

        {/* Grid */}
        <div className="flex-1 p-6 overflow-auto">
          <PivotGrid
            rowDimensions={rowDimensions}
            colDimensions={colDimensions}
            data={data}
            hideEmptyRows={hideEmptyRows}
            hideEmptyCols={hideEmptyCols}
          />
        </div>
      </div>
    </DndProvider>
  );
}