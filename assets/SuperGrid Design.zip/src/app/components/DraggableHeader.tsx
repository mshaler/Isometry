import { useDrag } from 'react-dnd';
import { HeaderDimension } from '../types/pivot';
import { GripVertical } from 'lucide-react';

interface DraggableHeaderProps {
  dimension: HeaderDimension;
  area: 'row' | 'column';
  onRemove: () => void;
  fullWidth?: boolean;
}

export function DraggableHeader({ dimension, area, onRemove, fullWidth = false }: DraggableHeaderProps) {
  const [{ isDragging }, drag] = useDrag({
    type: 'HEADER',
    item: { dimension, sourceArea: area },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  return (
    <div
      ref={drag}
      className={`
        flex items-center gap-2 px-3 py-2 rounded-md
        bg-gray-100 border border-gray-300
        cursor-move hover:bg-gray-200 transition-colors
        ${isDragging ? 'opacity-50' : 'opacity-100'}
        ${fullWidth ? 'w-full' : ''}
      `}
    >
      <GripVertical className="w-4 h-4 text-gray-500" />
      <span className="flex-1 text-sm">{dimension.name}</span>
      <button
        onClick={(e) => {
          e.stopPropagation();
          onRemove();
        }}
        className="text-gray-400 hover:text-gray-600 text-lg leading-none"
      >
        ×
      </button>
    </div>
  );
}