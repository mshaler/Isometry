# Isometry ETL Module

Direct data ingestion from platform sources to Isometry's canonical format.

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                          Source Adapters                             │
│                                                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌─────────┐ │
│  │ Apple Notes  │  │ Apple        │  │ Apple        │  │ Slack   │ │
│  │              │  │ Reminders    │  │ Calendar     │  │         │ │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └────┬────┘ │
│         │                 │                 │                │      │
│         └─────────────────┴────────┬────────┴────────────────┘      │
│                                    │                                 │
│                                    ▼                                 │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                 Canonical Format                              │   │
│  │  CanonicalNode { id, source, name, content, LATCH props }    │   │
│  │  CanonicalEdge { id, type, source→target, weight }           │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                    │                                 │
│                                    ▼                                 │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                   Isometry SQLite                             │   │
│  │  nodes, edges, nodes_fts (via NodeWriter)                     │   │
│  └─────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

## Quick Start

```bash
# Install dependencies
npm install

# Build
npm run build

# Run diagnostics
./scripts/diagnose-notes-folder.sh
./scripts/diagnose-reminders.sh
./scripts/diagnose-calendar.sh
./scripts/diagnose-slack.sh

# Test individual adapters
npm run apple-notes
npm run apple-reminders
npm run apple-calendar
npm run slack
```

## Adapters

### 1. Apple Notes

Direct SQLite access to `NoteStore.sqlite`. See [Apple Notes diagnostic](#apple-notes-diagnostic) for schema details.

```typescript
import { createAppleNotesAdapter } from '@isometry/etl';

const adapter = createAppleNotesAdapter();
const result = await adapter.fullSync();
```

**LATCH Mapping:**
| Axis | Source |
|------|--------|
| L | Not used |
| A | ZTITLE1 (note title) |
| T | ZCREATIONDATE, ZMODIFICATIONDATE |
| C | Folder hierarchy, inline #tags |
| H | Manual sort order |

### 2. Apple Reminders

Direct SQLite access to Reminders store. Supports subtasks and priorities.

```typescript
import { createAppleRemindersAdapter } from '@isometry/etl';

const adapter = createAppleRemindersAdapter();
const result = await adapter.fullSync();
```

**LATCH Mapping:**
| Axis | Source |
|------|--------|
| L | Not used |
| A | ZTITLE (reminder title) |
| T | Created, modified, due, completed |
| C | List hierarchy, flagged status |
| H | Priority (High/Medium/Low → 5/3/1) |

**Features:**
- Subtask support (parent-child relationships)
- Priority mapping (Apple's 1/5/9 → Isometry's 0-5)
- Multiple accounts/stores

### 3. Apple Calendar

Direct SQLite access to Calendar Cache. **First adapter with Location data!**

```typescript
import { createAppleCalendarAdapter } from '@isometry/etl';

const adapter = createAppleCalendarAdapter({ dateRangeMonths: 6 });
const result = await adapter.fullSync();

// Or sync specific date range
const events = await adapter.syncDateRange(startDate, endDate);
```

**LATCH Mapping:**
| Axis | Source |
|------|--------|
| L | Event location (name, address, lat/lng) ✓ |
| A | ZTITLE (event title) |
| T | Created, modified, eventStart, eventEnd |
| C | Calendar name |
| H | Not used |

**Features:**
- Location extraction with coordinates
- Attendee relationships (LINK edges)
- Date range filtering
- Recurring event detection

### 4. Slack

Hybrid adapter: SQLite cache first, MCP fallback.

```typescript
import { createSlackAdapter } from '@isometry/etl';

const adapter = createSlackAdapter({
  maxMessagesPerChannel: 1000,
  maxAgeDays: 90,
  preferMcp: false,  // Try SQLite first
});

console.log(`Data source: ${adapter.getDataSource()}`); // 'sqlite' | 'mcp' | 'none'
const result = await adapter.fullSync();
```

**LATCH Mapping:**
| Axis | Source |
|------|--------|
| L | Not used |
| A | Message text (first line) |
| T | Message timestamp |
| C | Workspace → Channel hierarchy |
| H | Not used |

**Features:**
- Local SQLite cache (no API rate limits)
- Thread relationships (SEQUENCE edges)
- @mention extraction (LINK edges)
- MCP fallback for complete data

## Diagnostic Scripts

Each adapter has a diagnostic script to validate database access:

```bash
# Apple Notes - validates folder hierarchy
./scripts/diagnose-notes-folder.sh

# Apple Reminders - shows lists and task counts
./scripts/diagnose-reminders.sh

# Apple Calendar - shows calendars and events with locations
./scripts/diagnose-calendar.sh

# Slack - probes local cache availability
./scripts/diagnose-slack.sh
```

## LATCH Property Mapping

Every source maps to the same five organizing principles:

| Axis | Meaning | Example Sources |
|------|---------|-----------------|
| **L** | Location | Calendar events, Check-ins |
| **A** | Alphabet | Titles, names |
| **T** | Time | Created, modified, due, event times |
| **C** | Category | Folders, lists, channels, tags |
| **H** | Hierarchy | Priority, importance, sort order |

## Edge Types

Relationships between nodes use GRAPH vocabulary:

| Type | Meaning | Example |
|------|---------|---------|
| **NEST** | Containment | Folder → Note, List → Reminder |
| **LINK** | Reference | Event → Attendee, Message → @mention |
| **SEQUENCE** | Ordered | Thread parent → Reply |
| **AFFINITY** | Computed | Similar content (future) |

## Development

```bash
# Run tests
npm test

# Type check
npm run typecheck

# Build
npm run build
```

## Roadmap

### Phase 1: Apple Ecosystem ✓
- [x] Apple Notes
- [x] Apple Reminders  
- [x] Apple Calendar
- [ ] Apple Contacts (requires Swift)

### Phase 2: Communication
- [x] Slack (SQLite + MCP)
- [ ] Apple Mail (SIP protected)
- [ ] Apple Messages (SIP protected)

### Phase 3: Cross-Platform
- [ ] Obsidian (local vault)
- [ ] Notion (API)
- [ ] Todoist (API)

## License

MIT
