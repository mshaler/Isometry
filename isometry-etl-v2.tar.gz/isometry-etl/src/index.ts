/**
 * Isometry ETL Module
 * 
 * Unified data ingestion from multiple sources into Isometry's
 * canonical format (PAFV + LATCH + GRAPH).
 * 
 * @example
 * ```typescript
 * import { createAppleNotesAdapter, NodeWriter } from '@isometry/etl';
 * 
 * // Create adapter for source
 * const notes = createAppleNotesAdapter();
 * 
 * // Sync to canonical format
 * const result = await notes.fullSync();
 * 
 * // Write to Isometry database
 * const writer = new NodeWriter(isometryDb);
 * await writer.upsertNodes(result.nodes);
 * await writer.upsertEdges(result.edges);
 * ```
 */

// Core types
export type {
  CanonicalNode,
  CanonicalEdge,
  SourceAdapter,
  SyncState,
  SyncResult,
  SourceType,
  NodeType,
  EdgeType,
  LatchLocation,
  LatchTime,
  LatchCategory,
  LatchHierarchy,
  ParsedContent,
  AttachmentMeta,
} from './core/types.js';

// =============================================================================
// Apple Notes Adapter
// =============================================================================
export {
  AppleNotesAdapter,
  createAppleNotesAdapter,
  extractNoteContent,
  getNoteStorePath,
} from './adapters/apple-notes/index.js';

// =============================================================================
// Apple Reminders Adapter
// =============================================================================
export {
  AppleRemindersAdapter,
  createAppleRemindersAdapter,
  getRemindersStorePaths,
  getPrimaryRemindersPath,
  mapPriority,
} from './adapters/apple-reminders/index.js';

// =============================================================================
// Apple Calendar Adapter
// =============================================================================
export {
  AppleCalendarAdapter,
  createAppleCalendarAdapter,
  getCalendarCachePath,
  isCalendarAvailable,
} from './adapters/apple-calendar/index.js';

// =============================================================================
// Slack Adapter (SQLite + MCP hybrid)
// =============================================================================
export {
  SlackAdapter,
  createSlackAdapter,
  getSlackDbPaths,
  isSlackCacheAvailable,
  type SlackAdapterOptions,
  type SlackDataSource,
} from './adapters/slack/index.js';

// =============================================================================
// Future Adapters
// =============================================================================
// export { ObsidianAdapter } from './adapters/obsidian/index.js';
// export { NotionAdapter } from './adapters/notion/index.js';
// export { TodoistAdapter } from './adapters/todoist/index.js';
