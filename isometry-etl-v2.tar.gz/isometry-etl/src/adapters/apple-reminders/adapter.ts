/**
 * Apple Reminders Source Adapter
 * 
 * Direct SQLite access to Reminders database for ETL to Isometry.
 * 
 * Features:
 * - Full sync: Import all reminders with list hierarchy
 * - Incremental sync: Only reminders modified since last watermark
 * - Subtask support: Parent-child relationships as NEST edges
 * - Priority mapping: Apple's 1/5/9 → Isometry's 0-5 scale
 * 
 * LATCH Mapping:
 * - L: Not used (reminders don't have location in basic schema)
 * - A: Reminder title
 * - T: Created, modified, due, completed dates
 * - C: List hierarchy, flagged status
 * - H: Priority (High/Medium/Low), sort order
 */

import Database from 'better-sqlite3';
import { existsSync } from 'fs';

import {
  SourceAdapter,
  SyncState,
  SyncResult,
  CanonicalNode,
  CanonicalEdge,
  SourceType,
} from '../../core/types.js';

import {
  getPrimaryRemindersPath,
  getRemindersStorePaths,
  dateToCoreDataTimestamp,
  QUERY_ALL_REMINDERS,
  QUERY_REMINDERS_SINCE,
  QUERY_ALL_LISTS,
  QUERY_REMINDER_COUNT,
  QUERY_DELETED_REMINDERS,
  RawReminderRow,
  RawListRow,
  extractLatchTime,
  extractLatchCategory,
  extractLatchHierarchy,
  generateReminderUrl,
} from './schema.js';

// =============================================================================
// Adapter Implementation
// =============================================================================

export class AppleRemindersAdapter implements SourceAdapter {
  readonly sourceType: SourceType = 'apple-reminders';
  readonly displayName = 'Apple Reminders';
  
  private dbPaths: string[];
  private syncState: SyncState;
  
  constructor(dbPaths?: string[]) {
    this.dbPaths = dbPaths || getRemindersStorePaths();
    this.syncState = { itemCount: 0 };
  }
  
  // ===========================================================================
  // SourceAdapter Interface
  // ===========================================================================
  
  async isAvailable(): Promise<boolean> {
    return this.dbPaths.length > 0 && this.dbPaths.some(p => existsSync(p));
  }
  
  async fullSync(): Promise<SyncResult> {
    const allNodes: CanonicalNode[] = [];
    const allEdges: CanonicalEdge[] = [];
    const listNodes = new Map<string, CanonicalNode>();
    let totalCount = 0;
    
    // Process each store (one per account)
    for (const dbPath of this.dbPaths) {
      if (!existsSync(dbPath)) continue;
      
      const db = new Database(dbPath, { readonly: true, fileMustExist: true });
      
      try {
        // Get all lists first (for folder structure)
        const lists = db.prepare(QUERY_ALL_LISTS).all() as RawListRow[];
        for (const list of lists) {
          const listNode = this.listToCanonicalNode(list);
          listNodes.set(listNode.id, listNode);
        }
        
        // Get all reminders
        const rows = db.prepare(QUERY_ALL_REMINDERS).all() as RawReminderRow[];
        
        for (const row of rows) {
          const node = this.rowToCanonicalNode(row);
          allNodes.push(node);
          
          // Create NEST edge from list to reminder
          if (row.list_name) {
            const listId = `apple-reminders:list:${row.list_id}`;
            allEdges.push({
              id: `nest:${listId}:${node.id}`,
              edgeType: 'NEST',
              sourceId: listId,
              targetId: node.id,
              weight: 1.0,
              directed: true,
            });
          }
          
          // Create NEST edge for subtasks
          if (row.parent_reminder_id) {
            const parentId = `apple-reminders:${row.parent_reminder_id}`;
            allEdges.push({
              id: `nest:${parentId}:${node.id}`,
              edgeType: 'NEST',
              sourceId: parentId,
              targetId: node.id,
              weight: 1.0,
              directed: true,
              sequenceOrder: row.sort_order || 0,
            });
          }
        }
        
        // Count
        const countResult = db.prepare(QUERY_REMINDER_COUNT).get() as { count: number };
        totalCount += countResult.count;
        
      } finally {
        db.close();
      }
    }
    
    // Add list nodes
    allNodes.push(...listNodes.values());
    
    // Update sync state
    this.syncState = {
      lastSync: new Date(),
      watermark: dateToCoreDataTimestamp(new Date()).toString(),
      itemCount: totalCount,
    };
    
    return {
      nodes: allNodes,
      edges: allEdges,
      deletedIds: [],
      syncState: this.syncState,
    };
  }
  
  async incrementalSync(state: SyncState): Promise<SyncResult> {
    const allNodes: CanonicalNode[] = [];
    const allEdges: CanonicalEdge[] = [];
    const deletedIds: string[] = [];
    let totalCount = 0;
    
    const watermark = state.watermark ? parseFloat(state.watermark) : 0;
    
    for (const dbPath of this.dbPaths) {
      if (!existsSync(dbPath)) continue;
      
      const db = new Database(dbPath, { readonly: true, fileMustExist: true });
      
      try {
        // Get modified reminders
        const rows = db.prepare(QUERY_REMINDERS_SINCE).all(watermark) as RawReminderRow[];
        
        for (const row of rows) {
          const node = this.rowToCanonicalNode(row);
          allNodes.push(node);
          
          // Edges (same as full sync)
          if (row.list_name) {
            const listId = `apple-reminders:list:${row.list_id}`;
            allEdges.push({
              id: `nest:${listId}:${node.id}`,
              edgeType: 'NEST',
              sourceId: listId,
              targetId: node.id,
              weight: 1.0,
              directed: true,
            });
          }
          
          if (row.parent_reminder_id) {
            const parentId = `apple-reminders:${row.parent_reminder_id}`;
            allEdges.push({
              id: `nest:${parentId}:${node.id}`,
              edgeType: 'NEST',
              sourceId: parentId,
              targetId: node.id,
              weight: 1.0,
              directed: true,
              sequenceOrder: row.sort_order || 0,
            });
          }
        }
        
        // Get deleted reminders
        const deleted = db.prepare(QUERY_DELETED_REMINDERS).all(watermark) as { id: number }[];
        for (const row of deleted) {
          deletedIds.push(`apple-reminders:${row.id}`);
        }
        
        // Count
        const countResult = db.prepare(QUERY_REMINDER_COUNT).get() as { count: number };
        totalCount += countResult.count;
        
      } finally {
        db.close();
      }
    }
    
    this.syncState = {
      lastSync: new Date(),
      watermark: dateToCoreDataTimestamp(new Date()).toString(),
      itemCount: totalCount,
    };
    
    return {
      nodes: allNodes,
      edges: allEdges,
      deletedIds,
      syncState: this.syncState,
    };
  }
  
  async getSyncState(): Promise<SyncState> {
    return this.syncState;
  }
  
  // ===========================================================================
  // Internal Methods
  // ===========================================================================
  
  private rowToCanonicalNode(row: RawReminderRow): CanonicalNode {
    const time = extractLatchTime(row);
    const category = extractLatchCategory(row);
    const hierarchy = extractLatchHierarchy(row);
    
    // Title might be null for subtasks that only have notes
    const title = row.title || row.notes?.slice(0, 50) || 'Untitled Reminder';
    
    return {
      id: `apple-reminders:${row.id}`,
      source: 'apple-reminders',
      sourceId: row.id.toString(),
      sourceUrl: generateReminderUrl(row.id),
      nodeType: 'task',
      name: title,
      content: row.notes || undefined,
      time,
      category,
      hierarchy,
      sourceMeta: {
        listId: row.list_id,
        listName: row.list_name,
        listColor: row.list_color,
        parentReminderId: row.parent_reminder_id,
        allDay: row.all_day === 1,
        flagged: row.flagged === 1,
      },
    };
  }
  
  private listToCanonicalNode(row: RawListRow): CanonicalNode {
    const hierarchy: string[] = [];
    if (row.account_name && row.account_name !== 'iCloud') {
      hierarchy.push(row.account_name);
    }
    
    return {
      id: `apple-reminders:list:${row.id}`,
      source: 'apple-reminders',
      sourceId: `list:${row.id}`,
      nodeType: 'project',
      name: row.name || 'Untitled List',
      time: {
        created: new Date(),
        modified: new Date(),
      },
      category: {
        hierarchy,
        tags: [],
        status: 'active',
      },
      hierarchy: {
        priority: 0,
        importance: 0,
        sortOrder: row.sort_order || 0,
      },
      sourceMeta: {
        color: row.color,
        accountName: row.account_name,
      },
    };
  }
}

// =============================================================================
// Factory Function
// =============================================================================

export function createAppleRemindersAdapter(): AppleRemindersAdapter {
  return new AppleRemindersAdapter();
}

// =============================================================================
// CLI Usage
// =============================================================================

if (import.meta.url === `file://${process.argv[1]}`) {
  const adapter = createAppleRemindersAdapter();
  
  (async () => {
    console.log('Apple Reminders ETL Adapter');
    console.log('===========================\n');
    
    const available = await adapter.isAvailable();
    console.log(`Database available: ${available}`);
    
    if (!available) {
      console.log('Reminders database not found. Are you on macOS?');
      process.exit(1);
    }
    
    console.log('\nRunning full sync...\n');
    
    const result = await adapter.fullSync();
    
    console.log(`Nodes extracted: ${result.nodes.length}`);
    console.log(`  - Tasks: ${result.nodes.filter(n => n.nodeType === 'task').length}`);
    console.log(`  - Lists: ${result.nodes.filter(n => n.nodeType === 'project').length}`);
    console.log(`Edges created: ${result.edges.length}`);
    
    // Show sample
    const sampleTask = result.nodes.find(n => n.nodeType === 'task');
    if (sampleTask) {
      console.log('\nSample reminder:');
      console.log(`  Title: ${sampleTask.name}`);
      console.log(`  List: ${sampleTask.category.hierarchy.join('/')}`);
      console.log(`  Priority: ${sampleTask.hierarchy.priority}`);
      console.log(`  Status: ${sampleTask.category.status}`);
      if (sampleTask.time.due) {
        console.log(`  Due: ${sampleTask.time.due.toISOString()}`);
      }
    }
  })();
}
