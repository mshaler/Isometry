/**
 * Apple Reminders Schema Module
 * 
 * Direct SQLite access to Reminders database.
 * 
 * Database location:
 *   ~/Library/Reminders/Container_v1/Stores/*.sqlite
 * 
 * Schema notes (macOS 14.x / iOS 17.x):
 * - ZREMCDREMINDER: Main reminders table
 * - ZREMCDLIST: Reminder lists (like folders)
 * - ZREMCDACCOUNT: Account info (iCloud, local, etc.)
 * 
 * Key columns on ZREMCDREMINDER:
 * - Z_PK: Primary key
 * - ZTITLE: Reminder title (can be null for subtasks)
 * - ZNOTES: Reminder notes/body
 * - ZDUEDATE: Due date (Core Data timestamp)
 * - ZCOMPLETIONDATE: Completion date
 * - ZPRIORITY: 0=none, 1=high, 5=medium, 9=low
 * - ZFLAGGED: Boolean flag
 * - ZLIST: FK to containing list
 * - ZPARENTREMINDER: FK for subtasks
 */

import { LatchCategory, LatchTime, LatchHierarchy } from '../../core/types.js';
import { readdirSync, existsSync } from 'fs';
import { join } from 'path';

// =============================================================================
// Database Path Resolution
// =============================================================================

/**
 * Get path(s) to Reminders SQLite database(s)
 * Reminders can have multiple store files (one per account)
 */
export function getRemindersStorePaths(): string[] {
  const home = process.env.HOME || '~';
  const storesDir = `${home}/Library/Reminders/Container_v1/Stores`;
  
  if (!existsSync(storesDir)) {
    return [];
  }
  
  try {
    const files = readdirSync(storesDir);
    return files
      .filter(f => f.endsWith('.sqlite'))
      .map(f => join(storesDir, f));
  } catch {
    return [];
  }
}

/**
 * Get the primary Reminders database (usually the largest/most recent)
 */
export function getPrimaryRemindersPath(): string | null {
  const paths = getRemindersStorePaths();
  return paths.length > 0 ? paths[0] : null;
}

// =============================================================================
// Core Data Timestamp Conversion (same as Notes)
// =============================================================================

const COCOA_REFERENCE = Date.UTC(2001, 0, 1, 0, 0, 0, 0);

export function coreDataTimestampToDate(timestamp: number | null): Date | undefined {
  if (timestamp === null || timestamp === undefined) return undefined;
  return new Date(COCOA_REFERENCE + (timestamp * 1000));
}

export function dateToCoreDataTimestamp(date: Date): number {
  return (date.getTime() - COCOA_REFERENCE) / 1000;
}

// =============================================================================
// Priority Mapping
// =============================================================================

/**
 * Apple Reminders priority values:
 * 0 = None
 * 1 = High (!!!)
 * 5 = Medium (!!)
 * 9 = Low (!)
 * 
 * We map to Isometry's 0-5 scale (higher = more important)
 */
export function mapPriority(applePriority: number | null): number {
  switch (applePriority) {
    case 1: return 5;  // High → 5
    case 5: return 3;  // Medium → 3
    case 9: return 1;  // Low → 1
    default: return 0; // None → 0
  }
}

/**
 * Reverse mapping for writing back
 */
export function mapPriorityToApple(isometryPriority: number): number {
  if (isometryPriority >= 5) return 1;
  if (isometryPriority >= 3) return 5;
  if (isometryPriority >= 1) return 9;
  return 0;
}

// =============================================================================
// SQL Queries
// =============================================================================

/**
 * Query all reminders with list info
 */
export const QUERY_ALL_REMINDERS = `
SELECT 
    r.Z_PK as id,
    r.ZTITLE as title,
    r.ZNOTES as notes,
    r.ZCREATIONDATE as created_timestamp,
    r.ZMODIFICATIONDATE as modified_timestamp,
    r.ZDUEDATE as due_timestamp,
    r.ZDUEDATEALIASDATE as due_alias_timestamp,
    r.ZCOMPLETIONDATE as completed_timestamp,
    r.ZPRIORITY as priority,
    r.ZFLAGGED as flagged,
    r.ZLIST as list_id,
    r.ZPARENTREMINDER as parent_reminder_id,
    r.ZALLDAY as all_day,
    r.ZORDER as sort_order,
    l.ZTITLE as list_name,
    l.ZCOLOR as list_color,
    a.ZTITLE as account_name
FROM ZREMCDREMINDER r
LEFT JOIN ZREMCDLIST l ON r.ZLIST = l.Z_PK
LEFT JOIN ZREMCDACCOUNT a ON l.ZACCOUNT = a.Z_PK
WHERE r.ZMARKEDFORDELETION IS NULL OR r.ZMARKEDFORDELETION = 0
ORDER BY r.ZMODIFICATIONDATE DESC
`;

/**
 * Query reminders modified since a timestamp
 */
export const QUERY_REMINDERS_SINCE = `
SELECT 
    r.Z_PK as id,
    r.ZTITLE as title,
    r.ZNOTES as notes,
    r.ZCREATIONDATE as created_timestamp,
    r.ZMODIFICATIONDATE as modified_timestamp,
    r.ZDUEDATE as due_timestamp,
    r.ZDUEDATEALIASDATE as due_alias_timestamp,
    r.ZCOMPLETIONDATE as completed_timestamp,
    r.ZPRIORITY as priority,
    r.ZFLAGGED as flagged,
    r.ZLIST as list_id,
    r.ZPARENTREMINDER as parent_reminder_id,
    r.ZALLDAY as all_day,
    r.ZORDER as sort_order,
    l.ZTITLE as list_name,
    l.ZCOLOR as list_color,
    a.ZTITLE as account_name
FROM ZREMCDREMINDER r
LEFT JOIN ZREMCDLIST l ON r.ZLIST = l.Z_PK
LEFT JOIN ZREMCDACCOUNT a ON l.ZACCOUNT = a.Z_PK
WHERE r.ZMODIFICATIONDATE > ?
  AND (r.ZMARKEDFORDELETION IS NULL OR r.ZMARKEDFORDELETION = 0)
ORDER BY r.ZMODIFICATIONDATE ASC
`;

/**
 * Query all lists (for folder structure)
 */
export const QUERY_ALL_LISTS = `
SELECT 
    l.Z_PK as id,
    l.ZTITLE as name,
    l.ZCOLOR as color,
    l.ZACCOUNT as account_id,
    l.ZORDER as sort_order,
    a.ZTITLE as account_name
FROM ZREMCDLIST l
LEFT JOIN ZREMCDACCOUNT a ON l.ZACCOUNT = a.Z_PK
WHERE l.ZMARKEDFORDELETION IS NULL OR l.ZMARKEDFORDELETION = 0
ORDER BY l.ZORDER
`;

/**
 * Query subtasks for a parent reminder
 */
export const QUERY_SUBTASKS = `
SELECT 
    r.Z_PK as id,
    r.ZTITLE as title,
    r.ZCOMPLETIONDATE as completed_timestamp,
    r.ZORDER as sort_order
FROM ZREMCDREMINDER r
WHERE r.ZPARENTREMINDER = ?
  AND (r.ZMARKEDFORDELETION IS NULL OR r.ZMARKEDFORDELETION = 0)
ORDER BY r.ZORDER
`;

/**
 * Query reminder count
 */
export const QUERY_REMINDER_COUNT = `
SELECT COUNT(*) as count
FROM ZREMCDREMINDER
WHERE ZMARKEDFORDELETION IS NULL OR ZMARKEDFORDELETION = 0
`;

/**
 * Query deleted reminders for sync
 */
export const QUERY_DELETED_REMINDERS = `
SELECT Z_PK as id
FROM ZREMCDREMINDER
WHERE ZMARKEDFORDELETION = 1
  AND ZMODIFICATIONDATE > ?
`;

// =============================================================================
// Raw Row Types
// =============================================================================

export interface RawReminderRow {
  id: number;
  title: string | null;
  notes: string | null;
  created_timestamp: number | null;
  modified_timestamp: number | null;
  due_timestamp: number | null;
  due_alias_timestamp: number | null;
  completed_timestamp: number | null;
  priority: number | null;
  flagged: number | null;
  list_id: number | null;
  parent_reminder_id: number | null;
  all_day: number | null;
  sort_order: number | null;
  list_name: string | null;
  list_color: string | null;
  account_name: string | null;
}

export interface RawListRow {
  id: number;
  name: string | null;
  color: string | null;
  account_id: number | null;
  sort_order: number | null;
  account_name: string | null;
}

// =============================================================================
// LATCH Property Extractors
// =============================================================================

/**
 * Extract LATCH Time properties from reminder row
 */
export function extractLatchTime(row: RawReminderRow): LatchTime {
  return {
    created: coreDataTimestampToDate(row.created_timestamp) || new Date(),
    modified: coreDataTimestampToDate(row.modified_timestamp) || new Date(),
    due: coreDataTimestampToDate(row.due_timestamp) || 
         coreDataTimestampToDate(row.due_alias_timestamp),
    completed: coreDataTimestampToDate(row.completed_timestamp),
  };
}

/**
 * Extract LATCH Category properties
 */
export function extractLatchCategory(row: RawReminderRow): LatchCategory {
  const hierarchy: string[] = [];
  
  // Account as top-level folder (if not default)
  if (row.account_name && row.account_name !== 'iCloud') {
    hierarchy.push(row.account_name);
  }
  
  // List as folder
  if (row.list_name) {
    hierarchy.push(row.list_name);
  }
  
  // Determine status
  let status: 'active' | 'pending' | 'completed' | 'archived' = 'active';
  if (row.completed_timestamp) {
    status = 'completed';
  } else if (row.due_timestamp) {
    const dueDate = coreDataTimestampToDate(row.due_timestamp);
    if (dueDate && dueDate < new Date()) {
      status = 'pending'; // Overdue
    }
  }
  
  return {
    hierarchy,
    tags: row.flagged ? ['flagged'] : [],
    status,
  };
}

/**
 * Extract LATCH Hierarchy properties
 */
export function extractLatchHierarchy(row: RawReminderRow): LatchHierarchy {
  return {
    priority: mapPriority(row.priority),
    importance: row.flagged ? 1 : 0,
    sortOrder: row.sort_order || 0,
  };
}

// =============================================================================
// URL Scheme
// =============================================================================

/**
 * Generate URL to open reminder in Reminders.app
 * Format: x-apple-reminderkit://reminder/{id}
 */
export function generateReminderUrl(reminderId: number): string {
  return `x-apple-reminderkit://reminder/${reminderId}`;
}
