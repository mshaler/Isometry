/**
 * Apple Calendar Source Adapter
 * 
 * Direct SQLite access to Calendar Cache for ETL to Isometry.
 * 
 * Features:
 * - Full sync: Import all events with calendar hierarchy
 * - Date range sync: Events within specific time window
 * - Incremental sync: Events modified since last watermark
 * - Location support: First adapter with LATCH Location data!
 * - Attendee extraction: Create LINK edges to contacts
 * 
 * LATCH Mapping:
 * - L: Event location (name, address, lat/lng)
 * - A: Event title
 * - T: Created, modified, eventStart, eventEnd
 * - C: Calendar name hierarchy
 * - H: Not used (events don't have priority)
 */

import Database from 'better-sqlite3';
import { existsSync } from 'fs';

import {
  SourceAdapter,
  SyncState,
  SyncResult,
  CanonicalNode,
  CanonicalEdge,
  SourceType,
} from '../../core/types.js';

import {
  getCalendarCachePath,
  isCalendarAvailable,
  dateToCoreDataTimestamp,
  QUERY_ALL_EVENTS,
  QUERY_EVENTS_SINCE,
  QUERY_EVENTS_IN_RANGE,
  QUERY_ALL_CALENDARS,
  QUERY_EVENT_ATTENDEES,
  QUERY_EVENT_COUNT,
  QUERY_DELETED_EVENTS,
  RawEventRow,
  RawCalendarRow,
  RawAttendeeRow,
  extractLatchTime,
  extractLatchLocation,
  extractLatchCategory,
  generateCalendarEventUrl,
} from './schema.js';

// =============================================================================
// Adapter Implementation
// =============================================================================

export class AppleCalendarAdapter implements SourceAdapter {
  readonly sourceType: SourceType = 'apple-calendar';
  readonly displayName = 'Apple Calendar';
  
  private dbPath: string;
  private syncState: SyncState;
  
  /** Optional: limit sync to events within this range */
  private dateRangeMonths: number;
  
  constructor(options?: { dbPath?: string; dateRangeMonths?: number }) {
    this.dbPath = options?.dbPath || getCalendarCachePath();
    this.dateRangeMonths = options?.dateRangeMonths || 12; // Default: 1 year
    this.syncState = { itemCount: 0 };
  }
  
  // ===========================================================================
  // SourceAdapter Interface
  // ===========================================================================
  
  async isAvailable(): Promise<boolean> {
    return existsSync(this.dbPath);
  }
  
  async fullSync(): Promise<SyncResult> {
    const db = this.openDatabase();
    
    try {
      const nodes: CanonicalNode[] = [];
      const edges: CanonicalEdge[] = [];
      const calendarNodes = new Map<string, CanonicalNode>();
      
      // Get all calendars first
      const calendars = db.prepare(QUERY_ALL_CALENDARS).all() as RawCalendarRow[];
      for (const cal of calendars) {
        const calNode = this.calendarToCanonicalNode(cal);
        calendarNodes.set(calNode.id, calNode);
      }
      
      // Get events (optionally limited by date range)
      let rows: RawEventRow[];
      
      if (this.dateRangeMonths > 0) {
        // Limit to recent/upcoming events
        const now = new Date();
        const pastDate = new Date(now);
        pastDate.setMonth(pastDate.getMonth() - this.dateRangeMonths);
        const futureDate = new Date(now);
        futureDate.setMonth(futureDate.getMonth() + this.dateRangeMonths);
        
        rows = db.prepare(QUERY_EVENTS_IN_RANGE).all(
          dateToCoreDataTimestamp(pastDate),
          dateToCoreDataTimestamp(futureDate)
        ) as RawEventRow[];
      } else {
        rows = db.prepare(QUERY_ALL_EVENTS).all() as RawEventRow[];
      }
      
      for (const row of rows) {
        const node = this.rowToCanonicalNode(row);
        nodes.push(node);
        
        // Create NEST edge from calendar to event
        if (row.calendar_id) {
          const calId = `apple-calendar:calendar:${row.calendar_id}`;
          edges.push({
            id: `nest:${calId}:${node.id}`,
            edgeType: 'NEST',
            sourceId: calId,
            targetId: node.id,
            weight: 1.0,
            directed: true,
          });
        }
        
        // Get attendees and create LINK edges
        const attendeeEdges = this.getAttendeeEdges(db, row.id, node.id);
        edges.push(...attendeeEdges);
      }
      
      // Add calendar nodes
      nodes.push(...calendarNodes.values());
      
      // Count
      const countResult = db.prepare(QUERY_EVENT_COUNT).get() as { count: number };
      
      this.syncState = {
        lastSync: new Date(),
        watermark: dateToCoreDataTimestamp(new Date()).toString(),
        itemCount: countResult.count,
      };
      
      return {
        nodes,
        edges,
        deletedIds: [],
        syncState: this.syncState,
      };
      
    } finally {
      db.close();
    }
  }
  
  async incrementalSync(state: SyncState): Promise<SyncResult> {
    const db = this.openDatabase();
    
    try {
      const nodes: CanonicalNode[] = [];
      const edges: CanonicalEdge[] = [];
      const deletedIds: string[] = [];
      
      const watermark = state.watermark ? parseFloat(state.watermark) : 0;
      
      // Get modified events
      const rows = db.prepare(QUERY_EVENTS_SINCE).all(watermark) as RawEventRow[];
      
      for (const row of rows) {
        const node = this.rowToCanonicalNode(row);
        nodes.push(node);
        
        if (row.calendar_id) {
          const calId = `apple-calendar:calendar:${row.calendar_id}`;
          edges.push({
            id: `nest:${calId}:${node.id}`,
            edgeType: 'NEST',
            sourceId: calId,
            targetId: node.id,
            weight: 1.0,
            directed: true,
          });
        }
        
        const attendeeEdges = this.getAttendeeEdges(db, row.id, node.id);
        edges.push(...attendeeEdges);
      }
      
      // Get deleted events
      const deleted = db.prepare(QUERY_DELETED_EVENTS).all(watermark) as { id: number }[];
      for (const row of deleted) {
        deletedIds.push(`apple-calendar:${row.id}`);
      }
      
      const countResult = db.prepare(QUERY_EVENT_COUNT).get() as { count: number };
      
      this.syncState = {
        lastSync: new Date(),
        watermark: dateToCoreDataTimestamp(new Date()).toString(),
        itemCount: countResult.count,
      };
      
      return {
        nodes,
        edges,
        deletedIds,
        syncState: this.syncState,
      };
      
    } finally {
      db.close();
    }
  }
  
  async getSyncState(): Promise<SyncState> {
    return this.syncState;
  }
  
  // ===========================================================================
  // Additional Methods
  // ===========================================================================
  
  /**
   * Sync events within a specific date range
   */
  async syncDateRange(startDate: Date, endDate: Date): Promise<SyncResult> {
    const db = this.openDatabase();
    
    try {
      const nodes: CanonicalNode[] = [];
      const edges: CanonicalEdge[] = [];
      
      const rows = db.prepare(QUERY_EVENTS_IN_RANGE).all(
        dateToCoreDataTimestamp(startDate),
        dateToCoreDataTimestamp(endDate)
      ) as RawEventRow[];
      
      for (const row of rows) {
        const node = this.rowToCanonicalNode(row);
        nodes.push(node);
        
        if (row.calendar_id) {
          const calId = `apple-calendar:calendar:${row.calendar_id}`;
          edges.push({
            id: `nest:${calId}:${node.id}`,
            edgeType: 'NEST',
            sourceId: calId,
            targetId: node.id,
            weight: 1.0,
            directed: true,
          });
        }
      }
      
      return {
        nodes,
        edges,
        deletedIds: [],
        syncState: this.syncState,
      };
      
    } finally {
      db.close();
    }
  }
  
  // ===========================================================================
  // Internal Methods
  // ===========================================================================
  
  private openDatabase(): Database.Database {
    return new Database(this.dbPath, { readonly: true, fileMustExist: true });
  }
  
  private rowToCanonicalNode(row: RawEventRow): CanonicalNode {
    const time = extractLatchTime(row);
    const location = extractLatchLocation(row);
    const category = extractLatchCategory(row);
    
    return {
      id: `apple-calendar:${row.id}`,
      source: 'apple-calendar',
      sourceId: row.id.toString(),
      sourceUrl: generateCalendarEventUrl(row.id),
      nodeType: 'event',
      name: row.title || 'Untitled Event',
      content: row.notes || undefined,
      location,
      time,
      category,
      hierarchy: {
        priority: 0,
        importance: 0,
        sortOrder: 0,
      },
      sourceMeta: {
        calendarId: row.calendar_id,
        calendarName: row.calendar_name,
        calendarColor: row.calendar_color || row.calendar_color_name,
        allDay: row.all_day === 1,
        hasRecurrence: row.recurrence_id !== null,
        url: row.url,
      },
    };
  }
  
  private calendarToCanonicalNode(row: RawCalendarRow): CanonicalNode {
    const hierarchy: string[] = [];
    if (row.account_name) {
      hierarchy.push(row.account_name);
    }
    
    return {
      id: `apple-calendar:calendar:${row.id}`,
      source: 'apple-calendar',
      sourceId: `calendar:${row.id}`,
      nodeType: 'project',
      name: row.name || 'Untitled Calendar',
      time: {
        created: new Date(),
        modified: new Date(),
      },
      category: {
        hierarchy,
        tags: [],
        status: 'active',
      },
      hierarchy: {
        priority: 0,
        importance: 0,
        sortOrder: row.sort_order || 0,
      },
      sourceMeta: {
        color: row.color || row.color_name,
        accountName: row.account_name,
      },
    };
  }
  
  private getAttendeeEdges(
    db: Database.Database,
    eventId: number,
    eventNodeId: string
  ): CanonicalEdge[] {
    const edges: CanonicalEdge[] = [];
    
    try {
      const attendees = db.prepare(QUERY_EVENT_ATTENDEES).all(eventId) as RawAttendeeRow[];
      
      for (const attendee of attendees) {
        if (!attendee.email) continue;
        
        // Create a reference to a contact node (may or may not exist)
        // The contact adapter would create the actual node
        const contactId = `apple-contacts:email:${attendee.email.toLowerCase()}`;
        
        edges.push({
          id: `link:${eventNodeId}:${contactId}`,
          edgeType: 'LINK',
          sourceId: eventNodeId,
          targetId: contactId,
          label: attendee.name || attendee.email,
          weight: 0.5, // Could be weighted by attendance status
          directed: false,
        });
      }
    } catch {
      // Attendees table might not exist in all versions
    }
    
    return edges;
  }
}

// =============================================================================
// Factory Function
// =============================================================================

export function createAppleCalendarAdapter(options?: {
  dateRangeMonths?: number;
}): AppleCalendarAdapter {
  return new AppleCalendarAdapter(options);
}

// =============================================================================
// CLI Usage
// =============================================================================

if (import.meta.url === `file://${process.argv[1]}`) {
  const adapter = createAppleCalendarAdapter({ dateRangeMonths: 3 });
  
  (async () => {
    console.log('Apple Calendar ETL Adapter');
    console.log('==========================\n');
    
    const available = await adapter.isAvailable();
    console.log(`Database available: ${available}`);
    
    if (!available) {
      console.log('Calendar Cache not found. Are you on macOS?');
      process.exit(1);
    }
    
    console.log('\nRunning full sync (±3 months)...\n');
    
    const result = await adapter.fullSync();
    
    console.log(`Nodes extracted: ${result.nodes.length}`);
    console.log(`  - Events: ${result.nodes.filter(n => n.nodeType === 'event').length}`);
    console.log(`  - Calendars: ${result.nodes.filter(n => n.nodeType === 'project').length}`);
    console.log(`Edges created: ${result.edges.length}`);
    
    // Show sample with location
    const eventWithLocation = result.nodes.find(n => 
      n.nodeType === 'event' && n.location?.name
    );
    
    if (eventWithLocation) {
      console.log('\nSample event with location:');
      console.log(`  Title: ${eventWithLocation.name}`);
      console.log(`  Calendar: ${eventWithLocation.category.hierarchy.join('/')}`);
      console.log(`  Location: ${eventWithLocation.location?.name}`);
      if (eventWithLocation.location?.latitude) {
        console.log(`  Coordinates: ${eventWithLocation.location.latitude}, ${eventWithLocation.location.longitude}`);
      }
      if (eventWithLocation.time.eventStart) {
        console.log(`  Start: ${eventWithLocation.time.eventStart.toISOString()}`);
      }
    } else {
      // Show any event
      const anyEvent = result.nodes.find(n => n.nodeType === 'event');
      if (anyEvent) {
        console.log('\nSample event:');
        console.log(`  Title: ${anyEvent.name}`);
        console.log(`  Calendar: ${anyEvent.category.hierarchy.join('/')}`);
        if (anyEvent.time.eventStart) {
          console.log(`  Start: ${anyEvent.time.eventStart.toISOString()}`);
        }
      }
    }
  })();
}
