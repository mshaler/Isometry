/**
 * Apple Calendar Schema Module
 * 
 * Direct SQLite access to Calendar cache database.
 * 
 * Database location:
 *   ~/Library/Calendars/Calendar Cache
 * 
 * Alternative (per-account):
 *   ~/Library/Calendars/*.caldav/
 * 
 * Schema notes (macOS 14.x):
 * - ZCALENDARITEM: Main events table (events + reminders)
 * - ZCALENDAR: Calendar definitions
 * - ZNODE: CalDAV/iCloud accounts
 * - ZRECURRENCERULE: Recurrence patterns
 * - ZALARM: Event alarms/reminders
 * - ZATTENDEE: Event attendees
 * - ZLOCATION: Event locations (LATCH: L!)
 * 
 * Key columns on ZCALENDARITEM:
 * - Z_PK: Primary key
 * - ZTITLE: Event title
 * - ZNOTES: Event notes
 * - ZSTARTDATE: Start time (Core Data timestamp)
 * - ZENDDATE: End time
 * - ZALLDAY: Boolean
 * - ZCALENDAR: FK to calendar
 * - ZLOCATION: FK to location
 * - ZRECURRENCERULE: FK to recurrence
 */

import { LatchLocation, LatchCategory, LatchTime } from '../../core/types.js';
import { existsSync } from 'fs';

// =============================================================================
// Database Path Resolution
// =============================================================================

/**
 * Get path to Calendar Cache database
 */
export function getCalendarCachePath(): string {
  const home = process.env.HOME || '~';
  return `${home}/Library/Calendars/Calendar Cache`;
}

/**
 * Check if Calendar database exists
 */
export function isCalendarAvailable(): boolean {
  return existsSync(getCalendarCachePath());
}

// =============================================================================
// Core Data Timestamp Conversion
// =============================================================================

const COCOA_REFERENCE = Date.UTC(2001, 0, 1, 0, 0, 0, 0);

export function coreDataTimestampToDate(timestamp: number | null): Date | undefined {
  if (timestamp === null || timestamp === undefined) return undefined;
  return new Date(COCOA_REFERENCE + (timestamp * 1000));
}

export function dateToCoreDataTimestamp(date: Date): number {
  return (date.getTime() - COCOA_REFERENCE) / 1000;
}

// =============================================================================
// SQL Queries
// =============================================================================

/**
 * Query all events with calendar and location info
 */
export const QUERY_ALL_EVENTS = `
SELECT 
    ci.Z_PK as id,
    ci.ZTITLE as title,
    ci.ZNOTES as notes,
    ci.ZSTARTDATE as start_timestamp,
    ci.ZENDDATE as end_timestamp,
    ci.ZALLDAY as all_day,
    ci.ZCREATIONDATE as created_timestamp,
    ci.ZMODIFICATIONDATE as modified_timestamp,
    ci.ZCALENDAR as calendar_id,
    ci.ZLOCATION as location_id,
    ci.ZRECURRENCERULE as recurrence_id,
    ci.ZURL as url,
    ci.ZSTATUS as status,
    c.ZTITLE as calendar_name,
    c.ZCOLOR as calendar_color,
    c.ZSYMBOLICCOLORNAME as calendar_color_name,
    l.ZTITLE as location_name,
    l.ZADDRESS as location_address,
    l.ZLATITUDE as latitude,
    l.ZLONGITUDE as longitude
FROM ZCALENDARITEM ci
LEFT JOIN ZCALENDAR c ON ci.ZCALENDAR = c.Z_PK
LEFT JOIN ZLOCATION l ON ci.ZLOCATION = l.Z_PK
WHERE ci.ZTITLE IS NOT NULL
  AND ci.ZENTITYTYPE = 1  -- Events only (not reminders)
  AND (ci.ZMARKEDFORDELETION IS NULL OR ci.ZMARKEDFORDELETION = 0)
ORDER BY ci.ZSTARTDATE DESC
`;

/**
 * Query events within a date range
 */
export const QUERY_EVENTS_IN_RANGE = `
SELECT 
    ci.Z_PK as id,
    ci.ZTITLE as title,
    ci.ZNOTES as notes,
    ci.ZSTARTDATE as start_timestamp,
    ci.ZENDDATE as end_timestamp,
    ci.ZALLDAY as all_day,
    ci.ZCREATIONDATE as created_timestamp,
    ci.ZMODIFICATIONDATE as modified_timestamp,
    ci.ZCALENDAR as calendar_id,
    ci.ZLOCATION as location_id,
    ci.ZRECURRENCERULE as recurrence_id,
    ci.ZURL as url,
    ci.ZSTATUS as status,
    c.ZTITLE as calendar_name,
    c.ZCOLOR as calendar_color,
    c.ZSYMBOLICCOLORNAME as calendar_color_name,
    l.ZTITLE as location_name,
    l.ZADDRESS as location_address,
    l.ZLATITUDE as latitude,
    l.ZLONGITUDE as longitude
FROM ZCALENDARITEM ci
LEFT JOIN ZCALENDAR c ON ci.ZCALENDAR = c.Z_PK
LEFT JOIN ZLOCATION l ON ci.ZLOCATION = l.Z_PK
WHERE ci.ZTITLE IS NOT NULL
  AND ci.ZENTITYTYPE = 1
  AND ci.ZSTARTDATE >= ?
  AND ci.ZSTARTDATE <= ?
  AND (ci.ZMARKEDFORDELETION IS NULL OR ci.ZMARKEDFORDELETION = 0)
ORDER BY ci.ZSTARTDATE ASC
`;

/**
 * Query events modified since a timestamp
 */
export const QUERY_EVENTS_SINCE = `
SELECT 
    ci.Z_PK as id,
    ci.ZTITLE as title,
    ci.ZNOTES as notes,
    ci.ZSTARTDATE as start_timestamp,
    ci.ZENDDATE as end_timestamp,
    ci.ZALLDAY as all_day,
    ci.ZCREATIONDATE as created_timestamp,
    ci.ZMODIFICATIONDATE as modified_timestamp,
    ci.ZCALENDAR as calendar_id,
    ci.ZLOCATION as location_id,
    ci.ZRECURRENCERULE as recurrence_id,
    ci.ZURL as url,
    ci.ZSTATUS as status,
    c.ZTITLE as calendar_name,
    c.ZCOLOR as calendar_color,
    c.ZSYMBOLICCOLORNAME as calendar_color_name,
    l.ZTITLE as location_name,
    l.ZADDRESS as location_address,
    l.ZLATITUDE as latitude,
    l.ZLONGITUDE as longitude
FROM ZCALENDARITEM ci
LEFT JOIN ZCALENDAR c ON ci.ZCALENDAR = c.Z_PK
LEFT JOIN ZLOCATION l ON ci.ZLOCATION = l.Z_PK
WHERE ci.ZTITLE IS NOT NULL
  AND ci.ZENTITYTYPE = 1
  AND ci.ZMODIFICATIONDATE > ?
  AND (ci.ZMARKEDFORDELETION IS NULL OR ci.ZMARKEDFORDELETION = 0)
ORDER BY ci.ZMODIFICATIONDATE ASC
`;

/**
 * Query all calendars
 */
export const QUERY_ALL_CALENDARS = `
SELECT 
    c.Z_PK as id,
    c.ZTITLE as name,
    c.ZCOLOR as color,
    c.ZSYMBOLICCOLORNAME as color_name,
    c.ZNODE as account_id,
    c.ZORDER as sort_order,
    n.ZTITLE as account_name
FROM ZCALENDAR c
LEFT JOIN ZNODE n ON c.ZNODE = n.Z_PK
WHERE c.ZMARKEDFORDELETION IS NULL OR c.ZMARKEDFORDELETION = 0
ORDER BY c.ZORDER
`;

/**
 * Query attendees for an event
 */
export const QUERY_EVENT_ATTENDEES = `
SELECT 
    a.Z_PK as id,
    a.ZCOMMONNAME as name,
    a.ZEMAIL as email,
    a.ZPARTICIPATIONSTATUS as status,
    a.ZROLE as role
FROM ZATTENDEE a
WHERE a.ZCALENDARITEM = ?
`;

/**
 * Query alarms for an event
 */
export const QUERY_EVENT_ALARMS = `
SELECT 
    al.Z_PK as id,
    al.ZTRIGGERINTERVAL as trigger_interval,
    al.ZTRIGGERDATE as trigger_date
FROM ZALARM al
WHERE al.ZCALENDARITEM = ?
`;

/**
 * Query event count
 */
export const QUERY_EVENT_COUNT = `
SELECT COUNT(*) as count
FROM ZCALENDARITEM
WHERE ZTITLE IS NOT NULL
  AND ZENTITYTYPE = 1
  AND (ZMARKEDFORDELETION IS NULL OR ZMARKEDFORDELETION = 0)
`;

/**
 * Query deleted events
 */
export const QUERY_DELETED_EVENTS = `
SELECT Z_PK as id
FROM ZCALENDARITEM
WHERE ZENTITYTYPE = 1
  AND ZMARKEDFORDELETION = 1
  AND ZMODIFICATIONDATE > ?
`;

// =============================================================================
// Raw Row Types
// =============================================================================

export interface RawEventRow {
  id: number;
  title: string | null;
  notes: string | null;
  start_timestamp: number | null;
  end_timestamp: number | null;
  all_day: number | null;
  created_timestamp: number | null;
  modified_timestamp: number | null;
  calendar_id: number | null;
  location_id: number | null;
  recurrence_id: number | null;
  url: string | null;
  status: number | null;
  calendar_name: string | null;
  calendar_color: string | null;
  calendar_color_name: string | null;
  location_name: string | null;
  location_address: string | null;
  latitude: number | null;
  longitude: number | null;
}

export interface RawCalendarRow {
  id: number;
  name: string | null;
  color: string | null;
  color_name: string | null;
  account_id: number | null;
  sort_order: number | null;
  account_name: string | null;
}

export interface RawAttendeeRow {
  id: number;
  name: string | null;
  email: string | null;
  status: number | null;
  role: number | null;
}

// =============================================================================
// Status Mapping
// =============================================================================

/**
 * Map event status codes to strings
 */
export function mapEventStatus(status: number | null): 'active' | 'pending' | 'completed' | 'archived' {
  switch (status) {
    case 0: return 'active';     // None/Confirmed
    case 1: return 'pending';    // Tentative
    case 2: return 'archived';   // Cancelled
    default: return 'active';
  }
}

/**
 * Map attendee participation status
 */
export function mapAttendeeStatus(status: number | null): string {
  switch (status) {
    case 0: return 'unknown';
    case 1: return 'pending';
    case 2: return 'accepted';
    case 3: return 'declined';
    case 4: return 'tentative';
    default: return 'unknown';
  }
}

// =============================================================================
// LATCH Property Extractors
// =============================================================================

/**
 * Extract LATCH Time properties from event row
 * Note: Calendar events use eventStart/eventEnd, not due dates
 */
export function extractLatchTime(row: RawEventRow): LatchTime {
  return {
    created: coreDataTimestampToDate(row.created_timestamp) || new Date(),
    modified: coreDataTimestampToDate(row.modified_timestamp) || new Date(),
    eventStart: coreDataTimestampToDate(row.start_timestamp),
    eventEnd: coreDataTimestampToDate(row.end_timestamp),
  };
}

/**
 * Extract LATCH Location properties
 * This is the first adapter that actually uses Location!
 */
export function extractLatchLocation(row: RawEventRow): LatchLocation | undefined {
  if (!row.location_name && !row.latitude) {
    return undefined;
  }
  
  return {
    name: row.location_name || undefined,
    address: row.location_address || undefined,
    latitude: row.latitude || undefined,
    longitude: row.longitude || undefined,
  };
}

/**
 * Extract LATCH Category properties
 */
export function extractLatchCategory(row: RawEventRow): LatchCategory {
  const hierarchy: string[] = [];
  
  // Calendar name as primary category
  if (row.calendar_name) {
    hierarchy.push(row.calendar_name);
  }
  
  return {
    hierarchy,
    tags: [], // Could extract from notes with #tags
    status: mapEventStatus(row.status),
  };
}

// =============================================================================
// URL Scheme
// =============================================================================

/**
 * Generate URL to open event in Calendar.app
 * Format: ical://ekevent/{id}
 */
export function generateCalendarEventUrl(eventId: number): string {
  return `ical://ekevent/${eventId}`;
}

/**
 * Generate calshow:// URL for a specific date
 */
export function generateCalendarDateUrl(date: Date): string {
  // calshow uses Unix timestamp
  const timestamp = Math.floor(date.getTime() / 1000);
  return `calshow:${timestamp}`;
}
