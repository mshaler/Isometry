/**
 * Apple Calendar Adapter Module
 */

export { AppleCalendarAdapter, createAppleCalendarAdapter } from './adapter.js';
export {
  getCalendarCachePath,
  isCalendarAvailable,
  coreDataTimestampToDate,
  dateToCoreDataTimestamp,
  mapEventStatus,
  mapAttendeeStatus,
  extractLatchTime,
  extractLatchLocation,
  extractLatchCategory,
  generateCalendarEventUrl,
  generateCalendarDateUrl,
  QUERY_ALL_EVENTS,
  QUERY_EVENTS_SINCE,
  QUERY_EVENTS_IN_RANGE,
  QUERY_ALL_CALENDARS,
  QUERY_EVENT_ATTENDEES,
  QUERY_EVENT_ALARMS,
  QUERY_EVENT_COUNT,
  QUERY_DELETED_EVENTS,
  type RawEventRow,
  type RawCalendarRow,
  type RawAttendeeRow,
} from './schema.js';
