/**
 * Slack Local Cache Schema Module
 * 
 * The Slack desktop app maintains a local SQLite cache for offline access.
 * This provides faster access than API calls, no rate limits, and works offline.
 * 
 * Cache location (macOS):
 *   ~/Library/Application Support/Slack/storage/*.db
 *   ~/Library/Containers/com.tinyspeck.slackmacgap/Data/Library/Application Support/Slack/storage/*.db (sandboxed)
 * 
 * Note: The exact schema varies by Slack client version. This module handles
 * the most common patterns and gracefully degrades when tables are missing.
 * 
 * Key tables (when available):
 * - messages: Message content and metadata
 * - channels: Channel/DM/group info
 * - users: User profiles
 * - files: Shared files metadata
 * 
 * Fallback: If SQLite is unavailable or incomplete, use MCP connector.
 */

import { LatchCategory, LatchTime } from '../../core/types.js';
import { existsSync, readdirSync } from 'fs';
import { join } from 'path';

// =============================================================================
// Database Path Resolution
// =============================================================================

/**
 * Possible locations for Slack's local database
 */
export function getSlackDbPaths(): string[] {
  const home = process.env.HOME || '~';
  
  const possiblePaths = [
    // Non-sandboxed install
    `${home}/Library/Application Support/Slack/storage`,
    // Sandboxed (App Store) install
    `${home}/Library/Containers/com.tinyspeck.slackmacgap/Data/Library/Application Support/Slack/storage`,
    // Electron cache location
    `${home}/Library/Application Support/Slack/IndexedDB`,
  ];
  
  const dbFiles: string[] = [];
  
  for (const dir of possiblePaths) {
    if (existsSync(dir)) {
      try {
        const files = readdirSync(dir);
        for (const file of files) {
          if (file.endsWith('.db') || file.endsWith('.sqlite')) {
            dbFiles.push(join(dir, file));
          }
        }
      } catch {
        // Permission denied or other error
      }
    }
  }
  
  return dbFiles;
}

/**
 * Check if Slack local cache is available
 */
export function isSlackCacheAvailable(): boolean {
  const paths = getSlackDbPaths();
  return paths.length > 0;
}

/**
 * Get the primary Slack database path
 */
export function getPrimarySlackDbPath(): string | null {
  const paths = getSlackDbPaths();
  // Prefer larger files (more likely to have useful data)
  return paths.length > 0 ? paths[0] : null;
}

// =============================================================================
// Workspace Detection
// =============================================================================

/**
 * Slack organizes data by workspace. Each workspace has its own tables/databases.
 */
export interface SlackWorkspace {
  id: string;
  name: string;
  domain: string;
  dbPath?: string;
}

/**
 * Detect workspaces from local cache
 */
export function detectWorkspaces(dbPaths: string[]): SlackWorkspace[] {
  // This would parse the Slack config or database metadata
  // For now, return empty - will be populated when we probe the database
  return [];
}

// =============================================================================
// Timestamp Conversion
// =============================================================================

/**
 * Slack uses Unix timestamps (seconds since epoch)
 */
export function slackTimestampToDate(ts: string | number | null): Date | undefined {
  if (ts === null || ts === undefined) return undefined;
  
  // Slack timestamps are often strings like "1234567890.123456"
  const seconds = typeof ts === 'string' ? parseFloat(ts) : ts;
  return new Date(seconds * 1000);
}

/**
 * Convert Date to Slack timestamp format
 */
export function dateToSlackTimestamp(date: Date): string {
  return (date.getTime() / 1000).toFixed(6);
}

// =============================================================================
// SQL Queries (for when SQLite is available)
// =============================================================================

/**
 * Query to detect available tables
 * Use this to probe the schema before running queries
 */
export const QUERY_SCHEMA_PROBE = `
SELECT name FROM sqlite_master 
WHERE type='table' 
AND name NOT LIKE 'sqlite_%'
`;

/**
 * Query messages (schema varies, this is a common pattern)
 */
export const QUERY_MESSAGES = `
SELECT 
    ts as id,
    text as content,
    user as user_id,
    channel as channel_id,
    ts as timestamp,
    thread_ts as thread_id,
    type as message_type
FROM messages
WHERE type = 'message'
ORDER BY ts DESC
LIMIT ?
`;

/**
 * Query channels
 */
export const QUERY_CHANNELS = `
SELECT 
    id,
    name,
    is_channel,
    is_group,
    is_im,
    is_mpim,
    is_private,
    is_archived,
    created,
    topic,
    purpose
FROM channels
WHERE is_archived = 0 OR is_archived IS NULL
`;

/**
 * Query users
 */
export const QUERY_USERS = `
SELECT 
    id,
    name,
    real_name,
    display_name,
    email,
    is_bot,
    deleted
FROM users
WHERE deleted = 0 OR deleted IS NULL
`;

// =============================================================================
// Raw Row Types
// =============================================================================

export interface RawSlackMessage {
  id: string;
  content: string | null;
  user_id: string | null;
  channel_id: string | null;
  timestamp: string | null;
  thread_id: string | null;
  message_type: string | null;
}

export interface RawSlackChannel {
  id: string;
  name: string | null;
  is_channel: number | null;
  is_group: number | null;
  is_im: number | null;
  is_mpim: number | null;
  is_private: number | null;
  is_archived: number | null;
  created: number | null;
  topic: string | null;
  purpose: string | null;
}

export interface RawSlackUser {
  id: string;
  name: string | null;
  real_name: string | null;
  display_name: string | null;
  email: string | null;
  is_bot: number | null;
  deleted: number | null;
}

// =============================================================================
// Channel Type Detection
// =============================================================================

export type SlackChannelType = 'channel' | 'group' | 'dm' | 'mpim';

export function getChannelType(row: RawSlackChannel): SlackChannelType {
  if (row.is_im) return 'dm';
  if (row.is_mpim) return 'mpim';
  if (row.is_group || row.is_private) return 'group';
  return 'channel';
}

// =============================================================================
// LATCH Property Extractors
// =============================================================================

/**
 * Extract LATCH Time from Slack message
 */
export function extractMessageLatchTime(msg: RawSlackMessage): LatchTime {
  const timestamp = slackTimestampToDate(msg.timestamp);
  return {
    created: timestamp || new Date(),
    modified: timestamp || new Date(),
  };
}

/**
 * Extract LATCH Category from Slack message
 */
export function extractMessageLatchCategory(
  msg: RawSlackMessage,
  channelName?: string,
  workspaceName?: string
): LatchCategory {
  const hierarchy: string[] = [];
  
  if (workspaceName) {
    hierarchy.push(workspaceName);
  }
  
  if (channelName) {
    hierarchy.push(channelName);
  }
  
  return {
    hierarchy,
    tags: extractSlackMentions(msg.content || ''),
    status: 'active',
  };
}

/**
 * Extract @mentions and #channels from Slack message
 */
export function extractSlackMentions(text: string): string[] {
  const tags: string[] = [];
  
  // User mentions: <@U1234567>
  const userMentions = text.match(/<@[A-Z0-9]+>/g) || [];
  for (const mention of userMentions) {
    tags.push(`@${mention.slice(2, -1)}`);
  }
  
  // Channel mentions: <#C1234567|channel-name>
  const channelMentions = text.match(/<#[A-Z0-9]+\|[^>]+>/g) || [];
  for (const mention of channelMentions) {
    const channelName = mention.split('|')[1]?.slice(0, -1);
    if (channelName) {
      tags.push(`#${channelName}`);
    }
  }
  
  return tags;
}

/**
 * Clean Slack message text (remove formatting codes)
 */
export function cleanSlackText(text: string): string {
  return text
    // User mentions: <@U1234567> → @user
    .replace(/<@([A-Z0-9]+)>/g, '@$1')
    // Channel mentions: <#C1234567|channel-name> → #channel-name
    .replace(/<#[A-Z0-9]+\|([^>]+)>/g, '#$1')
    // Links: <https://example.com|label> → label (https://example.com)
    .replace(/<(https?:\/\/[^|>]+)\|([^>]+)>/g, '$2 ($1)')
    // Plain links: <https://example.com> → https://example.com
    .replace(/<(https?:\/\/[^>]+)>/g, '$1')
    // Special markers
    .replace(/<!here>/g, '@here')
    .replace(/<!channel>/g, '@channel')
    .replace(/<!everyone>/g, '@everyone');
}

// =============================================================================
// URL Scheme
// =============================================================================

/**
 * Generate Slack deep link to a message
 * Format: slack://channel?team=TXXXXX&id=CXXXXX&message=1234567890.123456
 */
export function generateSlackMessageUrl(
  workspaceId: string,
  channelId: string,
  messageTs: string
): string {
  return `slack://channel?team=${workspaceId}&id=${channelId}&message=${messageTs}`;
}

/**
 * Generate Slack web URL to a message
 */
export function generateSlackWebUrl(
  workspaceDomain: string,
  channelId: string,
  messageTs: string
): string {
  // Remove the decimal point from timestamp for URL
  const tsForUrl = messageTs.replace('.', '');
  return `https://${workspaceDomain}.slack.com/archives/${channelId}/p${tsForUrl}`;
}
