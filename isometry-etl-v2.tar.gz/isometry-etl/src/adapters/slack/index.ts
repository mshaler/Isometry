/**
 * Slack Adapter Module
 * 
 * Hybrid adapter: SQLite cache first, MCP fallback.
 */

export { 
  SlackAdapter, 
  createSlackAdapter,
  type SlackAdapterOptions,
  type SlackDataSource,
} from './adapter.js';

export {
  getSlackDbPaths,
  isSlackCacheAvailable,
  getPrimarySlackDbPath,
  slackTimestampToDate,
  dateToSlackTimestamp,
  getChannelType,
  extractMessageLatchTime,
  extractMessageLatchCategory,
  extractSlackMentions,
  cleanSlackText,
  generateSlackMessageUrl,
  generateSlackWebUrl,
  detectWorkspaces,
  type SlackWorkspace,
  type RawSlackMessage,
  type RawSlackChannel,
  type RawSlackUser,
  type SlackChannelType,
} from './schema.js';
