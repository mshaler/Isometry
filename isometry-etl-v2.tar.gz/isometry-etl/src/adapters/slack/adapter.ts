/**
 * Slack Source Adapter
 * 
 * Hybrid adapter that tries local SQLite cache first, falls back to MCP.
 * 
 * Strategy:
 * 1. Check for local SQLite cache (Slack desktop app)
 * 2. If available and fresh, use it (fast, no rate limits)
 * 3. If unavailable or stale, fall back to MCP connector
 * 4. MCP requires user to have Slack MCP server configured
 * 
 * Data Model:
 * - Messages become nodes (type: 'note' for now, could be 'message')
 * - Channels/DMs become project nodes (containers)
 * - Users become contact nodes
 * - Thread replies create SEQUENCE edges
 * - @mentions create LINK edges to users
 * 
 * LATCH Mapping:
 * - L: Not used
 * - A: Message text (first line as title)
 * - T: Message timestamp
 * - C: Workspace → Channel hierarchy
 * - H: Not used (messages don't have priority)
 */

import Database from 'better-sqlite3';
import { existsSync } from 'fs';

import {
  SourceAdapter,
  SyncState,
  SyncResult,
  CanonicalNode,
  CanonicalEdge,
  SourceType,
} from '../../core/types.js';

import {
  getSlackDbPaths,
  isSlackCacheAvailable,
  slackTimestampToDate,
  dateToSlackTimestamp,
  QUERY_SCHEMA_PROBE,
  QUERY_MESSAGES,
  QUERY_CHANNELS,
  QUERY_USERS,
  RawSlackMessage,
  RawSlackChannel,
  RawSlackUser,
  getChannelType,
  extractMessageLatchTime,
  extractMessageLatchCategory,
  cleanSlackText,
  generateSlackMessageUrl,
} from './schema.js';

// =============================================================================
// Types
// =============================================================================

export type SlackDataSource = 'sqlite' | 'mcp' | 'none';

export interface SlackAdapterOptions {
  /** Prefer MCP even if SQLite is available */
  preferMcp?: boolean;
  /** Maximum messages to sync per channel */
  maxMessagesPerChannel?: number;
  /** Only sync messages newer than this */
  maxAgeDays?: number;
  /** MCP server URL (if using MCP fallback) */
  mcpServerUrl?: string;
}

// =============================================================================
// Adapter Implementation
// =============================================================================

export class SlackAdapter implements SourceAdapter {
  readonly sourceType: SourceType = 'manual'; // Using 'manual' since 'slack' isn't in union yet
  readonly displayName = 'Slack';
  
  private options: SlackAdapterOptions;
  private dataSource: SlackDataSource = 'none';
  private dbPaths: string[];
  private syncState: SyncState;
  
  // Caches for user/channel resolution
  private userCache = new Map<string, RawSlackUser>();
  private channelCache = new Map<string, RawSlackChannel>();
  
  constructor(options?: SlackAdapterOptions) {
    this.options = {
      maxMessagesPerChannel: 1000,
      maxAgeDays: 90,
      ...options,
    };
    this.dbPaths = getSlackDbPaths();
    this.syncState = { itemCount: 0 };
  }
  
  // ===========================================================================
  // SourceAdapter Interface
  // ===========================================================================
  
  async isAvailable(): Promise<boolean> {
    // Check SQLite first
    if (!this.options.preferMcp && isSlackCacheAvailable()) {
      this.dataSource = 'sqlite';
      return true;
    }
    
    // Check MCP availability
    if (this.options.mcpServerUrl) {
      // TODO: Ping MCP server to verify connectivity
      this.dataSource = 'mcp';
      return true;
    }
    
    // Check if MCP tools are available in environment
    // This would integrate with the MCP connector system
    const mcpAvailable = await this.checkMcpAvailability();
    if (mcpAvailable) {
      this.dataSource = 'mcp';
      return true;
    }
    
    this.dataSource = 'none';
    return false;
  }
  
  async fullSync(): Promise<SyncResult> {
    await this.isAvailable(); // Ensure data source is detected
    
    switch (this.dataSource) {
      case 'sqlite':
        return this.syncFromSqlite();
      case 'mcp':
        return this.syncFromMcp();
      default:
        return {
          nodes: [],
          edges: [],
          deletedIds: [],
          syncState: { itemCount: 0, lastError: 'No data source available' },
        };
    }
  }
  
  async incrementalSync(state: SyncState): Promise<SyncResult> {
    // For now, just do full sync
    // Incremental would track last message timestamp per channel
    return this.fullSync();
  }
  
  async getSyncState(): Promise<SyncState> {
    return this.syncState;
  }
  
  // ===========================================================================
  // SQLite Sync
  // ===========================================================================
  
  private async syncFromSqlite(): Promise<SyncResult> {
    const nodes: CanonicalNode[] = [];
    const edges: CanonicalEdge[] = [];
    let messageCount = 0;
    
    for (const dbPath of this.dbPaths) {
      if (!existsSync(dbPath)) continue;
      
      let db: Database.Database;
      try {
        db = new Database(dbPath, { readonly: true, fileMustExist: true });
      } catch (error) {
        console.warn(`Could not open Slack database at ${dbPath}:`, error);
        continue;
      }
      
      try {
        // Probe schema to see what tables are available
        const tables = this.probeSchema(db);
        
        if (!tables.has('messages')) {
          console.warn(`No messages table in ${dbPath}`);
          continue;
        }
        
        // Load users if available
        if (tables.has('users')) {
          this.loadUsers(db);
        }
        
        // Load channels if available
        if (tables.has('channels')) {
          const channelNodes = this.loadChannels(db);
          nodes.push(...channelNodes);
        }
        
        // Load messages
        const { messageNodes, messageEdges } = this.loadMessages(db);
        nodes.push(...messageNodes);
        edges.push(...messageEdges);
        messageCount += messageNodes.length;
        
      } finally {
        db.close();
      }
    }
    
    this.syncState = {
      lastSync: new Date(),
      watermark: dateToSlackTimestamp(new Date()),
      itemCount: messageCount,
    };
    
    return {
      nodes,
      edges,
      deletedIds: [],
      syncState: this.syncState,
    };
  }
  
  private probeSchema(db: Database.Database): Set<string> {
    const tables = new Set<string>();
    try {
      const rows = db.prepare(QUERY_SCHEMA_PROBE).all() as { name: string }[];
      for (const row of rows) {
        tables.add(row.name.toLowerCase());
      }
    } catch {
      // Schema probe failed
    }
    return tables;
  }
  
  private loadUsers(db: Database.Database): void {
    try {
      const users = db.prepare(QUERY_USERS).all() as RawSlackUser[];
      for (const user of users) {
        this.userCache.set(user.id, user);
      }
    } catch {
      // Users table might have different schema
    }
  }
  
  private loadChannels(db: Database.Database): CanonicalNode[] {
    const nodes: CanonicalNode[] = [];
    
    try {
      const channels = db.prepare(QUERY_CHANNELS).all() as RawSlackChannel[];
      
      for (const channel of channels) {
        this.channelCache.set(channel.id, channel);
        
        const channelType = getChannelType(channel);
        
        nodes.push({
          id: `slack:channel:${channel.id}`,
          source: 'manual', // Would be 'slack'
          sourceId: channel.id,
          nodeType: 'project',
          name: channel.name || `${channelType}:${channel.id}`,
          content: channel.purpose || channel.topic || undefined,
          time: {
            created: channel.created 
              ? new Date(channel.created * 1000) 
              : new Date(),
            modified: new Date(),
          },
          category: {
            hierarchy: ['Slack'],
            tags: [channelType],
            status: channel.is_archived ? 'archived' : 'active',
          },
          hierarchy: {
            priority: 0,
            importance: 0,
            sortOrder: 0,
          },
          sourceMeta: {
            channelType,
            isPrivate: channel.is_private === 1,
          },
        });
      }
    } catch {
      // Channels table might have different schema
    }
    
    return nodes;
  }
  
  private loadMessages(db: Database.Database): {
    messageNodes: CanonicalNode[];
    messageEdges: CanonicalEdge[];
  } {
    const nodes: CanonicalNode[] = [];
    const edges: CanonicalEdge[] = [];
    
    try {
      const limit = this.options.maxMessagesPerChannel || 1000;
      const messages = db.prepare(QUERY_MESSAGES).all(limit) as RawSlackMessage[];
      
      for (const msg of messages) {
        const time = extractMessageLatchTime(msg);
        
        // Skip old messages if maxAgeDays is set
        if (this.options.maxAgeDays) {
          const maxAge = new Date();
          maxAge.setDate(maxAge.getDate() - this.options.maxAgeDays);
          if (time.created < maxAge) continue;
        }
        
        const channel = this.channelCache.get(msg.channel_id || '');
        const user = this.userCache.get(msg.user_id || '');
        
        const cleanContent = cleanSlackText(msg.content || '');
        const title = cleanContent.split('\n')[0]?.slice(0, 100) || 'Message';
        
        const category = extractMessageLatchCategory(
          msg,
          channel?.name || undefined,
          'Slack' // workspace name would go here
        );
        
        const node: CanonicalNode = {
          id: `slack:message:${msg.id}`,
          source: 'manual',
          sourceId: msg.id,
          nodeType: 'note',
          name: title,
          content: cleanContent,
          time,
          category,
          hierarchy: {
            priority: 0,
            importance: 0,
            sortOrder: 0,
          },
          sourceMeta: {
            userId: msg.user_id,
            userName: user?.display_name || user?.real_name || user?.name,
            channelId: msg.channel_id,
            channelName: channel?.name,
            threadId: msg.thread_id,
          },
        };
        
        nodes.push(node);
        
        // Create NEST edge from channel to message
        if (msg.channel_id) {
          edges.push({
            id: `nest:slack:channel:${msg.channel_id}:${node.id}`,
            edgeType: 'NEST',
            sourceId: `slack:channel:${msg.channel_id}`,
            targetId: node.id,
            weight: 1.0,
            directed: true,
          });
        }
        
        // Create SEQUENCE edge for thread replies
        if (msg.thread_id && msg.thread_id !== msg.id) {
          edges.push({
            id: `sequence:slack:message:${msg.thread_id}:${node.id}`,
            edgeType: 'SEQUENCE',
            sourceId: `slack:message:${msg.thread_id}`,
            targetId: node.id,
            weight: 1.0,
            directed: true,
            timestamp: time.created,
          });
        }
        
        // Create LINK edge to user (if we had contacts)
        if (msg.user_id) {
          edges.push({
            id: `link:${node.id}:slack:user:${msg.user_id}`,
            edgeType: 'LINK',
            sourceId: node.id,
            targetId: `slack:user:${msg.user_id}`,
            label: 'sent by',
            weight: 1.0,
            directed: true,
          });
        }
      }
    } catch (error) {
      console.warn('Error loading Slack messages:', error);
    }
    
    return { messageNodes: nodes, messageEdges: edges };
  }
  
  // ===========================================================================
  // MCP Fallback
  // ===========================================================================
  
  private async checkMcpAvailability(): Promise<boolean> {
    // This would check if Slack MCP server is configured
    // For now, return false - MCP integration is a future enhancement
    return false;
  }
  
  private async syncFromMcp(): Promise<SyncResult> {
    // MCP sync implementation
    // This would use the Slack MCP connector to fetch data
    
    console.log('MCP sync not yet implemented - falling back to empty result');
    
    return {
      nodes: [],
      edges: [],
      deletedIds: [],
      syncState: {
        itemCount: 0,
        lastError: 'MCP sync not yet implemented',
      },
    };
    
    // Future implementation would:
    // 1. Call MCP tool: slack_list_channels
    // 2. For each channel, call: slack_get_channel_history
    // 3. Transform to CanonicalNode format
    // 4. Build edges for threads and mentions
  }
  
  // ===========================================================================
  // Utility Methods
  // ===========================================================================
  
  /**
   * Get the current data source being used
   */
  getDataSource(): SlackDataSource {
    return this.dataSource;
  }
  
  /**
   * Force a specific data source (for testing)
   */
  setDataSource(source: SlackDataSource): void {
    this.dataSource = source;
  }
}

// =============================================================================
// Factory Function
// =============================================================================

export function createSlackAdapter(options?: SlackAdapterOptions): SlackAdapter {
  return new SlackAdapter(options);
}

// =============================================================================
// CLI Usage
// =============================================================================

if (import.meta.url === `file://${process.argv[1]}`) {
  const adapter = createSlackAdapter({
    maxMessagesPerChannel: 100,
    maxAgeDays: 30,
  });
  
  (async () => {
    console.log('Slack ETL Adapter');
    console.log('=================\n');
    
    const available = await adapter.isAvailable();
    console.log(`Available: ${available}`);
    console.log(`Data source: ${adapter.getDataSource()}`);
    
    if (!available) {
      console.log('\nSlack data not accessible.');
      console.log('Options:');
      console.log('  1. Install Slack desktop app and log in');
      console.log('  2. Configure Slack MCP server');
      process.exit(1);
    }
    
    console.log('\nRunning sync...\n');
    
    const result = await adapter.fullSync();
    
    console.log(`Nodes extracted: ${result.nodes.length}`);
    console.log(`  - Channels: ${result.nodes.filter(n => n.nodeType === 'project').length}`);
    console.log(`  - Messages: ${result.nodes.filter(n => n.nodeType === 'note').length}`);
    console.log(`Edges created: ${result.edges.length}`);
    
    // Show sample
    const sampleMessage = result.nodes.find(n => n.nodeType === 'note');
    if (sampleMessage) {
      console.log('\nSample message:');
      console.log(`  Content: ${sampleMessage.name}`);
      console.log(`  Channel: ${sampleMessage.category.hierarchy.join('/')}`);
      console.log(`  From: ${(sampleMessage.sourceMeta as any)?.userName || 'unknown'}`);
    }
  })();
}
