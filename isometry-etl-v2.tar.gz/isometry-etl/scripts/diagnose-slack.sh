#!/bin/bash

# Diagnose Slack local cache
# Checks for available databases and probes schema

echo "=== Slack Local Cache Diagnostic ==="
echo ""

# Possible Slack database locations
LOCATIONS=(
    "$HOME/Library/Application Support/Slack/storage"
    "$HOME/Library/Containers/com.tinyspeck.slackmacgap/Data/Library/Application Support/Slack/storage"
    "$HOME/Library/Application Support/Slack/IndexedDB"
)

FOUND_DBS=()

echo "Searching for Slack databases..."
echo ""

for loc in "${LOCATIONS[@]}"; do
    if [[ -d "$loc" ]]; then
        echo "Found directory: $loc"
        
        # List database files
        while IFS= read -r -d '' file; do
            FOUND_DBS+=("$file")
            SIZE=$(du -h "$file" 2>/dev/null | cut -f1)
            echo "  - $(basename "$file") ($SIZE)"
        done < <(find "$loc" -name "*.db" -o -name "*.sqlite" -print0 2>/dev/null)
    fi
done

echo ""

if [[ ${#FOUND_DBS[@]} -eq 0 ]]; then
    echo "No Slack databases found."
    echo ""
    echo "Possible reasons:"
    echo "  1. Slack desktop app not installed"
    echo "  2. Not logged into any workspaces"
    echo "  3. Using web-only Slack"
    echo ""
    echo "Fallback: Configure Slack MCP connector for API access"
    exit 1
fi

echo "--- Analyzing first database ---"
SLACK_DB="${FOUND_DBS[0]}"
echo "Database: $SLACK_DB"
echo ""

echo "--- Available Tables ---"
sqlite3 "$SLACK_DB" "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name;" 2>/dev/null

echo ""
echo "--- Schema Probe ---"

# Check for common tables
for table in messages channels users conversations teams; do
    if sqlite3 "$SLACK_DB" "SELECT 1 FROM $table LIMIT 1;" 2>/dev/null; then
        COUNT=$(sqlite3 "$SLACK_DB" "SELECT COUNT(*) FROM $table;" 2>/dev/null)
        echo "$table: $COUNT rows"
    fi
done

echo ""
echo "--- Messages Sample (if available) ---"
sqlite3 -header -column "$SLACK_DB" <<'SQL' 2>/dev/null
SELECT 
    substr(text, 1, 50) as message_preview,
    user as user_id,
    channel as channel_id,
    datetime(CAST(ts AS REAL), 'unixepoch', 'localtime') as timestamp
FROM messages
WHERE type = 'message'
ORDER BY ts DESC
LIMIT 5;
SQL

echo ""
echo "--- Channels Sample (if available) ---"
sqlite3 -header -column "$SLACK_DB" <<'SQL' 2>/dev/null
SELECT 
    name,
    CASE 
        WHEN is_im = 1 THEN 'DM'
        WHEN is_mpim = 1 THEN 'Group DM'
        WHEN is_private = 1 THEN 'Private'
        ELSE 'Public'
    END as type
FROM channels
WHERE is_archived = 0 OR is_archived IS NULL
LIMIT 10;
SQL

echo ""
echo "--- Users Sample (if available) ---"
sqlite3 -header -column "$SLACK_DB" <<'SQL' 2>/dev/null
SELECT 
    name,
    real_name,
    CASE WHEN is_bot = 1 THEN 'Bot' ELSE 'Human' END as type
FROM users
WHERE deleted = 0 OR deleted IS NULL
LIMIT 10;
SQL

echo ""
echo "=== Diagnostic complete ==="
echo ""
echo "Note: Slack's local cache schema varies by version."
echo "If tables are missing, the MCP fallback will be used."
