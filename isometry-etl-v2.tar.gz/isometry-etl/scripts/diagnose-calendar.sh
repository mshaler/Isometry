#!/bin/bash

# Diagnose Apple Calendar database structure
# Validates schema and shows sample data

echo "=== Apple Calendar Database Diagnostic ==="
echo ""

CALENDAR_DB="$HOME/Library/Calendars/Calendar Cache"

if [[ ! -f "$CALENDAR_DB" ]]; then
    echo "Error: Calendar Cache not found"
    echo "Path checked: $CALENDAR_DB"
    exit 1
fi

echo "Database: $CALENDAR_DB"
echo "Size: $(du -h "$CALENDAR_DB" | cut -f1)"
echo ""

echo "--- Table List ---"
sqlite3 "$CALENDAR_DB" "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"

echo ""
echo "--- Calendar List ---"
sqlite3 -header -column "$CALENDAR_DB" <<'SQL'
SELECT 
    c.ZTITLE as calendar_name,
    c.ZSYMBOLICCOLORNAME as color,
    n.ZTITLE as account,
    COUNT(ci.Z_PK) as event_count
FROM ZCALENDAR c
LEFT JOIN ZNODE n ON c.ZNODE = n.Z_PK
LEFT JOIN ZCALENDARITEM ci ON ci.ZCALENDAR = c.Z_PK AND ci.ZENTITYTYPE = 1
WHERE c.ZMARKEDFORDELETION IS NULL OR c.ZMARKEDFORDELETION = 0
GROUP BY c.Z_PK
ORDER BY event_count DESC;
SQL

echo ""
echo "--- Upcoming Events (next 10) ---"
sqlite3 -header -column "$CALENDAR_DB" <<'SQL'
SELECT 
    ci.ZTITLE as event,
    c.ZTITLE as calendar,
    datetime(ci.ZSTARTDATE + 978307200, 'unixepoch', 'localtime') as start_time,
    CASE WHEN ci.ZALLDAY = 1 THEN 'Yes' ELSE 'No' END as all_day,
    l.ZTITLE as location
FROM ZCALENDARITEM ci
LEFT JOIN ZCALENDAR c ON ci.ZCALENDAR = c.Z_PK
LEFT JOIN ZLOCATION l ON ci.ZLOCATION = l.Z_PK
WHERE ci.ZENTITYTYPE = 1
  AND ci.ZSTARTDATE > (strftime('%s', 'now') - 978307200)
  AND (ci.ZMARKEDFORDELETION IS NULL OR ci.ZMARKEDFORDELETION = 0)
ORDER BY ci.ZSTARTDATE ASC
LIMIT 10;
SQL

echo ""
echo "--- Events with Locations (sample) ---"
sqlite3 -header -column "$CALENDAR_DB" <<'SQL'
SELECT 
    ci.ZTITLE as event,
    l.ZTITLE as location_name,
    l.ZADDRESS as address,
    l.ZLATITUDE as lat,
    l.ZLONGITUDE as lng
FROM ZCALENDARITEM ci
JOIN ZLOCATION l ON ci.ZLOCATION = l.Z_PK
WHERE ci.ZENTITYTYPE = 1
  AND l.ZTITLE IS NOT NULL
  AND (ci.ZMARKEDFORDELETION IS NULL OR ci.ZMARKEDFORDELETION = 0)
ORDER BY ci.ZSTARTDATE DESC
LIMIT 10;
SQL

echo ""
echo "--- Recurring Events Count ---"
sqlite3 -header -column "$CALENDAR_DB" <<'SQL'
SELECT 
    COUNT(*) as recurring_events
FROM ZCALENDARITEM ci
WHERE ci.ZENTITYTYPE = 1
  AND ci.ZRECURRENCERULE IS NOT NULL
  AND (ci.ZMARKEDFORDELETION IS NULL OR ci.ZMARKEDFORDELETION = 0);
SQL

echo ""
echo "--- Schema: ZCALENDARITEM columns ---"
sqlite3 "$CALENDAR_DB" "PRAGMA table_info(ZCALENDARITEM);" | grep -iE "title|date|location|calendar|recurrence|attendee|status"

echo ""
echo "--- Schema: ZLOCATION columns ---"
sqlite3 "$CALENDAR_DB" "PRAGMA table_info(ZLOCATION);" 2>/dev/null || echo "(ZLOCATION table not found)"

echo ""
echo "=== Diagnostic complete ==="
