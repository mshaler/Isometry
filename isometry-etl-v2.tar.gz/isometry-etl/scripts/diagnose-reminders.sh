#!/bin/bash

# Diagnose Apple Reminders database structure
# Validates schema and shows sample data

echo "=== Apple Reminders Database Diagnostic ==="
echo ""

# Find Reminders databases
STORES_DIR="$HOME/Library/Reminders/Container_v1/Stores"

if [[ ! -d "$STORES_DIR" ]]; then
    echo "Error: Reminders store directory not found"
    echo "Path checked: $STORES_DIR"
    exit 1
fi

# Find all .sqlite files
DB_FILES=$(find "$STORES_DIR" -name "*.sqlite" 2>/dev/null)

if [[ -z "$DB_FILES" ]]; then
    echo "Error: No SQLite databases found in $STORES_DIR"
    exit 1
fi

echo "Found databases:"
echo "$DB_FILES"
echo ""

# Use first database for analysis
REMINDERS_DB=$(echo "$DB_FILES" | head -1)
echo "Analyzing: $REMINDERS_DB"
echo ""

echo "--- Table List ---"
sqlite3 "$REMINDERS_DB" "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"

echo ""
echo "--- Reminder Count by List ---"
sqlite3 -header -column "$REMINDERS_DB" <<'SQL'
SELECT 
    l.ZTITLE as list_name,
    COUNT(r.Z_PK) as reminder_count,
    SUM(CASE WHEN r.ZCOMPLETIONDATE IS NOT NULL THEN 1 ELSE 0 END) as completed,
    SUM(CASE WHEN r.ZDUEDATE IS NOT NULL AND r.ZCOMPLETIONDATE IS NULL THEN 1 ELSE 0 END) as with_due_date
FROM ZREMCDLIST l
LEFT JOIN ZREMCDREMINDER r ON r.ZLIST = l.Z_PK
WHERE l.ZMARKEDFORDELETION IS NULL OR l.ZMARKEDFORDELETION = 0
GROUP BY l.Z_PK
ORDER BY reminder_count DESC
LIMIT 15;
SQL

echo ""
echo "--- Recent Reminders (last 10 modified) ---"
sqlite3 -header -column "$REMINDERS_DB" <<'SQL'
SELECT 
    r.ZTITLE as title,
    l.ZTITLE as list,
    CASE r.ZPRIORITY 
        WHEN 1 THEN 'High'
        WHEN 5 THEN 'Medium'
        WHEN 9 THEN 'Low'
        ELSE 'None'
    END as priority,
    CASE WHEN r.ZCOMPLETIONDATE IS NOT NULL THEN 'Done' ELSE 'Open' END as status,
    datetime(r.ZMODIFICATIONDATE + 978307200, 'unixepoch', 'localtime') as modified
FROM ZREMCDREMINDER r
LEFT JOIN ZREMCDLIST l ON r.ZLIST = l.Z_PK
WHERE r.ZMARKEDFORDELETION IS NULL OR r.ZMARKEDFORDELETION = 0
ORDER BY r.ZMODIFICATIONDATE DESC
LIMIT 10;
SQL

echo ""
echo "--- Subtasks Sample ---"
sqlite3 -header -column "$REMINDERS_DB" <<'SQL'
SELECT 
    p.ZTITLE as parent_reminder,
    COUNT(s.Z_PK) as subtask_count
FROM ZREMCDREMINDER p
JOIN ZREMCDREMINDER s ON s.ZPARENTREMINDER = p.Z_PK
WHERE p.ZMARKEDFORDELETION IS NULL OR p.ZMARKEDFORDELETION = 0
GROUP BY p.Z_PK
HAVING subtask_count > 0
ORDER BY subtask_count DESC
LIMIT 5;
SQL

echo ""
echo "--- Schema: ZREMCDREMINDER columns ---"
sqlite3 "$REMINDERS_DB" "PRAGMA table_info(ZREMCDREMINDER);" | grep -iE "title|date|priority|flag|list|parent|order|status"

echo ""
echo "=== Diagnostic complete ==="
