# CardBoard Architecture Truth: PAFV + LATCH + GRAPH

*December 2024*

This document captures the foundational taxonomy for CardBoard's polymorphic data visualization architecture.

---

## The Three Layers

| Layer | Purpose | Operations |
|-------|---------|------------|
| **PAFV** | Spatial projection | Map logical organization to screen coordinates |
| **LATCH** | Separation | Filter, sort, group (nodes AND edges) |
| **GRAPH** | Connection | Traverse, aggregate, cluster |

All three operate on **Values** (Cards), which include both Nodes and Edges.

---

## PAFV: Planes â†’ Axes â†’ Facets â†’ Values

PAFV resolves the semantic confusion between "dimensions" and "categories" by establishing clear hierarchical layers:

### Planes (Spatial Projection)
The x/y/z coordinate system for visual rendering:
- **x-plane**: Horizontal organization (columns)
- **y-plane**: Vertical organization (rows)
- **z-plane**: Depth/layering organization (sheets/cards)

### Axes (Logical Organization - LATCH)
The five fundamental organizing principles:
- **L**ocation: Spatial position (coordinates, geography)
- **A**lphabet: Lexical naming (Aâ†’Z, titles, labels)
- **T**ime: Temporal position (created, due, modified)
- **C**ategory: Taxonomic membership (project, status, tags)
- **H**ierarchy: Ordinal ranking (priority 1-5, importance)

### Facets (Specific Attributes)
Concrete implementations within each axis:
- Time axis â†’ facets: `created_date`, `due_date`, `modified_date`
- Category axis â†’ facets: `project`, `status`, `tags`

### Values (Cards)
The atomic data unitsâ€”both Nodes and Edges in LPG model.

### Key Insight
**Any axis can map to any plane.** View transitions are simply remapping axes to planes, not rebuilding data structures.

---

## LATCH vs GRAPH: The Fundamental Duality

This is the core architectural insight: **LATCH separates, GRAPH joins.**

| | LATCH | GRAPH |
|---|---|---|
| **Operation** | Separation | Connection |
| **SQL analog** | `WHERE`, `GROUP BY`, `ORDER BY` | `JOIN` |
| **Set theory** | Partition | Union/Intersection |
| **Question** | "How do I organize these?" | "How are these related?" |
| **D3 pattern** | Scales, axes, grouping | Force simulation, links |

### LATCH Views (Separation)
- **Grid**: Separate by two axes mapped to x/y planes
- **List**: Separate by one axis
- **Calendar**: Separate by time axis
- **Kanban**: Separate by category axis (status)

### GRAPH Views (Connection)
- **Network**: Connect by explicit links
- **Tree**: Connect by containment hierarchy
- **Sankey**: Connect by flow/sequence

### Polymorphic Implication
Every Card exists in **both** spaces simultaneously:
- It has **LATCH coordinates** (when, what category, what priority)
- It has **GRAPH edges** (linked to, contained by, depends on)

The polymorphic view switch isn't changing the dataâ€”it's choosing whether to **separate** or **join** the same underlying Values.

---

## Values: The LPG Model

CardBoard uses Labeled Property Graph (LPG) semantics implemented in SQLite. The key insight: **Edges are Cards too.**

```
Values (Cards) bifurcate into:
â”œâ”€â”€ Nodes: Person, Project, Document, Event
â””â”€â”€ Edges: Message, Mention, Dependency, Containment
```

### Why Edges as Cards?

Traditional graphs treat edges as dumb connectors. LPG gives edges properties:

```
Michael â”€â”€[Email: "Re: Q3 planning", 2024-11-15]â”€â”€> Sarah
Michael â”€â”€[Slack: "quick question", 2024-11-18]â”€â”€> Sarah
```

Each edge IS the message, with properties: channel, timestamp, subject, sentiment.

### LATCH Applies to Both
- Filter nodes: people in "Sales" category
- Filter edges: messages from "last 30 days" on "Slack" channel

### SQLite Implementation

```sql
-- Nodes
CREATE TABLE persons (
    id TEXT PRIMARY KEY,
    name TEXT,
    location TEXT,
    category TEXT,
    priority INTEGER
);

-- Edges (messages as first-class cards)
CREATE TABLE messages (
    id TEXT PRIMARY KEY,
    sender_id TEXT REFERENCES persons(id),
    receiver_id TEXT REFERENCES persons(id),
    channel TEXT,
    timestamp TEXT,
    subject TEXT,
    category TEXT,
    priority INTEGER
);
```

---

## Architecture Decision: No Graph Database

KuzuDB and similar graph databases are **removed** from the architecture.

### Rationale

| Capability | Implementation |
|------------|----------------|
| Store nodes + edges | SQLite tables with foreign keys |
| LATCH filtering | Standard SQL `WHERE`, `GROUP BY` |
| Path finding | SQLite recursive CTE |
| Degree centrality | `COUNT(*) GROUP BY` |
| PageRank, clustering | D3.js on filtered subset |

### Scale Boundaries

| Data Type | Volume | Location |
|-----------|--------|----------|
| Message bodies | GB | SQLite (content) |
| Graph structure | MB | SQLite (nodes/edges) â†’ D3 (algorithms) |

Complex graph algorithms run in D3/JavaScript on filtered subsets (MB scale), not on full database (GB scale).

### The Workflow

```
SQLite                      D3.js
â”€â”€â”€â”€â”€â”€â”€                     â”€â”€â”€â”€â”€
Store everything     â†’      Query filtered subset
LATCH filtering      â†’      Receive JSON
Simple graph queries â†’      Force simulation
Aggregations         â†’      PageRank, clustering
                            Render + interact
```

**The boring stack wins.**

---

## Person Card Example (LPG in Action)

A Person Card becomes a node-centric view with edge summaries:

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚ Sarah Chen                     [â˜…]  â”‚
â”‚ VP Engineering @ Acme              â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Connection Path: You â†’ Mike â†’ Sarah â”‚
â”‚ Relationship Strength: â–ˆâ–ˆâ–ˆâ–ˆâ–‘â–‘ 47    â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ Recent (Top 10 edges by time)       â”‚
â”‚ â€¢ 11/20 LinkedIn: "congrats on..."  â”‚
â”‚ â€¢ 11/18 Slack: "quick question..."  â”‚
â”‚ â€¢ 11/15 Email: "Re: Q3 planning..." â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚ By Channel                          â”‚
â”‚ Email: 34  Slack: 28  Text: 12     â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

Same data renders as:
- **Grid**: Messages as rows (LATCH separation by time/channel)
- **Person Card**: Node with embedded edge summary
- **Network**: Visual edges between people (GRAPH connection)
- **Timeline**: Edges projected onto time axis (PAFV)

---

## Summary

| Concept | Definition |
|---------|------------|
| **PAFV** | Planes â†’ Axes â†’ Facets â†’ Values (spatial projection) |
| **LATCH** | Location, Alphabet, Time, Category, Hierarchy (separation) |
| **GRAPH** | Links, Nesting, Sequence (connection) |
| **Values** | Cards = Nodes + Edges (LPG in SQLite) |
| **Stack** | SQLite + D3.js (no graph database) |

---

## Key Principles

1. **LATCH separates, GRAPH joins** â€” fundamental duality
2. **Edges are Cards** â€” LPG semantics without graph DB overhead
3. **Any axis maps to any plane** â€” view transitions are remappings
4. **Scale-appropriate** â€” complex algorithms run in D3 on filtered subsets
5. **Boring stack wins** â€” SQLite + D3.js covers the use case
