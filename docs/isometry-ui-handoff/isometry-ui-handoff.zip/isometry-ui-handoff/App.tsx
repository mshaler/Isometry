import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { Toolbar } from './components/Toolbar';
import { Navigator } from './components/Navigator';
import { Sidebar } from './components/Sidebar';
import { RightSidebar } from './components/RightSidebar';
import { Canvas } from './components/Canvas';
import { NavigatorFooter } from './components/NavigatorFooter';
import { CommandBar } from './components/CommandBar';

function AppLayout() {
  const { theme } = useTheme();
  
  return (
    <div className={`h-screen flex flex-col ${
      theme === 'NeXTSTEP' 
        ? 'bg-[#808080]' 
        : 'bg-gradient-to-br from-gray-100 to-gray-200'
    }`}>
      {/* Top: Menu Bar + Toolbar */}
      <Toolbar />
      
      {/* Navigation Bar + PAFV Navigator */}
      <Navigator />
      
      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar: Filters + Templates */}
        <Sidebar />
        
        {/* Center: Canvas */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <Canvas />
          
          {/* Bottom: Location Map / Time Slider */}
          <NavigatorFooter />
        </div>
        
        {/* Right Sidebar: Formats + Settings */}
        <RightSidebar />
      </div>
      
      {/* Bottom: Command Bar */}
      <CommandBar />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppLayout />
    </ThemeProvider>
  );
}
