// Mock Apple Notes database with ~80 properties classified into LATCH axes

export type LatchAxis = 'L' | 'A' | 'T' | 'C' | 'H' | 'GRAPH';

export interface Property {
  id: string;
  rawName: string;
  displayName: string;
  axis: LatchAxis;
  type: 'text' | 'date' | 'number' | 'select' | 'location';
  checked: boolean;
}

export interface Note {
  id: string;
  title: string;
  folder: string;
  tags: string[];
  created: Date;
  modified: Date;
  priority: number;
  status: string;
  location?: string;
  noteType: string;
  summary: string;
}

export const LATCH_COLUMNS = [
  { key: 'L', label: 'Location', color: '#4A90D9', icon: '📍' },
  { key: 'A', label: 'Alphabet', color: '#7CB342', icon: '🔤' },
  { key: 'T', label: 'Time', color: '#FF9800', icon: '⏱' },
  { key: 'C', label: 'Category', color: '#9C27B0', icon: '🏷' },
  { key: 'H', label: 'Hierarchy', color: '#E53935', icon: '📊' },
  { key: 'GRAPH', label: 'Graph', color: '#78909C', icon: '🔗' },
] as const;

export const PROPERTIES: Property[] = [
  // Location (L)
  { id: 'loc_1', rawName: 'ZLOCATIONNAME', displayName: '📍 Location Name', axis: 'L', type: 'location', checked: true },
  { id: 'loc_2', rawName: 'ZADDRESS', displayName: 'Address', axis: 'L', type: 'text', checked: false },
  { id: 'loc_3', rawName: 'ZLATITUDE', displayName: 'Latitude', axis: 'L', type: 'number', checked: false },
  { id: 'loc_4', rawName: 'ZLONGITUDE', displayName: 'Longitude', axis: 'L', type: 'number', checked: false },
  
  // Alphabet (A)
  { id: 'alph_1', rawName: 'ZTITLE2', displayName: 'Title', axis: 'A', type: 'text', checked: true },
  { id: 'alph_2', rawName: 'ZSUMMARY', displayName: 'Summary', axis: 'A', type: 'text', checked: false },
  { id: 'alph_3', rawName: 'ZSOURCE', displayName: 'Source', axis: 'A', type: 'text', checked: false },
  
  // Time (T)
  { id: 'time_1', rawName: 'ZINCEPTIONTIMESTAMP', displayName: '📅 Created', axis: 'T', type: 'date', checked: true },
  { id: 'time_2', rawName: 'ZMODIFICATIONDATE', displayName: '📅 Modified', axis: 'T', type: 'date', checked: true },
  { id: 'time_3', rawName: 'ZDUEDATE', displayName: 'Due Date', axis: 'T', type: 'date', checked: false },
  { id: 'time_4', rawName: 'ZEVENTSTART', displayName: 'Event Start', axis: 'T', type: 'date', checked: false },
  { id: 'time_5', rawName: 'ZEVENTEND', displayName: 'Event End', axis: 'T', type: 'date', checked: false },
  { id: 'time_6', rawName: 'ZCOMPLETED', displayName: 'Completed', axis: 'T', type: 'date', checked: false },
  
  // Category (C)
  { id: 'cat_1', rawName: 'ZFOLDER', displayName: '📁 Folder', axis: 'C', type: 'select', checked: true },
  { id: 'cat_2', rawName: 'ZTAGS', displayName: 'Tags', axis: 'C', type: 'select', checked: true },
  { id: 'cat_3', rawName: 'ZSTATUS', displayName: 'Status', axis: 'C', type: 'select', checked: false },
  { id: 'cat_4', rawName: 'ZNOTETYPE', displayName: 'Note Type', axis: 'C', type: 'select', checked: true },
  { id: 'cat_5', rawName: 'ZSOURCEAPP', displayName: 'Source App', axis: 'C', type: 'select', checked: false },
  
  // Hierarchy (H)
  { id: 'hier_1', rawName: 'ZPRIORITY', displayName: 'Priority', axis: 'H', type: 'number', checked: true },
  { id: 'hier_2', rawName: 'ZIMPORTANCE', displayName: 'Importance', axis: 'H', type: 'number', checked: false },
  { id: 'hier_3', rawName: 'ZSORTORDER', displayName: 'Sort Order', axis: 'H', type: 'number', checked: false },
  
  // Graph (GRAPH)
  { id: 'graph_1', rawName: 'ZLINKS', displayName: 'Links', axis: 'GRAPH', type: 'text', checked: true },
  { id: 'graph_2', rawName: 'ZNESTING', displayName: 'Nesting', axis: 'GRAPH', type: 'text', checked: false },
  { id: 'graph_3', rawName: 'ZSEQUENCE', displayName: 'Sequence', axis: 'GRAPH', type: 'text', checked: false },
  { id: 'graph_4', rawName: 'ZAFFINITY', displayName: 'Affinity', axis: 'GRAPH', type: 'text', checked: false },
];

// Generate mock notes data
export const MOCK_NOTES: Note[] = [
  // Q1 2024
  { id: 'n1', title: 'Project Kickoff Notes', folder: 'Work', tags: ['meeting', 'project'], created: new Date('2024-01-15'), modified: new Date('2024-01-20'), priority: 5, status: 'Active', noteType: 'Meeting', summary: 'Initial project planning session' },
  { id: 'n2', title: 'Design System Research', folder: 'Work', tags: ['design', 'research'], created: new Date('2024-01-22'), modified: new Date('2024-02-01'), priority: 4, status: 'Active', noteType: 'Research', summary: 'NeXTSTEP design patterns' },
  { id: 'n3', title: 'Shopping List', folder: 'Personal', tags: ['errands'], created: new Date('2024-02-05'), modified: new Date('2024-02-05'), priority: 2, status: 'Completed', noteType: 'List', summary: 'Weekly groceries' },
  { id: 'n4', title: 'API Documentation Draft', folder: 'Work', tags: ['documentation', 'api'], created: new Date('2024-02-14'), modified: new Date('2024-02-20'), priority: 4, status: 'In Progress', noteType: 'Documentation', summary: 'REST API endpoints' },
  { id: 'n5', title: 'Book Recommendations', folder: 'Personal', tags: ['reading', 'books'], created: new Date('2024-03-01'), modified: new Date('2024-03-10'), priority: 1, status: 'Active', noteType: 'List', summary: 'To-read list for 2024' },
  { id: 'n6', title: 'Sprint Planning Q1', folder: 'Work', tags: ['meeting', 'planning'], created: new Date('2024-03-15'), modified: new Date('2024-03-15'), priority: 5, status: 'Completed', noteType: 'Meeting', summary: 'Q1 retrospective and Q2 planning' },
  
  // Q2 2024
  { id: 'n7', title: 'User Interview Notes', folder: 'Work', tags: ['research', 'ux'], created: new Date('2024-04-02'), modified: new Date('2024-04-05'), priority: 4, status: 'Active', noteType: 'Research', summary: 'User feedback session' },
  { id: 'n8', title: 'Vacation Planning', folder: 'Personal', tags: ['travel', 'planning'], created: new Date('2024-04-12'), modified: new Date('2024-05-01'), priority: 3, status: 'In Progress', noteType: 'Planning', summary: 'Summer trip itinerary' },
  { id: 'n9', title: 'Database Schema Design', folder: 'Work', tags: ['database', 'architecture'], created: new Date('2024-05-08'), modified: new Date('2024-05-15'), priority: 5, status: 'Active', noteType: 'Technical', summary: 'LATCH classification schema' },
  { id: 'n10', title: 'Recipe Collection', folder: 'Personal', tags: ['cooking', 'recipes'], created: new Date('2024-05-20'), modified: new Date('2024-06-01'), priority: 1, status: 'Active', noteType: 'List', summary: 'Favorite dishes' },
  { id: 'n11', title: 'Team Standup 2024-06-10', folder: 'Work', tags: ['meeting', 'standup'], created: new Date('2024-06-10'), modified: new Date('2024-06-10'), priority: 3, status: 'Completed', noteType: 'Meeting', summary: 'Daily sync' },
  { id: 'n12', title: 'Component Library Audit', folder: 'Work', tags: ['design', 'frontend'], created: new Date('2024-06-18'), modified: new Date('2024-06-25'), priority: 4, status: 'In Progress', noteType: 'Technical', summary: 'Review existing components' },
  
  // Q3 2024
  { id: 'n13', title: 'Conference Talk Ideas', folder: 'Work', tags: ['speaking', 'conference'], created: new Date('2024-07-03'), modified: new Date('2024-07-10'), priority: 3, status: 'Active', noteType: 'Brainstorm', summary: 'Potential topics for fall conference' },
  { id: 'n14', title: 'Home Improvement Projects', folder: 'Personal', tags: ['home', 'diy'], created: new Date('2024-07-15'), modified: new Date('2024-08-01'), priority: 2, status: 'In Progress', noteType: 'List', summary: 'Renovations and repairs' },
  { id: 'n15', title: 'Performance Optimization Report', folder: 'Work', tags: ['performance', 'technical'], created: new Date('2024-08-05'), modified: new Date('2024-08-12'), priority: 5, status: 'Active', noteType: 'Technical', summary: 'Grid rendering benchmarks' },
  { id: 'n16', title: 'Gift Ideas', folder: 'Personal', tags: ['shopping', 'gifts'], created: new Date('2024-08-20'), modified: new Date('2024-08-20'), priority: 1, status: 'Active', noteType: 'List', summary: 'Birthday and holiday gifts' },
  { id: 'n17', title: 'Client Presentation Deck', folder: 'Work', tags: ['presentation', 'client'], created: new Date('2024-09-02'), modified: new Date('2024-09-10'), priority: 5, status: 'Completed', noteType: 'Presentation', summary: 'Q3 deliverables showcase' },
  { id: 'n18', title: 'Fitness Goals', folder: 'Personal', tags: ['health', 'fitness'], created: new Date('2024-09-15'), modified: new Date('2024-09-22'), priority: 3, status: 'Active', noteType: 'Planning', summary: 'Fall workout routine' },
  
  // Q4 2024
  { id: 'n19', title: 'Year End Review', folder: 'Work', tags: ['planning', 'review'], created: new Date('2024-10-01'), modified: new Date('2024-10-15'), priority: 4, status: 'In Progress', noteType: 'Planning', summary: '2024 retrospective' },
  { id: 'n20', title: 'Holiday Meal Planning', folder: 'Personal', tags: ['cooking', 'holidays'], created: new Date('2024-11-01'), modified: new Date('2024-11-20'), priority: 3, status: 'Active', noteType: 'Planning', summary: 'Thanksgiving and Christmas menus' },
  { id: 'n21', title: 'Budget 2025', folder: 'Work', tags: ['planning', 'finance'], created: new Date('2024-12-05'), modified: new Date('2024-12-15'), priority: 5, status: 'In Progress', noteType: 'Planning', summary: 'Next year resource allocation' },
  { id: 'n22', title: 'New Year Resolutions', folder: 'Personal', tags: ['goals', 'planning'], created: new Date('2024-12-28'), modified: new Date('2025-01-02'), priority: 2, status: 'Active', noteType: 'Planning', summary: '2025 personal goals' },
  
  // Q1 2025
  { id: 'n23', title: 'Product Roadmap Q1', folder: 'Work', tags: ['planning', 'product'], created: new Date('2025-01-10'), modified: new Date('2025-01-20'), priority: 5, status: 'Active', noteType: 'Planning', summary: 'Feature prioritization' },
  { id: 'n24', title: 'Winter Reading List', folder: 'Personal', tags: ['reading', 'books'], created: new Date('2025-02-01'), modified: new Date('2025-02-05'), priority: 1, status: 'Active', noteType: 'List', summary: 'Fiction and non-fiction' },
  { id: 'n25', title: 'Security Audit Findings', folder: 'Work', tags: ['security', 'technical'], created: new Date('2025-03-01'), modified: new Date('2025-03-10'), priority: 5, status: 'Active', noteType: 'Technical', summary: 'Vulnerability assessment' },
];
