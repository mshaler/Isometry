import { useState } from 'react';

interface DensitySliderProps {
  densityLevel: number;
  onDensityChange: (level: number) => void;
}

const DENSITY_LEVELS = [
  { level: 1, label: 'Value Sparsity', description: 'Full Cartesian product. Every intersection shown.' },
  { level: 2, label: 'Extent Density', description: 'Populated-only. Hide empty rows/columns.' },
  { level: 3, label: 'View Density', description: 'Matrix view. Aggregation rows visible.' },
  { level: 4, label: 'Region Density', description: 'Mixed sparse + dense regions. Power user mode.' },
];

export function DensitySlider({ densityLevel, onDensityChange }: DensitySliderProps) {
  const [hoveredLevel, setHoveredLevel] = useState<number | null>(null);

  return (
    <div className="fixed right-4 top-1/2 -translate-y-1/2 z-30 flex flex-col items-center">
      {/* Top Label */}
      <div className="mb-2 text-center">
        <div className="text-[11px] font-mono text-[#999] uppercase tracking-wide mb-1">
          Dense
        </div>
        <div className="text-xl">▦</div>
      </div>

      {/* Vertical Slider Track */}
      <div className="relative h-64 w-12 bg-gradient-to-b from-[#3A3A3A] to-[#1E1E1E] rounded-lg border-2 border-[#555] p-1">
        {/* Tick Marks */}
        {DENSITY_LEVELS.map((levelInfo, index) => {
          const position = ((4 - levelInfo.level) / 3) * 100; // Invert: level 4 at top
          const isActive = densityLevel === levelInfo.level;
          const isHovered = hoveredLevel === levelInfo.level;

          return (
            <button
              key={levelInfo.level}
              onClick={() => onDensityChange(levelInfo.level)}
              onMouseEnter={() => setHoveredLevel(levelInfo.level)}
              onMouseLeave={() => setHoveredLevel(null)}
              className="absolute left-1/2 -translate-x-1/2 w-8 h-8 flex items-center justify-center cursor-pointer group"
              style={{ top: `${position}%` }}
              title={levelInfo.description}
            >
              {/* Tick mark */}
              <div
                className={`
                  w-full h-1 rounded transition-all
                  ${isActive ? 'bg-[#4A90D9]' : 'bg-[#666]'}
                  ${isHovered ? 'scale-110' : ''}
                `}
              />
              
              {/* Level number */}
              {isActive && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-[11px] font-mono font-bold text-[#E0E0E0] bg-[#4A90D9] rounded-full w-5 h-5 flex items-center justify-center">
                    {levelInfo.level}
                  </span>
                </div>
              )}

              {/* Tooltip on hover */}
              {isHovered && (
                <div className="absolute left-full ml-3 w-48 bg-[#252525] border border-[#555] rounded p-2 shadow-lg pointer-events-none">
                  <div className="text-[11px] font-semibold text-[#E0E0E0] mb-1">
                    {levelInfo.label}
                  </div>
                  <div className="text-[10px] text-[#999]">
                    {levelInfo.description}
                  </div>
                </div>
              )}
            </button>
          );
        })}

        {/* Active position indicator */}
        <div
          className="absolute left-1/2 -translate-x-1/2 w-10 h-10 rounded-full bg-[#4A90D9]/20 border-2 border-[#4A90D9] transition-all duration-300"
          style={{ top: `${((4 - densityLevel) / 3) * 100}%`, transform: 'translate(-50%, -50%)' }}
        />
      </div>

      {/* Bottom Label */}
      <div className="mt-2 text-center">
        <div className="text-xl">◻</div>
        <div className="text-[11px] font-mono text-[#999] uppercase tracking-wide mt-1">
          Sparse
        </div>
      </div>

      {/* Current level info */}
      <div className="mt-4 p-2 bg-[#252525] border border-[#3A3A3A] rounded text-center max-w-32">
        <div className="text-[10px] font-mono text-[#999] uppercase tracking-wide mb-1">
          Level {densityLevel}
        </div>
        <div className="text-[11px] text-[#E0E0E0]">
          {DENSITY_LEVELS.find(l => l.level === densityLevel)?.label}
        </div>
      </div>
    </div>
  );
}
