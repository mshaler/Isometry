import { useState } from 'react';
import { MapPin, Type, Clock, Tag, BarChart3, X, ChevronUp, ChevronDown } from 'lucide-react';

interface LatchSlidersProps {
  onLocationFilter: (filter: any) => void;
  onAlphabetFilter: (filter: any) => void;
  onTimeFilter: (filter: any) => void;
  onCategoryFilter: (filter: any) => void;
  onHierarchyFilter: (filter: any) => void;
}

export function LatchSliders({
  onLocationFilter,
  onAlphabetFilter,
  onTimeFilter,
  onCategoryFilter,
  onHierarchyFilter,
}: LatchSlidersProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [locationQuery, setLocationQuery] = useState('');
  const [alphabetQuery, setAlphabetQuery] = useState('');
  const [timeRange, setTimeRange] = useState([0, 100]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [hierarchyRange, setHierarchyRange] = useState([1, 5]);

  return (
    <div className="w-full border-t border-[#3A3A3A] bg-[#252525]">
      {/* Collapsed Header */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between px-4 py-2 hover:bg-[#2D2D2D] transition-colors"
      >
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono text-[#999] uppercase">LATCH Filters</span>
          <div className="flex gap-1">
            <MapPin className="w-3 h-3 text-[#4A90D9]" />
            <Type className="w-3 h-3 text-[#7CB342]" />
            <Clock className="w-3 h-3 text-[#FF9800]" />
            <Tag className="w-3 h-3 text-[#9C27B0]" />
            <BarChart3 className="w-3 h-3 text-[#E53935]" />
          </div>
        </div>
        {isExpanded ? (
          <ChevronDown className="w-4 h-4 text-[#999]" />
        ) : (
          <ChevronUp className="w-4 h-4 text-[#999]" />
        )}
      </button>

      {/* Expanded Content */}
      {isExpanded && (
      <div className="p-2 space-y-2 max-h-64 overflow-y-auto">
        {/* Location Slider */}
        <div className="flex items-center gap-3 py-2 border-b border-[#3A3A3A]/50">
          <MapPin className="w-4 h-4 text-[#4A90D9] flex-shrink-0" />
          <span className="text-[11px] font-mono text-[#999] w-20">Location</span>
          <div className="flex-1 h-1 bg-[#3A3A3A] rounded-full relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <input
                type="text"
                placeholder="within 50mi of Denver"
                value={locationQuery}
                onChange={(e) => setLocationQuery(e.target.value)}
                className="w-full h-7 px-2 bg-[#2D2D2D] text-[11px] text-[#E0E0E0] border border-[#555] rounded"
              />
            </div>
          </div>
          {locationQuery && (
            <button
              onClick={() => setLocationQuery('')}
              className="p-1 hover:bg-[#3A3A3A] rounded"
            >
              <X className="w-3 h-3 text-[#999]" />
            </button>
          )}
        </div>

        {/* Alphabet Slider */}
        <div className="flex items-center gap-3 py-2 border-b border-[#3A3A3A]/50">
          <Type className="w-4 h-4 text-[#7CB342] flex-shrink-0" />
          <span className="text-[11px] font-mono text-[#999] w-20">Alphabet</span>
          <div className="flex-1 flex items-center gap-2">
            <input
              type="text"
              placeholder="Search..."
              value={alphabetQuery}
              onChange={(e) => setAlphabetQuery(e.target.value)}
              className="flex-1 h-7 px-2 bg-[#2D2D2D] text-[11px] text-[#E0E0E0] border border-[#555] rounded"
            />
            <select className="h-7 px-2 bg-[#2D2D2D] text-[11px] text-[#E0E0E0] border border-[#555] rounded">
              <option>A→Z</option>
              <option>Z→A</option>
              <option>Count</option>
            </select>
          </div>
          {alphabetQuery && (
            <button
              onClick={() => setAlphabetQuery('')}
              className="p-1 hover:bg-[#3A3A3A] rounded"
            >
              <X className="w-3 h-3 text-[#999]" />
            </button>
          )}
        </div>

        {/* Time Slider */}
        <div className="flex items-center gap-3 py-2 border-b border-[#3A3A3A]/50">
          <Clock className="w-4 h-4 text-[#FF9800] flex-shrink-0" />
          <span className="text-[11px] font-mono text-[#999] w-20">Time</span>
          <div className="flex-1">
            {/* Timeline Histogram */}
            <div className="h-12 bg-[#2D2D2D] rounded border border-[#555] p-1 mb-1">
              <div className="flex items-end justify-between h-full gap-0.5">
                {[3, 5, 7, 5, 3, 1, 3, 5, 7, 10, 7, 5, 3, 5, 7, 5, 3].map((height, i) => (
                  <div
                    key={i}
                    className="flex-1 bg-[#FF9800]/40 rounded-sm"
                    style={{ height: `${height * 10}%` }}
                  />
                ))}
              </div>
            </div>
            {/* Range Slider */}
            <div className="relative h-6 flex items-center">
              <input
                type="range"
                min="0"
                max="100"
                value={timeRange[0]}
                onChange={(e) => setTimeRange([parseInt(e.target.value), timeRange[1]])}
                className="absolute w-full"
              />
              <input
                type="range"
                min="0"
                max="100"
                value={timeRange[1]}
                onChange={(e) => setTimeRange([timeRange[0], parseInt(e.target.value)])}
                className="absolute w-full"
              />
            </div>
            {/* Shortcuts */}
            <div className="flex gap-1 mt-1">
              {['Today', 'This Week', 'This Month', 'This Quarter', 'This Year', 'All Time'].map(label => (
                <button
                  key={label}
                  className="px-2 py-0.5 bg-[#2D2D2D] text-[10px] text-[#999] border border-[#555] rounded hover:bg-[#3A3A3A] hover:text-[#E0E0E0]"
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
          <button className="p-1 hover:bg-[#3A3A3A] rounded">
            <X className="w-3 h-3 text-[#999]" />
          </button>
        </div>

        {/* Category Slider */}
        <div className="flex items-center gap-3 py-2 border-b border-[#3A3A3A]/50">
          <Tag className="w-4 h-4 text-[#9C27B0] flex-shrink-0" />
          <span className="text-[11px] font-mono text-[#999] w-20">Category</span>
          <div className="flex-1 flex flex-wrap gap-1">
            {['Work', 'Personal', 'Meeting', 'Research', 'Planning'].map(cat => {
              const isSelected = selectedCategories.includes(cat);
              return (
                <button
                  key={cat}
                  onClick={() => {
                    setSelectedCategories(prev =>
                      prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
                    );
                  }}
                  className={`
                    px-2 py-1 text-[11px] rounded border transition-all
                    ${isSelected
                      ? 'bg-[#9C27B0]/20 border-[#9C27B0] text-[#E0E0E0]'
                      : 'bg-transparent border-[#9C27B0]/50 text-[#999]'
                    }
                  `}
                >
                  {cat}
                </button>
              );
            })}
            <button className="px-2 py-1 text-[10px] text-[#666] border border-[#555] rounded hover:bg-[#3A3A3A]">
              AND/OR
            </button>
          </div>
          {selectedCategories.length > 0 && (
            <button
              onClick={() => setSelectedCategories([])}
              className="p-1 hover:bg-[#3A3A3A] rounded"
            >
              <X className="w-3 h-3 text-[#999]" />
            </button>
          )}
        </div>

        {/* Hierarchy Slider */}
        <div className="flex items-center gap-3 py-2">
          <BarChart3 className="w-4 h-4 text-[#E53935] flex-shrink-0" />
          <span className="text-[11px] font-mono text-[#999] w-20">Hierarchy</span>
          <div className="flex-1">
            {/* Priority Scale */}
            <div className="h-8 bg-gradient-to-r from-[#4A90D9] to-[#E53935] rounded border border-[#555] relative">
              <div className="absolute inset-0 flex items-center justify-between px-2 text-[10px] text-white/80">
                <span>1</span>
                <span>2</span>
                <span>3</span>
                <span>4</span>
                <span>5</span>
              </div>
            </div>
            {/* Range Slider */}
            <div className="relative h-6 flex items-center mt-1">
              <input
                type="range"
                min="1"
                max="5"
                value={hierarchyRange[0]}
                onChange={(e) => setHierarchyRange([parseInt(e.target.value), hierarchyRange[1]])}
                className="absolute w-full"
              />
              <input
                type="range"
                min="1"
                max="5"
                value={hierarchyRange[1]}
                onChange={(e) => setHierarchyRange([hierarchyRange[0], parseInt(e.target.value)])}
                className="absolute w-full"
              />
            </div>
            {/* Semantic Labels */}
            <div className="flex gap-1 mt-1">
              {['Critical', 'High', 'Medium', 'Low', 'None'].map(label => (
                <button
                  key={label}
                  className="flex-1 px-2 py-0.5 bg-[#2D2D2D] text-[10px] text-[#999] border border-[#555] rounded hover:bg-[#3A3A3A] hover:text-[#E0E0E0]"
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
          <button className="p-1 hover:bg-[#3A3A3A] rounded">
            <X className="w-3 h-3 text-[#999]" />
          </button>
        </div>
      </div>
      )}
    </div>
  );
}