import { useDrag, useDrop } from 'react-dnd';
import { Property } from '../data/mockData';
import { GripVertical, ArrowLeftRight } from 'lucide-react';
import { LATCH_COLUMNS } from '../data/mockData';

const ITEM_TYPE = 'AXIS_CHIP';

interface AxisChip {
  propertyId: string;
  property: Property;
  sourceWell: 'available' | 'x' | 'y' | 'z';
}

interface PafvNavigatorProps {
  availableProperties: Property[];
  xAxisProperties: Property[];
  yAxisProperties: Property[];
  zAxisProperties: Property[];
  displayProperty: Property | null;
  auditViewEnabled: boolean;
  cardDensity: 'compact' | 'standard' | 'expanded' | 'full';
  aggregationMode: 'count' | 'sum' | 'average' | 'min' | 'max' | 'list';
  densityLevel: number;
  onMoveProperty: (propertyId: string, fromWell: string, toWell: string) => void;
  onReorderProperty: (well: string, fromIndex: number, toIndex: number) => void;
  onDisplayPropertyChange: (propertyId: string) => void;
  onAuditViewToggle: () => void;
  onCardDensityChange: (density: 'compact' | 'standard' | 'expanded' | 'full') => void;
  onAggregationModeChange: (mode: 'count' | 'sum' | 'average' | 'min' | 'max' | 'list') => void;
  onDensityChange: (level: number) => void;
}

function DraggableChip({ 
  property, 
  sourceWell, 
  index,
  onMove 
}: { 
  property: Property; 
  sourceWell: 'available' | 'x' | 'y' | 'z';
  index: number;
  onMove: (propertyId: string, fromWell: string, toWell: string, index?: number) => void;
}) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: ITEM_TYPE,
    item: { propertyId: property.id, property, sourceWell, index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }));

  const axisColor = LATCH_COLUMNS.find(col => col.key === property.axis)?.color || '#78909C';

  return (
    <div
      ref={drag}
      className={`
        flex items-center gap-2 h-7 px-2 bg-[#2D2D2D] rounded cursor-move
        border-l-[3px] transition-all
        ${isDragging ? 'opacity-40 scale-95' : 'opacity-100'}
        hover:bg-[#3A3A3A]
      `}
      style={{ borderLeftColor: axisColor }}
    >
      <GripVertical className="w-3 h-3 text-[#666]" />
      <span className="flex-1 text-[13px] text-[#E0E0E0] truncate">
        {property.displayName}
      </span>
    </div>
  );
}

function DropWell({ 
  wellId, 
  label, 
  properties, 
  width, 
  onDrop,
  onReorder,
  children 
}: { 
  wellId: 'available' | 'x' | 'y' | 'z'; 
  label: string; 
  properties: Property[]; 
  width: string;
  onDrop: (propertyId: string, fromWell: string, toWell: string, index?: number) => void;
  onReorder: (well: string, fromIndex: number, toIndex: number) => void;
  children?: React.ReactNode;
}) {
  const [{ isOver, canDrop }, drop] = useDrop(() => ({
    accept: ITEM_TYPE,
    drop: (item: AxisChip) => {
      onDrop(item.propertyId, item.sourceWell, wellId);
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
      canDrop: monitor.canDrop(),
    }),
  }));

  return (
    <div className={width}>
      <div className="mb-1 px-2">
        <span className="text-[11px] font-mono text-[#999] uppercase tracking-wide">
          {label}
        </span>
      </div>
      <div
        ref={drop}
        className={`
          h-64 p-2 bg-[#2D2D2D] rounded border-2 transition-all overflow-y-auto
          ${isOver && canDrop ? 'border-[#4A90D9] bg-[#4A90D9]/10' : 'border-[#3A3A3A]'}
          ${!isOver && canDrop ? 'border-[#555]' : ''}
        `}
      >
        <div className="flex flex-col gap-1">
          {properties.map((prop, index) => (
            <DraggableChip 
              key={prop.id} 
              property={prop} 
              sourceWell={wellId} 
              index={index}
              onMove={onDrop}
            />
          ))}
          {children}
        </div>
      </div>
    </div>
  );
}

export function PafvNavigator({
  availableProperties,
  xAxisProperties,
  yAxisProperties,
  zAxisProperties,
  displayProperty,
  auditViewEnabled,
  cardDensity,
  aggregationMode,
  densityLevel,
  onMoveProperty,
  onReorderProperty,
  onDisplayPropertyChange,
  onAuditViewToggle,
  onCardDensityChange,
  onAggregationModeChange,
  onDensityChange,
}: PafvNavigatorProps) {
  const textProperties = availableProperties.filter(p => p.type === 'text');

  return (
    <div className="w-full border-b border-[#3A3A3A] bg-[#252525] p-2 max-h-80 overflow-y-auto">
      <div className="flex gap-2">
        {/* Available Well */}
        <div className="w-[28%] flex flex-col">
          <div className="mb-1 px-2 h-8 flex items-center">
            <span className="text-[11px] font-mono text-[#999] uppercase tracking-wide leading-tight">
              Available<br />Properties
            </span>
          </div>
          <DropWell
            wellId="available"
            label=""
            properties={availableProperties}
            width="w-full"
            onDrop={onMoveProperty}
            onReorder={onReorderProperty}
          />
        </div>

        {/* X Plane Well */}
        <div className="w-[18%] flex flex-col">
          <div className="mb-1 px-2 h-8 flex items-center">
            <span className="text-[11px] font-mono text-[#999] uppercase tracking-wide leading-tight">
              X-Plane<br />(Columns)
            </span>
          </div>
          <DropWell
            wellId="x"
            label=""
            properties={xAxisProperties}
            width="w-full"
            onDrop={onMoveProperty}
            onReorder={onReorderProperty}
          />
        </div>

        {/* Y Plane Well */}
        <div className="w-[18%] flex flex-col">
          <div className="mb-1 px-2 h-8 flex items-center">
            <span className="text-[11px] font-mono text-[#999] uppercase tracking-wide leading-tight">
              Y-Plane<br />(Rows)
            </span>
          </div>
          <DropWell
            wellId="y"
            label=""
            properties={yAxisProperties}
            width="w-full"
            onDrop={onMoveProperty}
            onReorder={onReorderProperty}
          />
        </div>

        {/* Z Plane Well with Controls */}
        <div className="w-[18%] flex flex-col">
          <div className="mb-1 px-2 h-8 flex items-center">
            <span className="text-[11px] font-mono text-[#999] uppercase tracking-wide leading-tight">
              Z-Plane<br />(Layers)
            </span>
          </div>
          <DropWell
            wellId="z"
            label=""
            properties={zAxisProperties}
            width="w-full"
            onDrop={onMoveProperty}
            onReorder={onReorderProperty}
          >
            {/* Display Property Dropdown */}
            <div className="mt-2 pt-2 border-t border-[#3A3A3A]">
              <select
                value={displayProperty?.id || ''}
                onChange={(e) => onDisplayPropertyChange(e.target.value)}
                className="w-full h-7 px-2 bg-[#2D2D2D] text-[11px] text-[#E0E0E0] border border-[#555] rounded hover:bg-[#3A3A3A] cursor-pointer"
              >
                <option value="">Display: (None)</option>
                {textProperties.map(prop => (
                  <option key={prop.id} value={prop.id}>
                    Display: {prop.displayName}
                  </option>
                ))}
              </select>
            </div>

            {/* Audit View Toggle */}
            <div className="mt-1">
              <label className="flex items-center gap-2 h-7 px-2 bg-[#2D2D2D] rounded border border-[#555] hover:bg-[#3A3A3A] cursor-pointer">
                <input
                  type="checkbox"
                  checked={auditViewEnabled}
                  onChange={onAuditViewToggle}
                  className="w-3.5 h-3.5"
                />
                <span className="text-[11px] text-[#E0E0E0]">Audit View</span>
              </label>
            </div>

            {/* Card Density Selector */}
            <div className="mt-1">
              <select
                value={cardDensity}
                onChange={(e) => onCardDensityChange(e.target.value as any)}
                className="w-full h-7 px-2 bg-[#2D2D2D] text-[11px] text-[#E0E0E0] border border-[#555] rounded hover:bg-[#3A3A3A] cursor-pointer"
              >
                <option value="compact">Cards: Compact</option>
                <option value="standard">Cards: Standard</option>
                <option value="expanded">Cards: Expanded</option>
                <option value="full">Cards: Full</option>
              </select>
            </div>

            {/* Aggregation Mode */}
            <div className="mt-1">
              <select
                value={aggregationMode}
                onChange={(e) => onAggregationModeChange(e.target.value as any)}
                className="w-full h-7 px-2 bg-[#2D2D2D] text-[11px] text-[#E0E0E0] border border-[#555] rounded hover:bg-[#3A3A3A] cursor-pointer"
              >
                <option value="count">Agg: Count</option>
                <option value="sum">Agg: Sum</option>
                <option value="average">Agg: Average</option>
                <option value="min">Agg: Min</option>
                <option value="max">Agg: Max</option>
                <option value="list">Agg: List</option>
              </select>
            </div>
          </DropWell>
        </div>

        {/* Sparsity-Density Slider Column */}
        <div className="w-[18%] flex flex-col">
          <div className="mb-1 px-2 h-8 flex items-center">
            <span className="text-[11px] font-mono text-[#999] uppercase tracking-wide leading-tight">
              Sparsity↔<br />Density
            </span>
          </div>
          <div className="flex-1 p-3 bg-[#2D2D2D] rounded border-2 border-[#3A3A3A] flex flex-col items-center justify-between">
            {/* Sparse Label */}
            <div className="text-[10px] font-mono text-[#999] rotate-0 text-center">
              SPARSE
            </div>
            
            {/* Vertical Slider */}
            <div className="flex-1 flex items-center justify-center py-4">
              <input
                type="range"
                min="0"
                max="4"
                step="1"
                value={densityLevel}
                onChange={(e) => onDensityChange(Number(e.target.value))}
                orient="vertical"
                className="h-full appearance-none bg-transparent cursor-pointer"
                style={{
                  writingMode: 'bt-lr',
                  WebkitAppearance: 'slider-vertical',
                  width: '8px',
                }}
              />
            </div>

            {/* Dense Label */}
            <div className="text-[10px] font-mono text-[#999] rotate-0 text-center">
              DENSE
            </div>

            {/* Density Level Indicator */}
            <div className="mt-2 text-[11px] text-[#E0E0E0] font-mono">
              {densityLevel}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}