import { useState } from 'react';
import { Checkbox } from './ui/checkbox';
import { LATCH_COLUMNS, Property } from '../data/mockData';
import { ChevronDown, ChevronRight, Edit2, Calendar, Type, Hash, List } from 'lucide-react';

interface LatchNavigatorProps {
  properties: Property[];
  onPropertyToggle: (propertyId: string) => void;
  onPropertyRename: (propertyId: string, newName: string) => void;
}

export function LatchNavigator({ properties, onPropertyToggle, onPropertyRename }: LatchNavigatorProps) {
  const [collapsedColumns, setCollapsedColumns] = useState<Set<string>>(new Set());
  const [editingProperty, setEditingProperty] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');

  const toggleColumn = (columnKey: string) => {
    setCollapsedColumns(prev => {
      const next = new Set(prev);
      if (next.has(columnKey)) {
        next.delete(columnKey);
      } else {
        next.add(columnKey);
      }
      return next;
    });
  };

  const startEdit = (property: Property) => {
    setEditingProperty(property.id);
    setEditValue(property.displayName);
  };

  const finishEdit = (propertyId: string) => {
    if (editValue.trim()) {
      onPropertyRename(propertyId, editValue.trim());
    }
    setEditingProperty(null);
  };

  const getTypeIcon = (type: Property['type']) => {
    switch (type) {
      case 'date': return <Calendar className="w-3 h-3" />;
      case 'text': return <Type className="w-3 h-3" />;
      case 'number': return <Hash className="w-3 h-3" />;
      case 'select': return <List className="w-3 h-3" />;
      case 'location': return <span className="text-[10px]">📍</span>;
    }
  };

  return (
    <div className="w-full border-b border-[#3A3A3A] bg-[#252525] max-h-48 overflow-y-auto">
      <div className="grid grid-cols-6 gap-1 p-1">
        {LATCH_COLUMNS.map((column) => {
          const columnProps = properties.filter(p => p.axis === column.key);
          const checkedCount = columnProps.filter(p => p.checked).length;
          const isCollapsed = collapsedColumns.has(column.key);

          return (
            <div key={column.key} className="bg-[#2D2D2D] rounded overflow-hidden flex flex-col">
              {/* Column Header */}
              <button
                onClick={() => toggleColumn(column.key)}
                className="flex items-center justify-between px-2 py-1.5 hover:bg-[#3A3A3A] transition-colors"
                style={{ borderBottom: `2px solid ${column.color}` }}
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-xs">{column.icon}</span>
                  <span className="text-[11px] font-mono text-[#E0E0E0] font-semibold">
                    {column.key === 'GRAPH' ? 'GRAPH' : column.key}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-[#999] font-mono">
                    {checkedCount}/{columnProps.length}
                  </span>
                  {isCollapsed ? (
                    <ChevronRight className="w-3 h-3 text-[#999]" />
                  ) : (
                    <ChevronDown className="w-3 h-3 text-[#999]" />
                  )}
                </div>
              </button>

              {/* Property Chips */}
              {!isCollapsed && (
                <div className="flex flex-col">
                  {columnProps.map((property) => (
                    <div
                      key={property.id}
                      className={`
                        group relative flex items-center gap-2 h-7 px-2 border-l-[3px] transition-all
                        ${property.checked 
                          ? `bg-[${column.color}]/10 border-l-[${column.color}]` 
                          : 'bg-transparent border-l-transparent opacity-60'
                        }
                        hover:bg-[#3A3A3A]/50
                      `}
                      style={{
                        borderLeftColor: property.checked ? column.color : 'transparent',
                        backgroundColor: property.checked ? `${column.color}15` : 'transparent',
                      }}
                    >
                      {/* Checkbox */}
                      <Checkbox
                        checked={property.checked}
                        onCheckedChange={() => onPropertyToggle(property.id)}
                        className="h-3.5 w-3.5 border-[#555]"
                      />

                      {/* Display Name */}
                      {editingProperty === property.id ? (
                        <input
                          type="text"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          onBlur={() => finishEdit(property.id)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') finishEdit(property.id);
                            if (e.key === 'Escape') setEditingProperty(null);
                          }}
                          autoFocus
                          className="flex-1 bg-[#1E1E1E] text-[13px] text-[#E0E0E0] px-1 py-0 border border-[#555] rounded outline-none"
                        />
                      ) : (
                        <span className="flex-1 text-[13px] text-[#E0E0E0] truncate">
                          {property.displayName}
                        </span>
                      )}

                      {/* Type Icon & Edit Button */}
                      <div className="flex items-center gap-1">
                        <span className="text-[#666]">
                          {getTypeIcon(property.type)}
                        </span>
                        <button
                          onClick={() => startEdit(property)}
                          className="opacity-0 group-hover:opacity-100 transition-opacity p-0.5 hover:bg-[#555] rounded"
                        >
                          <Edit2 className="w-3 h-3 text-[#999]" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}