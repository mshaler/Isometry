import { useState, useEffect } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { LatchNavigator } from './components/LatchNavigator';
import { PafvNavigator } from './components/PafvNavigator';
import { SuperGrid } from './components/SuperGrid';
import { DensitySlider } from './components/DensitySlider';
import { LatchSliders } from './components/LatchSliders';
import { PROPERTIES, MOCK_NOTES, Property } from './data/mockData';
import { MoreVertical } from 'lucide-react';

export default function App() {
  // State management
  const [properties, setProperties] = useState<Property[]>(PROPERTIES);
  const [availableProperties, setAvailableProperties] = useState<Property[]>([]);
  const [xAxisProperties, setXAxisProperties] = useState<Property[]>([]);
  const [yAxisProperties, setYAxisProperties] = useState<Property[]>([]);
  const [zAxisProperties, setZAxisProperties] = useState<Property[]>([]);
  const [displayProperty, setDisplayProperty] = useState<Property | null>(null);
  const [auditViewEnabled, setAuditViewEnabled] = useState(false);
  const [cardDensity, setCardDensity] = useState<'compact' | 'standard' | 'expanded' | 'full'>('standard');
  const [aggregationMode, setAggregationMode] = useState<'count' | 'sum' | 'average' | 'min' | 'max' | 'list'>('count');
  const [densityLevel, setDensityLevel] = useState(2);

  // Initialize available properties from checked properties
  useEffect(() => {
    const checked = properties.filter(p => p.checked);
    setAvailableProperties(checked);
    
    // Set default display property to first text property
    const firstText = checked.find(p => p.type === 'text');
    if (firstText) setDisplayProperty(firstText);
    
    // Pre-assign default axes for immediate visualization
    const folderProp = checked.find(p => p.rawName === 'ZFOLDER'); // Category axis
    const createdProp = checked.find(p => p.rawName === 'ZINCEPTIONTIMESTAMP'); // Time axis
    const priorityProp = checked.find(p => p.rawName === 'ZPRIORITY'); // Hierarchy axis
    
    if (folderProp && createdProp) {
      // X-plane (Columns) = Time (Created date)
      setXAxisProperties([createdProp]);
      // Y-plane (Rows) = Folder
      setYAxisProperties([folderProp]);
      // Remove from available
      setAvailableProperties(prev => prev.filter(p => p.id !== folderProp.id && p.id !== createdProp.id));
    }
  }, []);

  // Property toggle handler
  const handlePropertyToggle = (propertyId: string) => {
    setProperties(prev => prev.map(p => 
      p.id === propertyId ? { ...p, checked: !p.checked } : p
    ));

    const property = properties.find(p => p.id === propertyId);
    if (!property) return;

    if (property.checked) {
      // Unchecking - remove from all wells
      setAvailableProperties(prev => prev.filter(p => p.id !== propertyId));
      setXAxisProperties(prev => prev.filter(p => p.id !== propertyId));
      setYAxisProperties(prev => prev.filter(p => p.id !== propertyId));
      setZAxisProperties(prev => prev.filter(p => p.id !== propertyId));
    } else {
      // Checking - add to available
      setAvailableProperties(prev => [...prev, property]);
    }
  };

  // Property rename handler
  const handlePropertyRename = (propertyId: string, newName: string) => {
    setProperties(prev => prev.map(p => 
      p.id === propertyId ? { ...p, displayName: newName } : p
    ));
    // Update in all wells
    const updateWell = (props: Property[]) => 
      props.map(p => p.id === propertyId ? { ...p, displayName: newName } : p);
    setAvailableProperties(updateWell);
    setXAxisProperties(updateWell);
    setYAxisProperties(updateWell);
    setZAxisProperties(updateWell);
  };

  // Move property between wells
  const handleMoveProperty = (propertyId: string, fromWell: string, toWell: string) => {
    const property = [...availableProperties, ...xAxisProperties, ...yAxisProperties, ...zAxisProperties]
      .find(p => p.id === propertyId);
    
    if (!property) return;

    // Remove from source well
    const removeFrom = (well: string, setter: React.Dispatch<React.SetStateAction<Property[]>>) => {
      if (fromWell === well) {
        setter(prev => prev.filter(p => p.id !== propertyId));
      }
    };

    removeFrom('available', setAvailableProperties);
    removeFrom('x', setXAxisProperties);
    removeFrom('y', setYAxisProperties);
    removeFrom('z', setZAxisProperties);

    // Add to target well
    const addTo = (well: string, setter: React.Dispatch<React.SetStateAction<Property[]>>) => {
      if (toWell === well) {
        setter(prev => [...prev, property]);
      }
    };

    addTo('available', setAvailableProperties);
    addTo('x', setXAxisProperties);
    addTo('y', setYAxisProperties);
    addTo('z', setZAxisProperties);
  };

  // Reorder properties within a well
  const handleReorderProperty = (well: string, fromIndex: number, toIndex: number) => {
    // Implementation for reordering would go here
  };

  // Transpose X and Y axes
  const handleTranspose = () => {
    const tempX = xAxisProperties;
    setXAxisProperties(yAxisProperties);
    setYAxisProperties(tempX);
  };

  // Display property change
  const handleDisplayPropertyChange = (propertyId: string) => {
    const property = properties.find(p => p.id === propertyId);
    setDisplayProperty(property || null);
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="h-screen flex flex-col bg-[#1E1E1E] text-[#E0E0E0]">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-4 py-2 bg-[#252525] border-b border-[#3A3A3A]">
          <div className="flex items-center gap-3">
            <h1 className="text-[13px] font-mono font-semibold">Isometry</h1>
            <span className="text-[11px] text-[#666]">|</span>
            <span className="text-[11px] text-[#999]">Apple Notes Database</span>
            <span className="text-[11px] text-[#666]">•</span>
            <span className="text-[11px] text-[#999]">{MOCK_NOTES.length} notes</span>
          </div>
          <button className="p-1 hover:bg-[#3A3A3A] rounded">
            <MoreVertical className="w-4 h-4 text-[#999]" />
          </button>
        </div>

        {/* Navigator 1: LATCH×GRAPH Properties Filter */}
        <LatchNavigator
          properties={properties}
          onPropertyToggle={handlePropertyToggle}
          onPropertyRename={handlePropertyRename}
        />

        {/* Navigator 2: PAFV Projection */}
        <PafvNavigator
          availableProperties={availableProperties}
          xAxisProperties={xAxisProperties}
          yAxisProperties={yAxisProperties}
          zAxisProperties={zAxisProperties}
          displayProperty={displayProperty}
          auditViewEnabled={auditViewEnabled}
          cardDensity={cardDensity}
          aggregationMode={aggregationMode}
          densityLevel={densityLevel}
          onMoveProperty={handleMoveProperty}
          onReorderProperty={handleReorderProperty}
          onDisplayPropertyChange={handleDisplayPropertyChange}
          onAuditViewToggle={() => setAuditViewEnabled(!auditViewEnabled)}
          onCardDensityChange={setCardDensity}
          onAggregationModeChange={setAggregationMode}
          onDensityChange={setDensityLevel}
        />

        {/* SuperGrid */}
        <div className="flex-1 flex flex-col min-h-0 overflow-hidden bg-[#1E1E1E]">
          <SuperGrid
            notes={MOCK_NOTES}
            xAxisProperties={xAxisProperties}
            yAxisProperties={yAxisProperties}
            displayProperty={displayProperty}
            auditViewEnabled={auditViewEnabled}
            cardDensity={cardDensity}
            onTranspose={handleTranspose}
          />
        </div>

        {/* LATCH Sliders */}
        <LatchSliders
          onLocationFilter={() => {}}
          onAlphabetFilter={() => {}}
          onTimeFilter={() => {}}
          onCategoryFilter={() => {}}
          onHierarchyFilter={() => {}}
        />

        {/* Command Bar */}
        <div className="flex items-center gap-2 px-4 py-2 bg-[#252525] border-t border-[#3A3A3A]">
          <span className="text-[11px] text-[#999] font-mono">⌘</span>
          <input
            type="text"
            placeholder="Command palette..."
            className="flex-1 bg-[#2D2D2D] text-[13px] text-[#E0E0E0] px-3 py-1.5 border border-[#555] rounded outline-none focus:border-[#4A90D9]"
          />
        </div>
      </div>
    </DndProvider>
  );
}