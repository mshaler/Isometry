
  # Upload Markdown Document

  This is a code bundle for Upload Markdown Document. The original project is available at https://www.figma.com/design/aRUksAazmRiAvzJabzqsSG/Upload-Markdown-Document.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  