import { createBrowserRouter } from 'react-router';
import { GridView } from './views/GridView';
import { CardEditorView } from './views/CardEditorView';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: GridView,
  },
  {
    path: '/card/:id',
    Component: CardEditorView,
  },
]);
