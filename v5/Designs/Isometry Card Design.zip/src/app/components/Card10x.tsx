import { Card } from '../types/card';

interface Card10xProps {
  card: Card;
  onClick?: () => void;
}

export function Card10x({ card, onClick }: Card10xProps) {
  return (
    <div
      onClick={onClick}
      className="relative w-full h-full min-h-[600px] bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg overflow-hidden cursor-pointer group"
    >
      {/* Background thumbnail if available */}
      {card.thumbnailUrl && (
        <div
          className="absolute inset-0 opacity-30 bg-cover bg-center"
          style={{ backgroundImage: `url(${card.thumbnailUrl})` }}
        />
      )}
      
      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
      
      {/* Content */}
      <div className="relative h-full flex flex-col items-center justify-center p-12 text-white">
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-center mb-6 drop-shadow-lg">
          {card.title}
        </h1>
        
        {card.content && (
          <p className="text-lg md:text-xl text-center text-gray-200 max-w-3xl drop-shadow-md">
            {card.content.split('\n')[0]}
          </p>
        )}
      </div>
      
      {/* Hover effect */}
      <div className="absolute inset-0 ring-4 ring-white/0 group-hover:ring-white/20 transition-all rounded-lg" />
    </div>
  );
}
