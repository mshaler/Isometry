import { useState } from 'react';
import { Card } from '../types/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { X, Plus } from 'lucide-react';
import { Card5x } from './Card5x';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface CardEditorProps {
  card: Card;
  onSave: (card: Card) => void;
  onCancel: () => void;
}

export function CardEditor({ card, onSave, onCancel }: CardEditorProps) {
  const [editedCard, setEditedCard] = useState<Card>(card);
  const [newPropertyKey, setNewPropertyKey] = useState('');
  const [newPropertyValue, setNewPropertyValue] = useState('');
  const [contentTab, setContentTab] = useState<'edit' | 'preview'>('edit');

  const handleSave = () => {
    onSave({ ...editedCard, updatedAt: new Date() });
  };

  const addProperty = () => {
    if (newPropertyKey && newPropertyValue) {
      setEditedCard({
        ...editedCard,
        properties: [
          ...editedCard.properties,
          { key: newPropertyKey, value: newPropertyValue, type: 'text' }
        ]
      });
      setNewPropertyKey('');
      setNewPropertyValue('');
    }
  };

  const removeProperty = (index: number) => {
    setEditedCard({
      ...editedCard,
      properties: editedCard.properties.filter((_, i) => i !== index)
    });
  };

  return (
    <div className="h-full flex gap-6 p-6 bg-gray-50">
      {/* Editor Panel */}
      <div className="flex-1 bg-white rounded-lg shadow-sm p-6 overflow-y-auto">
        <h2 className="text-2xl font-bold mb-6">Edit Card</h2>

        {/* Card Type */}
        <div className="mb-4">
          <Label htmlFor="type">Card Type</Label>
          <Select
            value={editedCard.type}
            onValueChange={(value: Card['type']) =>
              setEditedCard({ ...editedCard, type: value })
            }
          >
            <SelectTrigger id="type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="note">Note</SelectItem>
              <SelectItem value="contact">Contact</SelectItem>
              <SelectItem value="event">Event</SelectItem>
              <SelectItem value="resource">Resource</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Title */}
        <div className="mb-4">
          <Label htmlFor="title">Title</Label>
          <Input
            id="title"
            value={editedCard.title}
            onChange={(e) =>
              setEditedCard({ ...editedCard, title: e.target.value })
            }
            placeholder="Card title"
          />
        </div>

        {/* Content with Tabs */}
        <div className="mb-4">
          <Label>Content (Markdown)</Label>
          <Tabs value={contentTab} onValueChange={(v) => setContentTab(v as 'edit' | 'preview')}>
            <TabsList className="mb-2">
              <TabsTrigger value="edit">Edit</TabsTrigger>
              <TabsTrigger value="preview">Preview</TabsTrigger>
            </TabsList>
            <TabsContent value="edit" className="mt-0">
              <Textarea
                value={editedCard.content}
                onChange={(e) =>
                  setEditedCard({ ...editedCard, content: e.target.value })
                }
                placeholder="Card content (supports markdown)"
                className="h-48"
              />
            </TabsContent>
            <TabsContent value="preview" className="mt-0">
              <div className="border rounded-md p-4 h-48 overflow-y-auto prose prose-sm max-w-none">
                <Markdown remarkPlugins={[remarkGfm]}>{editedCard.content}</Markdown>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Thumbnail URL */}
        <div className="mb-4">
          <Label htmlFor="thumbnail">Thumbnail URL</Label>
          <Input
            id="thumbnail"
            value={editedCard.thumbnailUrl || ''}
            onChange={(e) =>
              setEditedCard({ ...editedCard, thumbnailUrl: e.target.value })
            }
            placeholder="https://..."
          />
        </div>

        {/* Properties */}
        <div className="mb-6">
          <Label className="mb-2 block">Properties</Label>
          <div className="space-y-2 mb-3">
            {editedCard.properties.map((prop, index) => (
              <div
                key={index}
                className="flex items-center gap-2 p-2 bg-gray-50 rounded"
              >
                <Badge variant="outline">{prop.key}</Badge>
                <span className="flex-1 text-sm">{prop.value}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => removeProperty(index)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>

          {/* Add Property */}
          <div className="flex gap-2">
            <Input
              placeholder="Key"
              value={newPropertyKey}
              onChange={(e) => setNewPropertyKey(e.target.value)}
              className="flex-1"
            />
            <Input
              placeholder="Value"
              value={newPropertyValue}
              onChange={(e) => setNewPropertyValue(e.target.value)}
              className="flex-1"
            />
            <Button onClick={addProperty} size="icon">
              <Plus className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-4 border-t">
          <Button onClick={handleSave}>Save Changes</Button>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </div>

      {/* Preview Panel */}
      <div className="w-80 flex flex-col gap-4">
        <div className="bg-white rounded-lg shadow-sm p-4">
          <h3 className="font-semibold mb-3">Preview (5x)</h3>
          <div className="flex justify-center">
            <Card5x card={editedCard} />
          </div>
        </div>
      </div>
    </div>
  );
}
