import { Card } from '../types/card';
import { getCardIcon, stripMarkdown, truncateText } from '../utils/cardUtils';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';

interface Card2xProps {
  card: Card;
  onClick?: () => void;
}

export function Card2x({ card, onClick }: Card2xProps) {
  const Icon = getCardIcon(card.type);
  const contentPreview = stripMarkdown(card.content);
  const initials = card.title
    .split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
  
  return (
    <div
      onClick={onClick}
      className="h-[60px] flex items-start gap-2 p-2 border border-gray-200 bg-white hover:bg-gray-50 cursor-pointer rounded transition-colors overflow-hidden"
      style={{ minWidth: '100px' }}
    >
      {card.type === 'contact' && card.thumbnailUrl ? (
        <Avatar className="w-8 h-8 flex-shrink-0">
          <AvatarImage src={card.thumbnailUrl} alt={card.title} />
          <AvatarFallback>{initials}</AvatarFallback>
        </Avatar>
      ) : (
        <div className="w-8 h-8 flex-shrink-0 rounded-full bg-gray-100 flex items-center justify-center">
          <Icon className="w-4 h-4 text-gray-600" />
        </div>
      )}
      
      <div className="flex-1 min-w-0 flex flex-col justify-center">
        <div className="font-medium text-sm truncate">
          {truncateText(card.title, 25)}
        </div>
        {contentPreview && (
          <div className="text-xs text-gray-500 truncate">
            {truncateText(contentPreview, 30)}
          </div>
        )}
      </div>
    </div>
  );
}
