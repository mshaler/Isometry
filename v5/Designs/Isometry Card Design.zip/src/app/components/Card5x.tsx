import { Card } from '../types/card';
import { getCardIcon, getCardBorderColor } from '../utils/cardUtils';
import { Badge } from './ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { ChevronDown } from 'lucide-react';
import { useState } from 'react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface Card5xProps {
  card: Card;
  onClick?: () => void;
}

export function Card5x({ card, onClick }: Card5xProps) {
  const Icon = getCardIcon(card.type);
  const [propertiesOpen, setPropertiesOpen] = useState(false);
  const borderColor = getCardBorderColor(card.type);
  
  return (
    <div
      className={`w-[200px] h-[300px] border-2 ${borderColor} bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow flex flex-col overflow-hidden`}
    >
      {/* Header - styled like a nutrition label */}
      <div className="border-b-4 border-black p-3 bg-white">
        <div className="flex items-center gap-2 mb-1">
          <Icon className="w-5 h-5 text-gray-700" />
          <Badge variant="outline" className="text-xs">
            {card.type}
          </Badge>
        </div>
        <h3 className="font-bold text-base leading-tight">{card.title}</h3>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-3 text-xs">
        <div className="prose prose-xs max-w-none">
          <Markdown remarkPlugins={[remarkGfm]}>{card.content}</Markdown>
        </div>
      </div>

      {/* Properties - Collapsible */}
      {card.properties.length > 0 && (
        <Collapsible open={propertiesOpen} onOpenChange={setPropertiesOpen}>
          <CollapsibleTrigger className="w-full border-t border-gray-200 px-3 py-2 flex items-center justify-between text-xs font-medium hover:bg-gray-50">
            <span>Properties ({card.properties.length})</span>
            <ChevronDown
              className={`w-4 h-4 transition-transform ${
                propertiesOpen ? 'rotate-180' : ''
              }`}
            />
          </CollapsibleTrigger>
          <CollapsibleContent className="border-t border-gray-100">
            <div className="p-3 bg-gray-50 space-y-2 max-h-32 overflow-y-auto">
              {card.properties.map((prop, index) => (
                <div key={index} className="text-xs">
                  <span className="font-medium text-gray-600">{prop.key}:</span>{' '}
                  <span className="text-gray-800">{prop.value}</span>
                </div>
              ))}
            </div>
          </CollapsibleContent>
        </Collapsible>
      )}
    </div>
  );
}
