import { Card } from '../types/card';
import { getCardIcon, truncateText } from '../utils/cardUtils';

interface Card1xProps {
  card: Card;
  onClick?: () => void;
}

export function Card1x({ card, onClick }: Card1xProps) {
  const Icon = getCardIcon(card.type);
  
  return (
    <div
      onClick={onClick}
      className="h-[30px] flex items-center px-2 border border-gray-200 bg-white hover:bg-gray-50 cursor-pointer rounded transition-colors overflow-hidden"
      style={{ minWidth: '100px' }}
    >
      <Icon className="w-3 h-3 mr-1.5 text-gray-500 flex-shrink-0" />
      <span className="text-xs truncate">
        {truncateText(card.title, 20)}
      </span>
    </div>
  );
}
