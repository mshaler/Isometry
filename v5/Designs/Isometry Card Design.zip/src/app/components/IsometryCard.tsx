import { Card, CardDimension } from '../types/card';
import { Card1x } from './Card1x';
import { Card2x } from './Card2x';
import { Card5x } from './Card5x';
import { Card10x } from './Card10x';

interface IsometryCardProps {
  card: Card;
  dimension: CardDimension;
  onClick?: () => void;
}

export function IsometryCard({ card, dimension, onClick }: IsometryCardProps) {
  switch (dimension) {
    case '1x':
      return <Card1x card={card} onClick={onClick} />;
    case '2x':
      return <Card2x card={card} onClick={onClick} />;
    case '5x':
      return <Card5x card={card} onClick={onClick} />;
    case '10x':
      return <Card10x card={card} onClick={onClick} />;
    default:
      return <Card5x card={card} onClick={onClick} />;
  }
}
