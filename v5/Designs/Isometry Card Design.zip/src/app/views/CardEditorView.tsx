import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import { Card } from '../types/card';
import { CardEditor } from '../components/CardEditor';
import { mockCards } from '../data/mockCards';
import { Button } from '../components/ui/button';
import { ArrowLeft } from 'lucide-react';

export function CardEditorView() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [card, setCard] = useState<Card | null>(null);

  useEffect(() => {
    const foundCard = mockCards.find(c => c.id === id);
    if (foundCard) {
      setCard(foundCard);
    }
  }, [id]);

  const handleSave = (updatedCard: Card) => {
    // In a real app, this would save to a backend
    console.log('Saving card:', updatedCard);
    navigate('/');
  };

  const handleCancel = () => {
    navigate('/');
  };

  if (!card) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">Card not found</p>
          <Button onClick={() => navigate('/')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Grid
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <Button variant="ghost" onClick={() => navigate('/')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Grid
          </Button>
        </div>
      </div>
      <CardEditor card={card} onSave={handleSave} onCancel={handleCancel} />
    </div>
  );
}
