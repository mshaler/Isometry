import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Card, CardDimension } from '../types/card';
import { IsometryCard } from '../components/IsometryCard';
import { Button } from '../components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Plus, LayoutGrid, LayoutList, Presentation } from 'lucide-react';
import { mockCards } from '../data/mockCards';

export function GridView() {
  const navigate = useNavigate();
  const [cards, setCards] = useState<Card[]>(mockCards);
  const [dimension, setDimension] = useState<CardDimension>('5x');
  const [filterType, setFilterType] = useState<Card['type'] | 'all'>('all');

  const filteredCards = filterType === 'all' 
    ? cards 
    : cards.filter(card => card.type === filterType);

  const handleCardClick = (cardId: string) => {
    navigate(`/card/${cardId}`);
  };

  const createNewCard = () => {
    const newCard: Card = {
      id: Date.now().toString(),
      type: 'note',
      title: 'New Card',
      content: '',
      properties: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };
    setCards([newCard, ...cards]);
    navigate(`/card/${newCard.id}`);
  };

  const getGridClass = () => {
    switch (dimension) {
      case '1x':
        return 'grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-2';
      case '2x':
        return 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3';
      case '5x':
        return 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6';
      case '10x':
        return 'grid grid-cols-1 md:grid-cols-2 gap-8';
      default:
        return 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold">Isometry</h1>
              <p className="text-sm text-gray-600">Cards in context</p>
            </div>
            <Button onClick={createNewCard}>
              <Plus className="w-4 h-4 mr-2" />
              New Card
            </Button>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-4 flex-wrap">
            {/* Card Dimension */}
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Size:</span>
              <Tabs value={dimension} onValueChange={(v) => setDimension(v as CardDimension)}>
                <TabsList>
                  <TabsTrigger value="1x" className="text-xs">1x</TabsTrigger>
                  <TabsTrigger value="2x" className="text-xs">2x</TabsTrigger>
                  <TabsTrigger value="5x" className="text-xs">5x</TabsTrigger>
                  <TabsTrigger value="10x" className="text-xs">10x</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            {/* Card Type Filter */}
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Type:</span>
              <Select value={filterType} onValueChange={(v) => setFilterType(v as Card['type'] | 'all')}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="note">Note</SelectItem>
                  <SelectItem value="contact">Contact</SelectItem>
                  <SelectItem value="event">Event</SelectItem>
                  <SelectItem value="resource">Resource</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1" />

            {/* Card Count */}
            <span className="text-sm text-gray-600">
              {filteredCards.length} {filteredCards.length === 1 ? 'card' : 'cards'}
            </span>
          </div>
        </div>
      </div>

      {/* Cards Grid */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className={getGridClass()}>
          {filteredCards.map((card) => (
            <IsometryCard
              key={card.id}
              card={card}
              dimension={dimension}
              onClick={() => handleCardClick(card.id)}
            />
          ))}
        </div>

        {filteredCards.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-500 mb-4">No cards found</p>
            <Button onClick={createNewCard}>
              <Plus className="w-4 h-4 mr-2" />
              Create your first card
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
