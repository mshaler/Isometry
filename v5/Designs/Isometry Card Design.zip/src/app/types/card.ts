export type CardType = 'note' | 'contact' | 'event' | 'resource';

export type CardDimension = '1x' | '2x' | '5x' | '10x';

export interface CardProperty {
  key: string;
  value: string;
  type?: 'text' | 'date' | 'url' | 'number' | 'email' | 'phone';
}

export interface Card {
  id: string;
  type: CardType;
  title: string;
  content: string; // Markdown+ content
  properties: CardProperty[];
  thumbnailUrl?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Contact specific properties
export interface ContactCard extends Card {
  type: 'contact';
}

// Event specific properties
export interface EventCard extends Card {
  type: 'event';
  isTask?: boolean;
  location?: string;
  startDate?: Date;
  endDate?: Date;
}

// Note specific properties
export interface NoteCard extends Card {
  type: 'note';
}

// Resource specific properties
export interface ResourceCard extends Card {
  type: 'resource';
  resourceType?: string;
}
