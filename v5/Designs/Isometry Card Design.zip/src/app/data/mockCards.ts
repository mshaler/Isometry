import { Card } from '../types/card';

export const mockCards: Card[] = [
  {
    id: '1',
    type: 'note',
    title: 'Project Meeting Notes',
    content: `# Meeting Summary\n\n## Attendees\n- Sarah Johnson\n- Mike Chen\n- Emily Rodriguez\n\n## Key Points\n- Discussed Q1 roadmap\n- Agreed on new feature priorities\n- **Action items** assigned to team members\n\n### Next Steps\n1. Review design mocks\n2. Schedule follow-up\n3. Update project timeline`,
    properties: [
      { key: 'category', value: 'work', type: 'text' },
      { key: 'priority', value: 'high', type: 'text' },
      { key: 'tags', value: 'meeting, planning', type: 'text' }
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1557426272-fc759fdf7a8d?w=400&h=600',
    createdAt: new Date('2026-02-20'),
    updatedAt: new Date('2026-02-25')
  },
  {
    id: '2',
    type: 'contact',
    title: 'Sarah Johnson',
    content: 'Senior Product Manager at TechCorp. Specializes in B2B SaaS products and agile methodologies.',
    properties: [
      { key: 'email', value: 'sarah.johnson@techcorp.com', type: 'email' },
      { key: 'phone', value: '+1 (555) 123-4567', type: 'phone' },
      { key: 'company', value: 'TechCorp', type: 'text' },
      { key: 'role', value: 'Senior Product Manager', type: 'text' },
      { key: 'linkedin', value: 'linkedin.com/in/sarahjohnson', type: 'url' }
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=600',
    createdAt: new Date('2026-01-15'),
    updatedAt: new Date('2026-02-10')
  },
  {
    id: '3',
    type: 'event',
    title: 'Design Review',
    content: `Review new dashboard designs with the team.\n\n**Agenda:**\n- Present wireframes\n- Discuss user feedback\n- Finalize color scheme`,
    properties: [
      { key: 'date', value: '2026-03-05', type: 'date' },
      { key: 'time', value: '2:00 PM', type: 'text' },
      { key: 'location', value: 'Conference Room B', type: 'text' },
      { key: 'attendees', value: '6', type: 'number' },
      { key: 'type', value: 'meeting', type: 'text' }
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=600',
    createdAt: new Date('2026-02-18'),
    updatedAt: new Date('2026-02-24')
  },
  {
    id: '4',
    type: 'event',
    title: 'Complete API Documentation',
    content: 'Write comprehensive documentation for the new REST API endpoints. Include authentication examples and error handling.',
    properties: [
      { key: 'status', value: 'in-progress', type: 'text' },
      { key: 'priority', value: 'high', type: 'text' },
      { key: 'assignee', value: 'Mike Chen', type: 'text' },
      { key: 'estimate', value: '8 hours', type: 'text' }
    ],
    createdAt: new Date('2026-02-22'),
    updatedAt: new Date('2026-02-25')
  },
  {
    id: '5',
    type: 'resource',
    title: 'Design System Guidelines',
    content: `# Isometry Design System\n\nComprehensive guide to our design language and component library.\n\n## Core Principles\n- **Clarity**: Clear visual hierarchy\n- **Consistency**: Reusable patterns\n- **Flexibility**: Adaptable components\n\n## Resources\n- Figma library\n- Component documentation\n- Code examples`,
    properties: [
      { key: 'type', value: 'documentation', type: 'text' },
      { key: 'url', value: 'https://design.isometry.app', type: 'url' },
      { key: 'version', value: '2.1.0', type: 'text' },
      { key: 'updated', value: '2026-02-20', type: 'date' }
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400&h=600',
    createdAt: new Date('2026-01-10'),
    updatedAt: new Date('2026-02-20')
  },
  {
    id: '6',
    type: 'note',
    title: 'Research Findings',
    content: 'User research insights from recent interviews. Key takeaway: users prefer card-based layouts.',
    properties: [
      { key: 'category', value: 'research', type: 'text' },
      { key: 'date', value: '2026-02-15', type: 'date' }
    ],
    createdAt: new Date('2026-02-15'),
    updatedAt: new Date('2026-02-15')
  },
  {
    id: '7',
    type: 'contact',
    title: 'Mike Chen',
    content: 'Lead Developer specializing in React and Node.js',
    properties: [
      { key: 'email', value: 'mike.chen@techcorp.com', type: 'email' },
      { key: 'phone', value: '+1 (555) 234-5678', type: 'phone' },
      { key: 'company', value: 'TechCorp', type: 'text' }
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600',
    createdAt: new Date('2026-01-20'),
    updatedAt: new Date('2026-02-12')
  },
  {
    id: '8',
    type: 'resource',
    title: 'Brand Assets',
    content: 'Logo files, color palettes, and typography guidelines',
    properties: [
      { key: 'type', value: 'assets', type: 'text' },
      { key: 'format', value: 'SVG, PNG', type: 'text' }
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=400&h=600',
    createdAt: new Date('2026-01-05'),
    updatedAt: new Date('2026-02-01')
  },
  {
    id: '9',
    type: 'event',
    title: 'Team Lunch',
    content: 'Monthly team lunch at the new Italian restaurant downtown',
    properties: [
      { key: 'date', value: '2026-03-10', type: 'date' },
      { key: 'time', value: '12:30 PM', type: 'text' },
      { key: 'location', value: 'Bella Cucina', type: 'text' }
    ],
    thumbnailUrl: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400&h=600',
    createdAt: new Date('2026-02-25'),
    updatedAt: new Date('2026-02-25')
  },
  {
    id: '10',
    type: 'note',
    title: 'Quick Ideas',
    content: 'Brainstorming session notes',
    properties: [
      { key: 'category', value: 'ideas', type: 'text' }
    ],
    createdAt: new Date('2026-02-26'),
    updatedAt: new Date('2026-02-26')
  }
];
