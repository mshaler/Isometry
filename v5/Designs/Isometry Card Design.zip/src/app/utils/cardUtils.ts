import { Card } from '../types/card';
import { FileText, User, Calendar, Package } from 'lucide-react';

export const getCardIcon = (type: Card['type']) => {
  switch (type) {
    case 'note':
      return FileText;
    case 'contact':
      return User;
    case 'event':
      return Calendar;
    case 'resource':
      return Package;
    default:
      return FileText;
  }
};

export const getCardColor = (type: Card['type']) => {
  switch (type) {
    case 'note':
      return 'bg-blue-500';
    case 'contact':
      return 'bg-green-500';
    case 'event':
      return 'bg-purple-500';
    case 'resource':
      return 'bg-orange-500';
    default:
      return 'bg-gray-500';
  }
};

export const getCardBorderColor = (type: Card['type']) => {
  switch (type) {
    case 'note':
      return 'border-blue-200';
    case 'contact':
      return 'border-green-200';
    case 'event':
      return 'border-purple-200';
    case 'resource':
      return 'border-orange-200';
    default:
      return 'border-gray-200';
  }
};

export const truncateText = (text: string, maxLength: number) => {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
};

export const stripMarkdown = (markdown: string) => {
  return markdown
    .replace(/#{1,6}\s/g, '') // Remove headers
    .replace(/\*\*(.+?)\*\*/g, '$1') // Remove bold
    .replace(/\*(.+?)\*/g, '$1') // Remove italic
    .replace(/\[(.+?)\]\(.+?\)/g, '$1') // Remove links
    .replace(/`(.+?)`/g, '$1') // Remove code
    .replace(/\n/g, ' ') // Replace newlines with spaces
    .trim();
};
