
  # Isometry Card Design

  This is a code bundle for Isometry Card Design. The original project is available at https://www.figma.com/design/5irH1caC2d3zLnvhLH4ZgB/Isometry-Card-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  