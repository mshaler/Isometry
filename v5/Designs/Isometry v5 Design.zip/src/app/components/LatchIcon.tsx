import { MapPin, ALargeSmall, Clock, Tag, BarChart3, Link } from 'lucide-react';
import { LatchIconName } from '../data/mockData';

interface LatchIconProps {
  iconName: LatchIconName;
  color: string;
  size?: number;
  className?: string;
}

export function LatchIcon({ iconName, color, size = 14, className = '' }: LatchIconProps) {
  const iconProps = {
    size,
    color,
    className,
    strokeWidth: 2,
  };

  switch (iconName) {
    case 'MapPin':
      return <MapPin {...iconProps} />;
    case 'ALargeSmall':
      return <ALargeSmall {...iconProps} />;
    case 'Clock':
      return <Clock {...iconProps} />;
    case 'Tag':
      return <Tag {...iconProps} />;
    case 'BarChart3':
      return <BarChart3 {...iconProps} />;
    case 'Link':
      return <Link {...iconProps} />;
    default:
      return null;
  }
}