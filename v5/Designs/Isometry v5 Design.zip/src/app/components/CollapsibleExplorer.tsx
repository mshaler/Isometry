import { useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { Theme } from '../themes';

interface CollapsibleExplorerProps {
  title: string | React.ReactNode;
  defaultCollapsed?: boolean;
  children: React.ReactNode;
  theme: Theme;
  fillRemaining?: boolean;
}

export function CollapsibleExplorer({ 
  title, 
  defaultCollapsed = false, 
  children, 
  theme,
  fillRemaining = false,
}: CollapsibleExplorerProps) {
  const [isCollapsed, setIsCollapsed] = useState(defaultCollapsed);

  return (
    <div 
      className={`w-full border-b ${fillRemaining ? 'flex flex-col flex-1 min-h-0' : ''}`}
      style={{
        backgroundColor: theme.colors.surface,
        borderColor: theme.colors.border,
      }}
    >
      {/* Header */}
      <button
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="w-full px-3 py-2 flex items-center gap-2 hover:opacity-80 transition-opacity"
        style={{
          backgroundColor: theme.colors.surfaceElevated,
          borderBottom: isCollapsed ? 'none' : `1px solid ${theme.colors.border}`,
        }}
      >
        {isCollapsed ? (
          <ChevronRight className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
        ) : (
          <ChevronDown className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
        )}
        {typeof title === 'string' ? (
          <span 
            className="text-xs font-medium uppercase tracking-wide"
            style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}
          >
            {title}
          </span>
        ) : (
          title
        )}
      </button>

      {/* Content */}
      {!isCollapsed && (
        <div className={fillRemaining ? 'flex-1 flex flex-col min-h-0 overflow-hidden' : ''}>
          {children}
        </div>
      )}
    </div>
  );
}