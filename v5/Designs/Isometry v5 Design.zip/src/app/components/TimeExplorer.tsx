import { useState, useEffect, useRef } from 'react';
import { MapPin, ALargeSmall, Clock, Tag, BarChart3, X, Play, Pause } from 'lucide-react';
import { Theme } from '../themes';

interface TimeExplorerProps {
  onLocationFilter: (filter: any) => void;
  onAlphabetFilter: (filter: any) => void;
  onTimeFilter: (filter: any) => void;
  onCategoryFilter: (filter: any) => void;
  onHierarchyFilter: (filter: any) => void;
  theme: Theme;
}

export function TimeExplorer({
  onLocationFilter,
  onAlphabetFilter,
  onTimeFilter,
  onCategoryFilter,
  onHierarchyFilter,
  theme,
}: TimeExplorerProps) {
  const [alphabetQuery, setAlphabetQuery] = useState('');
  const [timeRange, setTimeRange] = useState([0, 100]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [hierarchyRange, setHierarchyRange] = useState([1, 5]);
  const [zoomLevel, setZoomLevel] = useState(2);
  const [mapZoom, setMapZoom] = useState(2);
  const [distanceRadius, setDistanceRadius] = useState(50);

  const playRef = useRef<HTMLButtonElement>(null);
  const pauseRef = useRef<HTMLButtonElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime(prev => {
          const newTime = prev + 1;
          if (newTime > 100) {
            setIsPlaying(false);
            return 0;
          }
          return newTime;
        });
      }, 100);
    }
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isPlaying]);

  useEffect(() => {
    setTimeRange([currentTime, currentTime]);
  }, [currentTime]);

  return (
    <div className="flex-1 flex overflow-hidden" style={{ backgroundColor: theme.colors.background }}>
      {/* Zoom Slider - Left Side */}
      <div 
        className="w-12 flex flex-col items-center py-4"
        style={{
          borderRight: `1px solid ${theme.colors.border}`,
          backgroundColor: theme.colors.surface,
          ...(theme.effects.blur && {
            backdropFilter: 'blur(40px)',
            WebkitBackdropFilter: 'blur(40px)',
          }),
        }}
      >
        <div 
          className="text-[9px] mb-2 [writing-mode:vertical-lr] rotate-180"
          style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}
        >
          ZOOM
        </div>
        
        <div className="flex-1 flex items-center justify-center">
          <input
            type="range"
            min="0"
            max="4"
            step="1"
            value={zoomLevel}
            onChange={(e) => setZoomLevel(Number(e.target.value))}
            orient="vertical"
            className="h-full appearance-none bg-transparent cursor-pointer"
            style={{
              writingMode: 'bt-lr',
              WebkitAppearance: 'slider-vertical',
              width: '6px',
            }}
          />
        </div>

        <div 
          className="text-[9px] mt-2 [writing-mode:vertical-lr] rotate-180"
          style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}
        >
          PAN
        </div>

        <div 
          className="mt-3 text-[10px]"
          style={{ color: theme.colors.text, fontFamily: theme.fonts.ui }}
        >
          {zoomLevel}
        </div>
      </div>

      {/* LATCH Explorers Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 p-2 space-y-2 overflow-y-auto">
          {/* Location - Compact Map Explorer */}
          <div className="space-y-1">
            {/* Location Label */}
            <div className="flex items-center gap-2 px-1">
              <MapPin className="w-4 h-4 text-[#4A90D9] flex-shrink-0" />
              <span className="text-[11px]" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>Location</span>
            </div>
            
            {/* Map Container */}
            <div 
              className="h-[120px] flex overflow-hidden border"
              style={{ 
                backgroundColor: theme.colors.background,
                borderColor: theme.colors.borderSubtle,
                borderRadius: theme.effects.borderRadius,
              }}
            >
              {/* Map Content Area */}
              <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
                {/* Map View with Minimap */}
                <div className="flex-1 relative overflow-hidden" style={{ backgroundColor: theme.colors.surfaceElevated }}>
                  {/* Main Map Placeholder */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div 
                      className="w-full h-full flex items-center justify-center"
                      style={{
                        backgroundColor: theme.colors.surface,
                        backgroundImage: `repeating-linear-gradient(
                          0deg,
                          ${theme.colors.border} 0px,
                          ${theme.colors.border} 1px,
                          transparent 1px,
                          transparent 20px
                        ),
                        repeating-linear-gradient(
                          90deg,
                          ${theme.colors.border} 0px,
                          ${theme.colors.border} 1px,
                          transparent 1px,
                          transparent 20px
                        )`,
                      }}
                    >
                      <div className="text-center">
                        <MapPin className="w-6 h-6 mx-auto mb-1" style={{ color: theme.colors.textMuted }} />
                        <div className="text-[10px]" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>
                          Boulder, CO
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Minimap Navigator - Bottom Right */}
                  <div 
                    className="absolute bottom-2 right-2 w-20 h-16 border overflow-hidden"
                    style={{
                      borderColor: theme.colors.border,
                      borderRadius: theme.effects.borderRadius,
                      backgroundColor: theme.colors.surface,
                      boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
                    }}
                  >
                    {/* Simple map representation */}
                    <div className="relative w-full h-full bg-[#F2EFE9]">
                      <div className="absolute inset-0 flex items-center justify-center text-[6px]" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.mono }}>
                        <MapPin className="w-3 h-3 text-red-500" />
                      </div>
                      
                      {/* Viewport indicator */}
                      <div 
                        className="absolute border border-blue-500"
                        style={{
                          left: '25%',
                          top: '25%',
                          width: '50%',
                          height: '50%',
                          pointerEvents: 'none',
                        }}
                      />
                    </div>
                  </div>
                </div>

                {/* Distance Slider - Bottom */}
                <div 
                  className="px-2 py-1.5 flex items-center gap-2"
                  style={{
                    borderTop: `1px solid ${theme.colors.border}`,
                    backgroundColor: theme.colors.surface,
                  }}
                >
                  <MapPin className="w-3 h-3 flex-shrink-0" style={{ color: '#4A90D9' }} />
                  <span className="text-[10px] w-16" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>Distance</span>
                  
                  <div className="flex-1 flex items-center gap-2">
                    <input
                      type="range"
                      min="1"
                      max="200"
                      step="1"
                      value={distanceRadius}
                      onChange={(e) => setDistanceRadius(Number(e.target.value))}
                      className="flex-1"
                      style={{
                        accentColor: '#4A90D9',
                      }}
                    />
                    <div 
                      className="text-[10px] font-mono w-12 text-right"
                      style={{ color: theme.colors.text }}
                    >
                      {distanceRadius} mi
                    </div>
                  </div>

                  {/* Quick Distance Buttons */}
                  <div className="flex gap-0.5">
                    {[10, 25, 50, 100].map(distance => (
                      <button
                        key={distance}
                        onClick={() => setDistanceRadius(distance)}
                        className="px-1.5 py-0.5 text-[9px] border transition-all"
                        style={{
                          backgroundColor: distanceRadius === distance ? '#4A90D9' + '33' : theme.colors.surfaceElevated,
                          color: distanceRadius === distance ? theme.colors.text : theme.colors.textMuted,
                          borderColor: distanceRadius === distance ? '#4A90D9' : theme.colors.border,
                          borderRadius: theme.effects.borderRadius,
                        }}
                        onMouseEnter={(e) => {
                          if (distanceRadius !== distance) {
                            e.currentTarget.style.backgroundColor = theme.colors.hover;
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (distanceRadius !== distance) {
                            e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated;
                          }
                        }}
                      >
                        {distance}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Alphabet Slider */}
          <div 
            className="flex items-center gap-3 py-2"
            style={{ borderBottom: `1px solid ${theme.colors.borderSubtle}` }}
          >
            <ALargeSmall className="w-4 h-4 text-[#7CB342] flex-shrink-0" />
            <span className="text-[11px] w-20" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>Alpha</span>
            <div className="flex-1 flex items-center gap-2">
              <input
                type="text"
                placeholder="Search..."
                value={alphabetQuery}
                onChange={(e) => setAlphabetQuery(e.target.value)}
                className="flex-1 h-7 px-2 text-[11px] border outline-none"
                style={{
                  backgroundColor: theme.colors.surfaceElevated,
                  color: theme.colors.text,
                  borderColor: theme.colors.border,
                  borderRadius: theme.effects.borderRadius,
                  ...(theme.name === 'nextstep' && {
                    boxShadow: theme.effects.shadow,
                    borderStyle: theme.effects.borderStyle,
                  }),
                }}
              />
              <select 
                className="h-7 px-2 text-[11px] border outline-none"
                style={{
                  backgroundColor: theme.colors.surfaceElevated,
                  color: theme.colors.text,
                  borderColor: theme.colors.border,
                  borderRadius: theme.effects.borderRadius,
                  ...(theme.name === 'nextstep' && {
                    boxShadow: theme.effects.shadow,
                    borderStyle: theme.effects.borderStyle,
                  }),
                }}
              >
                <option>A→Z</option>
                <option>Z→A</option>
                <option>Count</option>
              </select>
            </div>
            {alphabetQuery && (
              <button
                onClick={() => setAlphabetQuery('')}
                className="p-1"
                style={{ borderRadius: theme.effects.borderRadius }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
              >
                <X className="w-3 h-3" style={{ color: theme.colors.textMuted }} />
              </button>
            )}
          </div>

          {/* Time Slider */}
          <div 
            className="flex items-center gap-3 py-2"
            style={{ borderBottom: `1px solid ${theme.colors.borderSubtle}` }}
          >
            <Clock className="w-4 h-4 text-[#FF9800] flex-shrink-0" />
            <span className="text-[11px] w-20" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>Time</span>
            <div className="flex-1">
              {/* Timeline Histogram with Playhead */}
              <div 
                className="relative h-12 p-1 mb-1 border"
                style={{
                  backgroundColor: theme.colors.surfaceElevated,
                  borderColor: theme.colors.border,
                  borderRadius: theme.effects.borderRadius,
                  ...(theme.name === 'nextstep' && {
                    boxShadow: 'inset 2px 2px 4px rgba(0,0,0,0.2)',
                  }),
                }}
              >
                {/* Histogram Bars */}
                <div className="flex items-end justify-between h-full gap-[1px]">
                  {[3, 5, 7, 5, 3, 1, 3, 5, 7, 10, 7, 5, 3, 5, 7, 5, 3, 2, 4, 6, 8, 9, 7, 5, 3, 4, 5, 6, 4, 3].map((height, i) => {
                    const totalBars = 30;
                    const barPosition = (i / totalBars) * 100;
                    const nextBarPosition = ((i + 1) / totalBars) * 100;
                    
                    // Check if this bar is in the "played" region
                    const isPlayed = currentTime >= nextBarPosition;
                    // Check if this bar is the "current" bar being played
                    const isCurrent = currentTime >= barPosition && currentTime < nextBarPosition;
                    
                    return (
                      <div
                        key={i}
                        className="w-[2px] rounded-sm transition-all duration-100"
                        style={{ 
                          height: `${height * 10}%`,
                          backgroundColor: isCurrent 
                            ? '#FF9800' // Current bar - full orange
                            : isPlayed 
                            ? '#FF9800aa' // Played bars - semi-transparent orange
                            : '#FF9800' + '40', // Unplayed bars - very transparent orange
                          boxShadow: isCurrent ? '0 0 4px rgba(255, 152, 0, 0.8)' : 'none',
                          transform: isCurrent ? 'scaleY(1.1)' : 'scaleY(1)',
                          transformOrigin: 'bottom',
                        }}
                      />
                    );
                  })}
                </div>
                
                {/* Playhead Indicator */}
                {isPlaying && (
                  <div 
                    className="absolute top-0 bottom-0 w-0.5 bg-[#FF9800] shadow-lg transition-all pointer-events-none"
                    style={{
                      left: `${currentTime}%`,
                      boxShadow: '0 0 8px rgba(255, 152, 0, 0.8)',
                    }}
                  >
                    {/* Playhead Handle */}
                    <div 
                      className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-[#FF9800] border-2"
                      style={{
                        borderColor: theme.colors.surface,
                        boxShadow: '0 0 4px rgba(255, 152, 0, 0.6)',
                      }}
                    />
                  </div>
                )}
              </div>
              
              {/* Replay Controls Row */}
              <div className="flex items-center gap-2 mb-1">
                {/* Play/Pause Button */}
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="flex items-center justify-center w-7 h-7 border transition-all"
                  style={{
                    backgroundColor: isPlaying ? '#FF9800' + '22' : theme.colors.surfaceElevated,
                    color: isPlaying ? '#FF9800' : theme.colors.textMuted,
                    borderColor: isPlaying ? '#FF9800' : theme.colors.border,
                    borderRadius: theme.effects.borderRadius,
                  }}
                  onMouseEnter={(e) => {
                    if (!isPlaying) {
                      e.currentTarget.style.backgroundColor = theme.colors.hover;
                      e.currentTarget.style.color = theme.colors.text;
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isPlaying) {
                      e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated;
                      e.currentTarget.style.color = theme.colors.textMuted;
                    }
                  }}
                >
                  {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 translate-x-[1px]" />}
                </button>
                
                {/* Progress Bar/Scrubber */}
                <div className="flex-1 relative h-7 flex items-center">
                  <div 
                    className="absolute w-full h-1 rounded-full overflow-hidden"
                    style={{
                      backgroundColor: theme.colors.border,
                    }}
                  >
                    {/* Progress Fill */}
                    <div 
                      className="h-full bg-[#FF9800] transition-all"
                      style={{
                        width: `${currentTime}%`,
                      }}
                    />
                  </div>
                  {/* Scrubber Input */}
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={currentTime}
                    onChange={(e) => {
                      setCurrentTime(parseInt(e.target.value));
                      setIsPlaying(false);
                    }}
                    className="absolute w-full cursor-pointer opacity-0 z-10"
                  />
                </div>
                
                {/* Time Display */}
                <div 
                  className="text-[10px] font-mono w-12 text-right"
                  style={{ color: theme.colors.textMuted }}
                >
                  {currentTime}%
                </div>
              </div>
              
              {/* Range Slider */}
              <div className="relative h-6 flex items-center">
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={timeRange[0]}
                  onChange={(e) => setTimeRange([parseInt(e.target.value), timeRange[1]])}
                  className="absolute w-full"
                />
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={timeRange[1]}
                  onChange={(e) => setTimeRange([timeRange[0], parseInt(e.target.value)])}
                  className="absolute w-full"
                />
              </div>
              {/* Shortcuts */}
              <div className="flex gap-1 mt-1">
                {['Today', 'This Week', 'This Month', 'This Quarter', 'This Year', 'All Time'].map(label => (
                  <button
                    key={label}
                    className="px-2 py-0.5 text-[10px] border"
                    style={{
                      backgroundColor: theme.colors.surfaceElevated,
                      color: theme.colors.textMuted,
                      borderColor: theme.colors.border,
                      borderRadius: theme.effects.borderRadius,
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = theme.colors.hover;
                      e.currentTarget.style.color = theme.colors.text;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated;
                      e.currentTarget.style.color = theme.colors.textMuted;
                    }}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
            <button 
              className="p-1"
              style={{ borderRadius: theme.effects.borderRadius }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
            >
              <X className="w-3 h-3" style={{ color: theme.colors.textMuted }} />
            </button>
          </div>

          {/* Category Slider */}
          <div 
            className="flex items-center gap-3 py-2"
            style={{ borderBottom: `1px solid ${theme.colors.borderSubtle}` }}
          >
            <Tag className="w-4 h-4 text-[#9C27B0] flex-shrink-0" />
            <span className="text-[11px] w-20" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>Category</span>
            <div className="flex-1 flex flex-wrap gap-1">
              {['Work', 'Personal', 'Meeting', 'Research', 'Planning'].map(cat => {
                const isSelected = selectedCategories.includes(cat);
                return (
                  <button
                    key={cat}
                    onClick={() => {
                      setSelectedCategories(prev =>
                        prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
                      );
                    }}
                    className="px-2 py-1 text-[11px] border transition-all"
                    style={{
                      backgroundColor: isSelected ? '#9C27B0' + '33' : 'transparent',
                      borderColor: isSelected ? '#9C27B0' : '#9C27B0' + '80',
                      color: isSelected ? theme.colors.text : theme.colors.textMuted,
                      borderRadius: theme.effects.borderRadius,
                    }}
                  >
                    {cat}
                  </button>
                );
              })}
              <button 
                className="px-2 py-1 text-[10px] border"
                style={{
                  color: theme.colors.textSecondary,
                  borderColor: theme.colors.border,
                  borderRadius: theme.effects.borderRadius,
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
              >
                AND/OR
              </button>
            </div>
            {selectedCategories.length > 0 && (
              <button
                onClick={() => setSelectedCategories([])}
                className="p-1"
                style={{ borderRadius: theme.effects.borderRadius }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
              >
                <X className="w-3 h-3" style={{ color: theme.colors.textMuted }} />
              </button>
            )}
          </div>

          {/* Hierarchy Slider - ROYGBIV */}
          <div className="flex items-center gap-3 py-2">
            <BarChart3 className="w-4 h-4 text-[#E53935] flex-shrink-0" />
            <span className="text-[11px] w-20" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>Hierarchy</span>
            <div className="flex-1">
              {/* ROYGBIV Rainbow Scale */}
              <div 
                className="relative h-8 border overflow-hidden"
                style={{
                  borderColor: theme.colors.border,
                  borderRadius: theme.effects.borderRadius,
                }}
              >
                <div className="absolute inset-0 flex">
                  <div className="flex-1 bg-[#FF0000]"></div> {/* Red */}
                  <div className="flex-1 bg-[#FF7F00]"></div> {/* Orange */}
                  <div className="flex-1 bg-[#FFFF00]"></div> {/* Yellow */}
                  <div className="flex-1 bg-[#00FF00]"></div> {/* Green */}
                  <div className="flex-1 bg-[#0000FF]"></div> {/* Blue */}
                  <div className="flex-1 bg-[#4B0082]"></div> {/* Indigo */}
                  <div className="flex-1 bg-[#9400D3]"></div> {/* Violet */}
                </div>
                <div className="absolute inset-0 flex items-center justify-between px-2 text-[10px] text-white font-bold drop-shadow-[0_1px_1px_rgba(0,0,0,0.8)]">
                  <span>1</span>
                  <span>2</span>
                  <span>3</span>
                  <span>4</span>
                  <span>5</span>
                </div>
              </div>
              {/* Range Slider on top */}
              <div className="relative h-6 flex items-center -mt-7 z-10">
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={hierarchyRange[0]}
                  onChange={(e) => setHierarchyRange([parseInt(e.target.value), hierarchyRange[1]])}
                  className="absolute w-full"
                />
                <input
                  type="range"
                  min="1"
                  max="5"
                  value={hierarchyRange[1]}
                  onChange={(e) => setHierarchyRange([hierarchyRange[0], parseInt(e.target.value)])}
                  className="absolute w-full"
                />
              </div>
              {/* Semantic Labels */}
              <div className="flex gap-1 mt-2">
                {['Critical', 'High', 'Medium', 'Low', 'None'].map(label => (
                  <button
                    key={label}
                    className="flex-1 px-2 py-0.5 text-[10px] border"
                    style={{
                      backgroundColor: theme.colors.surfaceElevated,
                      color: theme.colors.textMuted,
                      borderColor: theme.colors.border,
                      borderRadius: theme.effects.borderRadius,
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = theme.colors.hover;
                      e.currentTarget.style.color = theme.colors.text;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated;
                      e.currentTarget.style.color = theme.colors.textMuted;
                    }}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
            <button 
              className="p-1"
              style={{ borderRadius: theme.effects.borderRadius }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
            >
              <X className="w-3 h-3" style={{ color: theme.colors.textMuted }} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}