import { useState } from 'react';
import { ChevronRight, ChevronDown, Edit2 } from 'lucide-react';
import { Checkbox } from './ui/checkbox';
import { Property, LATCH_COLUMNS } from '../data/mockData';
import { LatchIcon } from './LatchIcon';
import { Theme } from '../themes';

interface PropertiesExplorerProps {
  properties: Property[];
  onPropertyToggle: (id: string) => void;
  onPropertyRename: (id: string, newName: string) => void;
  theme: Theme;
}

export function PropertiesExplorer({ properties, onPropertyToggle, onPropertyRename, theme }: PropertiesExplorerProps) {
  const [collapsedColumns, setCollapsedColumns] = useState<Set<string>>(new Set());
  const [editingProperty, setEditingProperty] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');

  // Strip emojis from display names
  const stripEmojis = (text: string) => {
    return text.replace(/[\u{1F000}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F300}-\u{1F5FF}\u{1F600}-\u{1F64F}\u{1F680}-\u{1F6FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{FE00}-\u{FE0F}\u{200D}]/gu, '').trim();
  };

  const toggleColumn = (columnKey: string) => {
    const newCollapsed = new Set(collapsedColumns);
    if (newCollapsed.has(columnKey)) {
      newCollapsed.delete(columnKey);
    } else {
      newCollapsed.add(columnKey);
    }
    setCollapsedColumns(newCollapsed);
  };

  const startEdit = (property: Property) => {
    setEditingProperty(property.id);
    setEditValue(property.displayName);
  };

  const finishEdit = (propertyId: string) => {
    if (editValue.trim()) {
      onPropertyRename(propertyId, stripEmojis(editValue.trim()));
    }
    setEditingProperty(null);
  };

  return (
    <div 
      className="w-full max-h-48 overflow-y-auto"
      style={{
        backgroundColor: theme.colors.surface,
        ...(theme.effects.blur && {
          backdropFilter: 'blur(40px)',
          WebkitBackdropFilter: 'blur(40px)',
        }),
      }}
    >
      <div className="grid grid-cols-6 gap-1 p-1">
        {LATCH_COLUMNS.map((column) => {
          const columnProps = properties.filter(p => p.axis === column.key);
          const checkedCount = columnProps.filter(p => p.checked).length;
          const isCollapsed = collapsedColumns.has(column.key);

          return (
            <div 
              key={column.key} 
              className="overflow-hidden flex flex-col"
              style={{
                backgroundColor: theme.colors.surfaceElevated,
                borderRadius: theme.effects.borderRadius,
                border: `1px solid ${theme.colors.border}`,
                ...(theme.name === 'nextstep' && {
                  boxShadow: theme.effects.shadow,
                  borderWidth: '2px',
                  borderStyle: theme.effects.borderStyle,
                  borderColor: theme.colors.border,
                }),
                ...(theme.effects.blur && {
                  backdropFilter: 'blur(20px)',
                  WebkitBackdropFilter: 'blur(20px)',
                  boxShadow: '0 4px 16px rgba(0, 0, 0, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
                }),
              }}
            >
              {/* Column Header */}
              <div 
                className="flex items-center justify-between px-2 py-1.5 cursor-pointer"
                style={{
                  backgroundColor: theme.colors.surface,
                  borderBottom: `1px solid ${theme.colors.border}`,
                }}
                onClick={() => toggleColumn(column.key)}
              >
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <LatchIcon iconName={column.iconName} color={column.color} size={14} />
                  <span 
                    className="text-[11px] font-semibold truncate uppercase tracking-wide" 
                    style={{ 
                      color: theme.colors.text,
                      fontFamily: theme.fonts.ui,
                    }}
                  >
                    {column.label}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  <span 
                    className="text-[10px] px-1.5 py-0.5 rounded"
                    style={{
                      backgroundColor: theme.colors.background,
                      color: theme.colors.textMuted,
                      borderRadius: theme.effects.borderRadius,
                      fontFamily: theme.fonts.mono,
                    }}
                  >
                    {checkedCount}
                  </span>
                  <div style={{ color: theme.colors.textMuted }}>
                    {isCollapsed ? <ChevronRight className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                  </div>
                </div>
              </div>

              {/* Property Chips */}
              {!isCollapsed && (
                <div className="flex flex-col">
                  {columnProps.map((property) => (
                    <div
                      key={property.id}
                      className="group relative flex items-center gap-2 h-7 px-2 border-l-[3px] transition-all"
                      style={{
                        borderLeftColor: property.checked ? column.color : 'transparent',
                        backgroundColor: property.checked ? `${column.color}15` : 'transparent',
                        opacity: property.checked ? 1 : 0.6,
                      }}
                      onMouseEnter={(e) => {
                        if (property.checked) return;
                        e.currentTarget.style.backgroundColor = `${theme.colors.hover}50`;
                      }}
                      onMouseLeave={(e) => {
                        if (property.checked) return;
                        e.currentTarget.style.backgroundColor = 'transparent';
                      }}
                    >
                      {/* Checkbox */}
                      <Checkbox
                        checked={property.checked}
                        onCheckedChange={() => onPropertyToggle(property.id)}
                        className="h-3.5 w-3.5"
                        style={{ borderColor: theme.colors.border }}
                      />

                      {/* LATCH Icon */}
                      <LatchIcon iconName={column.iconName} color={column.color} size={12} />

                      {/* Display Name */}
                      {editingProperty === property.id ? (
                        <input
                          type="text"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          onBlur={() => finishEdit(property.id)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') finishEdit(property.id);
                            if (e.key === 'Escape') setEditingProperty(null);
                          }}
                          autoFocus
                          className="flex-1 text-[13px] px-1 py-0 outline-none"
                          style={{
                            backgroundColor: theme.colors.background,
                            color: theme.colors.text,
                            border: `1px solid ${theme.colors.border}`,
                            borderRadius: theme.effects.borderRadius,
                          }}
                        />
                      ) : (
                        <span className="flex-1 text-[13px] truncate" style={{ color: theme.colors.text }}>
                          {stripEmojis(property.displayName)}
                        </span>
                      )}

                      {/* Edit Button */}
                      <button
                        onClick={() => startEdit(property)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-0.5"
                        style={{
                          borderRadius: theme.effects.borderRadius,
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                      >
                        <Edit2 className="w-3 h-3" style={{ color: theme.colors.textMuted }} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}