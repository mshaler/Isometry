import { useState, useRef, useEffect } from 'react';
import { Theme } from '../themes';

interface MenuItem {
  label: string;
  shortcut?: string;
  divider?: boolean;
  submenu?: MenuItem[];
  onClick?: () => void;
}

interface MenuDropdownProps {
  trigger: React.ReactNode;
  items: MenuItem[];
  theme: Theme;
}

export function MenuDropdown({ trigger, items, theme }: MenuDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [openSubmenu, setOpenSubmenu] = useState<string | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setOpenSubmenu(null);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const renderMenuItem = (item: MenuItem, depth: number = 0) => {
    if (item.divider) {
      return (
        <div
          className="h-px my-1"
          style={{
            backgroundColor: theme.colors.border,
          }}
        />
      );
    }

    const hasSubmenu = item.submenu && item.submenu.length > 0;
    const isSubmenuOpen = openSubmenu === item.label;

    return (
      <div
        key={item.label}
        className="relative"
        onMouseEnter={() => hasSubmenu && setOpenSubmenu(item.label)}
        onMouseLeave={() => hasSubmenu && setOpenSubmenu(null)}
      >
        <button
          className="w-full px-3 py-1.5 text-left flex items-center justify-between text-[13px] transition-colors"
          style={{
            color: theme.colors.text,
            fontFamily: theme.fonts.ui,
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = theme.colors.hover;
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'transparent';
          }}
          onClick={() => {
            if (item.onClick) {
              item.onClick();
              setIsOpen(false);
              setOpenSubmenu(null);
            }
          }}
        >
          <span>{item.label}</span>
          <div className="flex items-center gap-2">
            {item.shortcut && (
              <span
                className="text-[11px]"
                style={{
                  color: theme.colors.textMuted,
                  fontFamily: theme.fonts.mono,
                }}
              >
                {item.shortcut}
              </span>
            )}
            {hasSubmenu && (
              <span style={{ color: theme.colors.textMuted }}>▸</span>
            )}
          </div>
        </button>

        {/* Submenu */}
        {hasSubmenu && isSubmenuOpen && (
          <div
            className="absolute left-full top-0 ml-1 min-w-[180px] py-1 shadow-lg z-50"
            style={{
              backgroundColor: theme.colors.surface,
              border: `1px solid ${theme.colors.border}`,
              borderRadius: theme.effects.borderRadius,
              ...(theme.effects.blur && {
                backdropFilter: 'blur(40px)',
                WebkitBackdropFilter: 'blur(40px)',
              }),
              ...(theme.name === 'nextstep' && {
                boxShadow: theme.effects.shadow,
                borderStyle: theme.effects.borderStyle,
              }),
            }}
          >
            {item.submenu!.map((subItem) => renderMenuItem(subItem, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div ref={menuRef} className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-1 transition-colors"
        style={{
          borderRadius: theme.effects.borderRadius,
        }}
        onMouseEnter={(e) => {
          if (!isOpen) {
            e.currentTarget.style.backgroundColor = theme.colors.hover;
          }
        }}
        onMouseLeave={(e) => {
          if (!isOpen) {
            e.currentTarget.style.backgroundColor = 'transparent';
          }
        }}
      >
        {trigger}
      </button>

      {isOpen && (
        <div
          className="absolute left-0 top-full mt-1 min-w-[200px] py-1 shadow-lg z-50"
          style={{
            backgroundColor: theme.colors.surface,
            border: `1px solid ${theme.colors.border}`,
            borderRadius: theme.effects.borderRadius,
            ...(theme.effects.blur && {
              backdropFilter: 'blur(40px)',
              WebkitBackdropFilter: 'blur(40px)',
            }),
            ...(theme.name === 'nextstep' && {
              boxShadow: theme.effects.shadow,
              borderStyle: theme.effects.borderStyle,
            }),
          }}
        >
          {items.map((item) => renderMenuItem(item))}
        </div>
      )}
    </div>
  );
}
