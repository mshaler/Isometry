import { useDrag, useDrop } from 'react-dnd';
import { Property } from '../data/mockData';
import { GripVertical } from 'lucide-react';
import { LATCH_COLUMNS } from '../data/mockData';
import { LatchIcon } from './LatchIcon';
import { Theme } from '../themes';

const ITEM_TYPE = 'AXIS_CHIP';

// Strip emojis from display names
const stripEmojis = (text: string) => {
  return text.replace(/[\u{1F000}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F300}-\u{1F5FF}\u{1F600}-\u{1F64F}\u{1F680}-\u{1F6FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{FE00}-\u{FE0F}\u{200D}]/gu, '').trim();
};

interface AxisChip {
  propertyId: string;
  property: Property;
  sourceWell: 'available' | 'x' | 'y' | 'z';
}

interface ProjectionExplorerProps {
  availableProperties: Property[];
  xAxisProperties: Property[];
  yAxisProperties: Property[];
  zAxisProperties: Property[];
  displayProperty: Property | null;
  auditViewEnabled: boolean;
  cardDensity: 'compact' | 'standard' | 'expanded' | 'full';
  aggregationMode: 'count' | 'sum' | 'average' | 'min' | 'max' | 'list';
  onMoveProperty: (propertyId: string, fromWell: string, toWell: string) => void;
  onReorderProperty: (well: string, fromIndex: number, toIndex: number) => void;
  onDisplayPropertyChange: (propertyId: string) => void;
  onAuditViewToggle: () => void;
  onCardDensityChange: (density: 'compact' | 'standard' | 'expanded' | 'full') => void;
  onAggregationModeChange: (mode: 'count' | 'sum' | 'average' | 'min' | 'max' | 'list') => void;
  theme: Theme;
}

function DraggableChip({ 
  property, 
  sourceWell, 
  index,
  onMove,
  theme
}: { 
  property: Property; 
  sourceWell: 'available' | 'x' | 'y' | 'z';
  index: number;
  onMove: (propertyId: string, fromWell: string, toWell: string, index?: number) => void;
  theme: Theme;
}) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: ITEM_TYPE,
    item: { propertyId: property.id, property, sourceWell, index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }));

  const axisColor = LATCH_COLUMNS.find(col => col.key === property.axis)?.color || '#78909C';
  const axisIconName = LATCH_COLUMNS.find(col => col.key === property.axis)?.iconName || 'Link';

  return (
    <div
      ref={drag}
      className={`
        flex items-center gap-2 h-7 px-2 cursor-move
        border-l-[3px] transition-all
        ${isDragging ? 'opacity-40 scale-95' : 'opacity-100'}
      `}
      style={{ 
        borderLeftColor: axisColor,
        backgroundColor: theme.colors.surfaceElevated,
        borderRadius: theme.effects.borderRadius,
        ...(theme.name === 'nextstep' && {
          boxShadow: theme.effects.shadow,
          borderWidth: '2px',
          borderStyle: theme.effects.borderStyle,
          borderColor: theme.colors.border,
        }),
      }}
      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
    >
      <GripVertical className="w-3 h-3" style={{ color: theme.colors.textMuted }} />
      <LatchIcon iconName={axisIconName} color={axisColor} size={12} />
      <span className="flex-1 text-[13px] truncate" style={{ color: theme.colors.text }}>
        {stripEmojis(property.displayName)}
      </span>
    </div>
  );
}

function DropWell({ 
  wellId, 
  label, 
  properties, 
  width, 
  onDrop,
  onReorder,
  children,
  theme
}: { 
  wellId: 'available' | 'x' | 'y' | 'z'; 
  label: string; 
  properties: Property[]; 
  width: string;
  onDrop: (propertyId: string, fromWell: string, toWell: string, index?: number) => void;
  onReorder: (well: string, fromIndex: number, toIndex: number) => void;
  children?: React.ReactNode;
  theme: Theme;
}) {
  const [{ isOver, canDrop }, drop] = useDrop(() => ({
    accept: ITEM_TYPE,
    drop: (item: AxisChip) => {
      onDrop(item.propertyId, item.sourceWell, wellId);
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
      canDrop: monitor.canDrop(),
    }),
  }));

  return (
    <div className={width}>
      <div className="mb-1 px-2">
        <span className="text-[11px] uppercase tracking-wide" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>
          {label}
        </span>
      </div>
      <div
        ref={drop}
        className="h-64 p-2 border-2 transition-all overflow-y-auto"
        style={{
          backgroundColor: theme.colors.surfaceElevated,
          borderColor: isOver && canDrop ? theme.colors.focus : theme.colors.border,
          borderRadius: theme.effects.borderRadius,
          ...(isOver && canDrop && {
            backgroundColor: `${theme.colors.focus}10`,
          }),
          ...(theme.name === 'nextstep' && {
            boxShadow: 'inset 2px 2px 4px rgba(0,0,0,0.3), inset -2px -2px 4px rgba(255,255,255,0.2)',
          }),
        }}
      >
        <div className="flex flex-col gap-1">
          {properties.map((prop, index) => (
            <DraggableChip 
              key={prop.id} 
              property={prop} 
              sourceWell={wellId} 
              index={index}
              onMove={onDrop}
              theme={theme}
            />
          ))}
          {children}
        </div>
      </div>
    </div>
  );
}

export function ProjectionExplorer({
  availableProperties,
  xAxisProperties,
  yAxisProperties,
  zAxisProperties,
  displayProperty,
  auditViewEnabled,
  cardDensity,
  aggregationMode,
  onMoveProperty,
  onReorderProperty,
  onDisplayPropertyChange,
  onAuditViewToggle,
  onCardDensityChange,
  onAggregationModeChange,
  theme,
}: ProjectionExplorerProps) {
  const textProperties = availableProperties.filter(p => p.type === 'text');

  return (
    <div 
      className="w-full p-2 max-h-80 overflow-y-auto"
      style={{
        backgroundColor: theme.colors.surface,
        ...(theme.effects.blur && {
          backdropFilter: 'blur(40px)',
          WebkitBackdropFilter: 'blur(40px)',
        }),
      }}
    >
      <div className="flex gap-2">
        {/* Available Well */}
        <div className="w-[34%] flex flex-col">
          <div className="mb-1 px-2 h-8 flex items-center">
            <span className="text-[11px] uppercase tracking-wide leading-tight" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>
              Available<br />Properties
            </span>
          </div>
          <DropWell
            wellId="available"
            label=""
            properties={availableProperties}
            width="w-full"
            onDrop={onMoveProperty}
            onReorder={onReorderProperty}
            theme={theme}
          />
        </div>

        {/* X Plane Well (Rows) */}
        <div className="w-[22%] flex flex-col">
          <div className="mb-1 px-2 h-8 flex items-center">
            <span className="text-[11px] uppercase tracking-wide leading-tight" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>
              X-Plane<br />Rows
            </span>
          </div>
          <DropWell
            wellId="x"
            label=""
            properties={xAxisProperties}
            width="w-full"
            onDrop={onMoveProperty}
            onReorder={onReorderProperty}
            theme={theme}
          />
        </div>

        {/* Y Plane Well (Columns) */}
        <div className="w-[22%] flex flex-col">
          <div className="mb-1 px-2 h-8 flex items-center">
            <span className="text-[11px] uppercase tracking-wide leading-tight" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>
              Y-Plane<br />Columns
            </span>
          </div>
          <DropWell
            wellId="y"
            label=""
            properties={yAxisProperties}
            width="w-full"
            onDrop={onMoveProperty}
            onReorder={onReorderProperty}
            theme={theme}
          />
        </div>

        {/* Z Plane Well with Controls */}
        <div className="w-[22%] flex flex-col">
          <div className="mb-1 px-2 h-8 flex items-center">
            <span className="text-[11px] uppercase tracking-wide leading-tight" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>
              Z-Plane<br />Layers
            </span>
          </div>
          <DropWell
            wellId="z"
            label=""
            properties={zAxisProperties}
            width="w-full"
            onDrop={onMoveProperty}
            onReorder={onReorderProperty}
            theme={theme}
          >
            {/* Display Property Dropdown */}
            <div 
              className="mt-2 pt-2"
              style={{ borderTop: `1px solid ${theme.colors.border}` }}
            >
              <select
                value={displayProperty?.id || ''}
                onChange={(e) => onDisplayPropertyChange(e.target.value)}
                className="w-full h-7 px-2 text-[11px] border cursor-pointer outline-none"
                style={{
                  backgroundColor: theme.colors.surfaceElevated,
                  color: theme.colors.text,
                  borderColor: theme.colors.border,
                  borderRadius: theme.effects.borderRadius,
                  ...(theme.name === 'nextstep' && {
                    boxShadow: theme.effects.shadow,
                    borderStyle: theme.effects.borderStyle,
                  }),
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
              >
                <option value="">Display: (None)</option>
                {textProperties.map(prop => (
                  <option key={prop.id} value={prop.id}>
                    Display: {prop.displayName}
                  </option>
                ))}
              </select>
            </div>

            {/* Audit View Toggle */}
            <div className="mt-1">
              <label 
                className="flex items-center gap-2 h-7 px-2 border cursor-pointer"
                style={{
                  backgroundColor: theme.colors.surfaceElevated,
                  borderColor: theme.colors.border,
                  borderRadius: theme.effects.borderRadius,
                  ...(theme.name === 'nextstep' && {
                    boxShadow: theme.effects.shadow,
                    borderStyle: theme.effects.borderStyle,
                  }),
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
              >
                <input
                  type="checkbox"
                  checked={auditViewEnabled}
                  onChange={onAuditViewToggle}
                  className="w-3.5 h-3.5"
                />
                <span className="text-[11px]" style={{ color: theme.colors.text }}>Audit View</span>
              </label>
            </div>

            {/* Card Density Selector */}
            <div className="mt-1">
              <select
                value={cardDensity}
                onChange={(e) => onCardDensityChange(e.target.value as any)}
                className="w-full h-7 px-2 text-[11px] border cursor-pointer outline-none"
                style={{
                  backgroundColor: theme.colors.surfaceElevated,
                  color: theme.colors.text,
                  borderColor: theme.colors.border,
                  borderRadius: theme.effects.borderRadius,
                  ...(theme.name === 'nextstep' && {
                    boxShadow: theme.effects.shadow,
                    borderStyle: theme.effects.borderStyle,
                  }),
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
              >
                <option value="compact">Cards: Compact</option>
                <option value="standard">Cards: Standard</option>
                <option value="expanded">Cards: Expanded</option>
                <option value="full">Cards: Full</option>
              </select>
            </div>

            {/* Aggregation Mode */}
            <div className="mt-1">
              <select
                value={aggregationMode}
                onChange={(e) => onAggregationModeChange(e.target.value as any)}
                className="w-full h-7 px-2 text-[11px] border cursor-pointer outline-none"
                style={{
                  backgroundColor: theme.colors.surfaceElevated,
                  color: theme.colors.text,
                  borderColor: theme.colors.border,
                  borderRadius: theme.effects.borderRadius,
                  ...(theme.name === 'nextstep' && {
                    boxShadow: theme.effects.shadow,
                    borderStyle: theme.effects.borderStyle,
                  }),
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
              >
                <option value="count">Aggregation: Count</option>
                <option value="sum">Aggregation: Sum</option>
                <option value="average">Aggregation: Average</option>
                <option value="min">Aggregation: Min</option>
                <option value="max">Aggregation: Max</option>
                <option value="list">Aggregation: List</option>
              </select>
            </div>
          </DropWell>
        </div>
      </div>
    </div>
  );
}