import { useState, useEffect, useRef } from 'react';
import { Bold, Italic, Underline, Code, List, ListOrdered, Link, Heading1, Heading2, Heading3, Quote } from 'lucide-react';
import { Theme } from '../themes';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import * as d3 from 'd3';

interface NotebookPaneProps {
  theme: Theme;
}

export function NotebookPane({ theme }: NotebookPaneProps) {
  const [markdown, setMarkdown] = useState(`# Isometry Notebook

Welcome to the **Isometry** polymorphic data visualization platform!

## Features

- LATCH classification system (Location, Alphanumeric, Time, Category, Hierarchy)
- Multi-dimensional SuperGrid
- Drag-and-drop projection explorer
- Real-time visualization

## Sample D3 Visualization

\`\`\`d3
{
  "type": "bar",
  "data": [
    {"name": "Location", "value": 4, "color": "#4A90D9"},
    {"name": "Alphanumeric", "value": 3, "color": "#7CB342"},
    {"name": "Time", "value": 6, "color": "#FF9800"},
    {"name": "Category", "value": 5, "color": "#9C27B0"},
    {"name": "Hierarchy", "value": 3, "color": "#E53935"},
    {"name": "Graph", "value": 4, "color": "#78909C"}
  ]
}
\`\`\`

## Getting Started

Start by dragging properties from the **Properties Explorer** into the projection wells.
`);

  const d3ContainerRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Insert markdown formatting at cursor position
  const insertFormatting = (before: string, after: string = '') => {
    if (!textareaRef.current) return;

    const textarea = textareaRef.current;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = markdown.substring(start, end);
    const newText = markdown.substring(0, start) + before + selectedText + after + markdown.substring(end);
    
    setMarkdown(newText);
    
    // Restore focus and set cursor position
    setTimeout(() => {
      textarea.focus();
      const newCursorPos = start + before.length + selectedText.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  // Render D3 visualization when markdown changes
  useEffect(() => {
    if (!d3ContainerRef.current) return;

    // Extract D3 code blocks from markdown
    const d3CodeMatch = markdown.match(/```d3\n([\s\S]*?)\n```/);
    
    if (d3CodeMatch) {
      try {
        const d3Config = JSON.parse(d3CodeMatch[1]);
        renderD3Visualization(d3Config);
      } catch (e) {
        console.error('Failed to parse D3 config:', e);
      }
    }
  }, [markdown, theme]);

  const renderD3Visualization = (config: any) => {
    if (!d3ContainerRef.current) return;

    // Clear previous visualization
    d3.select(d3ContainerRef.current).selectAll('*').remove();

    const container = d3ContainerRef.current;
    const width = container.clientWidth;
    const height = 200;
    const margin = { top: 20, right: 20, bottom: 40, left: 40 };

    const svg = d3.select(container)
      .append('svg')
      .attr('width', width)
      .attr('height', height);

    if (config.type === 'bar' && config.data) {
      const data = config.data;
      const chartWidth = width - margin.left - margin.right;
      const chartHeight = height - margin.top - margin.bottom;

      const x = d3.scaleBand()
        .domain(data.map((d: any) => d.name))
        .range([margin.left, width - margin.right])
        .padding(0.2);

      const y = d3.scaleLinear()
        .domain([0, d3.max(data, (d: any) => d.value) || 10])
        .range([height - margin.bottom, margin.top]);

      // Add bars
      svg.selectAll('rect')
        .data(data)
        .join('rect')
        .attr('x', (d: any) => x(d.name) || 0)
        .attr('y', (d: any) => y(d.value))
        .attr('width', x.bandwidth())
        .attr('height', (d: any) => y(0) - y(d.value))
        .attr('fill', (d: any) => d.color || theme.colors.focus);

      // Add x-axis
      svg.append('g')
        .attr('transform', `translate(0,${height - margin.bottom})`)
        .call(d3.axisBottom(x))
        .attr('color', theme.colors.textMuted)
        .selectAll('text')
        .attr('transform', 'rotate(-45)')
        .style('text-anchor', 'end')
        .style('font-size', '10px');

      // Add y-axis
      svg.append('g')
        .attr('transform', `translate(${margin.left},0)`)
        .call(d3.axisLeft(y))
        .attr('color', theme.colors.textMuted)
        .style('font-size', '10px');
    }
  };

  return (
    <div 
      className="w-full border-b"
      style={{
        backgroundColor: theme.colors.surface,
        borderColor: theme.colors.border,
      }}
    >
      <div className="flex h-96">
        {/* Editor Pane */}
        <div className="w-1/2 border-r flex flex-col" style={{ borderColor: theme.colors.border }}>
          {/* Header with Title */}
          <div 
            className="px-3 py-2 border-b"
            style={{ 
              backgroundColor: theme.colors.surfaceElevated,
              borderColor: theme.colors.border,
            }}
          >
            <span className="text-xs font-medium uppercase tracking-wide" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>
              Card Editor
            </span>
          </div>

          {/* Formatting Toolbar */}
          <div 
            className="px-2 py-1.5 border-b flex items-center gap-1"
            style={{ 
              backgroundColor: theme.colors.surface,
              borderColor: theme.colors.border,
            }}
          >
            {/* Heading buttons */}
            <button
              onClick={() => insertFormatting('# ', '')}
              className="p-1.5 hover:bg-opacity-80 transition-colors"
              style={{ 
                backgroundColor: theme.colors.surfaceElevated,
                borderRadius: theme.effects.borderRadius,
              }}
              title="Heading 1"
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
            >
              <Heading1 className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
            </button>
            <button
              onClick={() => insertFormatting('## ', '')}
              className="p-1.5 hover:bg-opacity-80 transition-colors"
              style={{ 
                backgroundColor: theme.colors.surfaceElevated,
                borderRadius: theme.effects.borderRadius,
              }}
              title="Heading 2"
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
            >
              <Heading2 className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
            </button>
            <button
              onClick={() => insertFormatting('### ', '')}
              className="p-1.5 hover:bg-opacity-80 transition-colors"
              style={{ 
                backgroundColor: theme.colors.surfaceElevated,
                borderRadius: theme.effects.borderRadius,
              }}
              title="Heading 3"
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
            >
              <Heading3 className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
            </button>

            {/* Divider */}
            <div className="w-px h-6 mx-1" style={{ backgroundColor: theme.colors.border }} />

            {/* Text formatting buttons */}
            <button
              onClick={() => insertFormatting('**', '**')}
              className="p-1.5 hover:bg-opacity-80 transition-colors"
              style={{ 
                backgroundColor: theme.colors.surfaceElevated,
                borderRadius: theme.effects.borderRadius,
              }}
              title="Bold"
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
            >
              <Bold className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
            </button>
            <button
              onClick={() => insertFormatting('*', '*')}
              className="p-1.5 hover:bg-opacity-80 transition-colors"
              style={{ 
                backgroundColor: theme.colors.surfaceElevated,
                borderRadius: theme.effects.borderRadius,
              }}
              title="Italic"
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
            >
              <Italic className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
            </button>
            <button
              onClick={() => insertFormatting('`', '`')}
              className="p-1.5 hover:bg-opacity-80 transition-colors"
              style={{ 
                backgroundColor: theme.colors.surfaceElevated,
                borderRadius: theme.effects.borderRadius,
              }}
              title="Code"
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
            >
              <Code className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
            </button>

            {/* Divider */}
            <div className="w-px h-6 mx-1" style={{ backgroundColor: theme.colors.border }} />

            {/* List buttons */}
            <button
              onClick={() => insertFormatting('- ', '')}
              className="p-1.5 hover:bg-opacity-80 transition-colors"
              style={{ 
                backgroundColor: theme.colors.surfaceElevated,
                borderRadius: theme.effects.borderRadius,
              }}
              title="Bullet List"
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
            >
              <List className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
            </button>
            <button
              onClick={() => insertFormatting('1. ', '')}
              className="p-1.5 hover:bg-opacity-80 transition-colors"
              style={{ 
                backgroundColor: theme.colors.surfaceElevated,
                borderRadius: theme.effects.borderRadius,
              }}
              title="Numbered List"
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
            >
              <ListOrdered className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
            </button>
            <button
              onClick={() => insertFormatting('> ', '')}
              className="p-1.5 hover:bg-opacity-80 transition-colors"
              style={{ 
                backgroundColor: theme.colors.surfaceElevated,
                borderRadius: theme.effects.borderRadius,
              }}
              title="Quote"
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
            >
              <Quote className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
            </button>

            {/* Divider */}
            <div className="w-px h-6 mx-1" style={{ backgroundColor: theme.colors.border }} />

            {/* Link button */}
            <button
              onClick={() => insertFormatting('[', '](url)')}
              className="p-1.5 hover:bg-opacity-80 transition-colors"
              style={{ 
                backgroundColor: theme.colors.surfaceElevated,
                borderRadius: theme.effects.borderRadius,
              }}
              title="Link"
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
            >
              <Link className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
            </button>
          </div>

          <textarea
            ref={textareaRef}
            value={markdown}
            onChange={(e) => setMarkdown(e.target.value)}
            className="flex-1 p-4 outline-none resize-none font-mono text-sm"
            style={{
              backgroundColor: theme.colors.surface,
              color: theme.colors.text,
              fontFamily: theme.fonts.mono,
            }}
            placeholder="Write your markdown here..."
          />
        </div>

        {/* Preview Pane */}
        <div className="w-1/2 flex flex-col">
          <div 
            className="px-3 py-2 border-b"
            style={{ 
              backgroundColor: theme.colors.surfaceElevated,
              borderColor: theme.colors.border,
            }}
          >
            <span className="text-xs font-medium uppercase tracking-wide" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>
              Preview
            </span>
          </div>
          <div 
            className="flex-1 p-4 overflow-y-auto prose prose-sm max-w-none"
            style={{
              backgroundColor: theme.colors.surface,
              color: theme.colors.text,
            }}
          >
            {/* Markdown Preview */}
            <ReactMarkdown 
              remarkPlugins={[remarkGfm]}
              components={{
                h1: ({node, ...props}) => <h1 style={{ color: theme.colors.text, fontFamily: theme.fonts.ui }} {...props} />,
                h2: ({node, ...props}) => <h2 style={{ color: theme.colors.text, fontFamily: theme.fonts.ui }} {...props} />,
                h3: ({node, ...props}) => <h3 style={{ color: theme.colors.text, fontFamily: theme.fonts.ui }} {...props} />,
                p: ({node, ...props}) => <p style={{ color: theme.colors.text, fontFamily: theme.fonts.ui }} {...props} />,
                li: ({node, ...props}) => <li style={{ color: theme.colors.text, fontFamily: theme.fonts.ui }} {...props} />,
                code: ({node, className, children, ...props}) => {
                  const match = /language-(\w+)/.exec(className || '');
                  const isD3 = match && match[1] === 'd3';
                  
                  if (isD3) {
                    return null; // D3 blocks are rendered separately
                  }
                  
                  return (
                    <code 
                      className={className}
                      style={{ 
                        backgroundColor: theme.colors.surfaceElevated,
                        color: theme.colors.text,
                        fontFamily: theme.fonts.mono,
                        padding: '2px 6px',
                        borderRadius: '3px',
                      }}
                      {...props}
                    >
                      {children}
                    </code>
                  );
                },
                pre: ({node, ...props}) => (
                  <pre 
                    style={{ 
                      backgroundColor: theme.colors.surfaceElevated,
                      color: theme.colors.text,
                      fontFamily: theme.fonts.mono,
                      padding: '12px',
                      borderRadius: theme.effects.borderRadius,
                      border: `1px solid ${theme.colors.border}`,
                    }}
                    {...props}
                  />
                ),
              }}
            >
              {markdown.replace(/```d3\n[\s\S]*?\n```/g, '')}
            </ReactMarkdown>

            {/* D3 Visualization Container */}
            {markdown.includes('```d3') && (
              <div className="mt-4">
                <div 
                  className="p-3 border rounded"
                  style={{
                    backgroundColor: theme.colors.surfaceElevated,
                    borderColor: theme.colors.border,
                    borderRadius: theme.effects.borderRadius,
                  }}
                >
                  <div ref={d3ContainerRef} className="w-full" />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}