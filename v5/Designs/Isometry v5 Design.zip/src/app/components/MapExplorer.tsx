import { useState } from 'react';
import { MapPin } from 'lucide-react';
import { Theme } from '../themes';

interface MapExplorerProps {
  theme: Theme;
}

export function MapExplorer({ theme }: MapExplorerProps) {
  const [zoomLevel, setZoomLevel] = useState(2);
  const [distanceRadius, setDistanceRadius] = useState(50);

  // OpenStreetMap centered on Boulder, Colorado
  // Boulder coordinates: 40.0150° N, 105.2705° W
  // Using static map tile from OpenStreetMap
  const mapUrl = `https://tile.openstreetmap.org/12/850/1463.png`;

  return (
    <div className="h-96 flex overflow-hidden" style={{ backgroundColor: theme.colors.background }}>
      {/* Zoom Slider - Left Side */}
      <div 
        className="w-12 flex flex-col items-center py-4"
        style={{
          borderRight: `1px solid ${theme.colors.border}`,
          backgroundColor: theme.colors.surface,
          ...(theme.effects.blur && {
            backdropFilter: 'blur(40px)',
            WebkitBackdropFilter: 'blur(40px)',
          }),
        }}
      >
        <div 
          className="text-[9px] font-mono mb-2 [writing-mode:vertical-lr] rotate-180"
          style={{ color: theme.colors.textMuted }}
        >
          ZOOM
        </div>
        
        <div className="flex-1 flex items-center justify-center">
          <input
            type="range"
            min="0"
            max="4"
            step="1"
            value={zoomLevel}
            onChange={(e) => setZoomLevel(Number(e.target.value))}
            orient="vertical"
            className="h-full appearance-none bg-transparent cursor-pointer"
            style={{
              writingMode: 'bt-lr',
              WebkitAppearance: 'slider-vertical',
              width: '6px',
            }}
          />
        </div>

        <div 
          className="text-[9px] font-mono mt-2 [writing-mode:vertical-lr] rotate-180"
          style={{ color: theme.colors.textMuted }}
        >
          PAN
        </div>

        <div 
          className="mt-3 text-[10px] font-mono"
          style={{ color: theme.colors.text }}
        >
          {zoomLevel}
        </div>
      </div>

      {/* Map Content Area */}
      <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
        {/* Map View with Minimap */}
        <div className="flex-1 relative overflow-hidden" style={{ backgroundColor: theme.colors.surfaceElevated }}>
          {/* Main Map Placeholder */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div 
              className="w-full h-full flex items-center justify-center"
              style={{
                backgroundColor: theme.colors.surface,
                backgroundImage: `repeating-linear-gradient(
                  0deg,
                  ${theme.colors.border} 0px,
                  ${theme.colors.border} 1px,
                  transparent 1px,
                  transparent 40px
                ),
                repeating-linear-gradient(
                  90deg,
                  ${theme.colors.border} 0px,
                  ${theme.colors.border} 1px,
                  transparent 1px,
                  transparent 40px
                )`,
              }}
            >
              <div className="text-center">
                <MapPin className="w-12 h-12 mx-auto mb-2" style={{ color: theme.colors.textMuted }} />
                <div className="text-sm" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>
                  Map View
                </div>
                <div className="text-xs mt-1" style={{ color: theme.colors.textSecondary, fontFamily: theme.fonts.ui }}>
                  Boulder, Colorado
                </div>
              </div>
            </div>
          </div>

          {/* Minimap Navigator - Bottom Right */}
          <div 
            className="absolute bottom-4 right-4 w-32 h-24 border-2 overflow-hidden"
            style={{
              borderColor: theme.colors.border,
              borderRadius: theme.effects.borderRadius,
              backgroundColor: theme.colors.surface,
              boxShadow: '0 4px 8px rgba(0,0,0,0.2)',
              ...(theme.name === 'nextstep' && {
                boxShadow: theme.effects.shadow,
                borderStyle: theme.effects.borderStyle,
              }),
            }}
          >
            {/* OpenStreetMap Tile - Boulder, CO */}
            <div className="relative w-full h-full bg-[#F2EFE9]">
              {/* Simple map representation */}
              <div className="absolute inset-0 flex items-center justify-center text-[8px]" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.mono }}>
                <div className="text-center">
                  <MapPin className="w-4 h-4 mx-auto mb-1 text-red-500" />
                  <div>Boulder, CO</div>
                  <div className="text-[7px] mt-0.5">40.0150°N, 105.2705°W</div>
                </div>
              </div>
              
              {/* Viewport indicator */}
              <div 
                className="absolute border-2 border-blue-500"
                style={{
                  left: '25%',
                  top: '25%',
                  width: '50%',
                  height: '50%',
                  pointerEvents: 'none',
                }}
              />
            </div>

            {/* Minimap Label */}
            <div 
              className="absolute top-0 left-0 right-0 px-1 py-0.5 text-[8px] font-mono text-center"
              style={{
                backgroundColor: theme.colors.surface + 'CC',
                color: theme.colors.textMuted,
                backdropFilter: 'blur(4px)',
              }}
            >
              MINIMAP
            </div>
          </div>
        </div>

        {/* Distance Slider - Bottom */}
        <div 
          className="px-4 py-3 flex items-center gap-3"
          style={{
            borderTop: `1px solid ${theme.colors.border}`,
            backgroundColor: theme.colors.surface,
            ...(theme.effects.blur && {
              backdropFilter: 'blur(40px)',
              WebkitBackdropFilter: 'blur(40px)',
            }),
          }}
        >
          <MapPin className="w-4 h-4 flex-shrink-0" style={{ color: '#4A90D9' }} />
          <span className="text-[11px] font-mono w-20" style={{ color: theme.colors.textMuted }}>Distance</span>
          
          <div className="flex-1 flex items-center gap-3">
            <input
              type="range"
              min="1"
              max="200"
              step="1"
              value={distanceRadius}
              onChange={(e) => setDistanceRadius(Number(e.target.value))}
              className="flex-1"
              style={{
                accentColor: '#4A90D9',
              }}
            />
            <div 
              className="text-[11px] font-mono w-16 text-right"
              style={{ color: theme.colors.text }}
            >
              {distanceRadius} mi
            </div>
          </div>

          {/* Quick Distance Buttons */}
          <div className="flex gap-1">
            {[10, 25, 50, 100].map(distance => (
              <button
                key={distance}
                onClick={() => setDistanceRadius(distance)}
                className="px-2 py-1 text-[10px] border transition-all"
                style={{
                  backgroundColor: distanceRadius === distance ? '#4A90D9' + '33' : theme.colors.surfaceElevated,
                  color: distanceRadius === distance ? theme.colors.text : theme.colors.textMuted,
                  borderColor: distanceRadius === distance ? '#4A90D9' : theme.colors.border,
                  borderRadius: theme.effects.borderRadius,
                }}
                onMouseEnter={(e) => {
                  if (distanceRadius !== distance) {
                    e.currentTarget.style.backgroundColor = theme.colors.hover;
                  }
                }}
                onMouseLeave={(e) => {
                  if (distanceRadius !== distance) {
                    e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated;
                  }
                }}
              >
                {distance}mi
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
