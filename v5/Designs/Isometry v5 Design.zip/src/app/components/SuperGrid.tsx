import { Note, Property } from '../data/mockData';
import { useMemo } from 'react';
import { ArrowLeftRight } from 'lucide-react';
import { Theme } from '../themes';

interface SuperGridProps {
  notes: Note[];
  xAxisProperties: Property[];
  yAxisProperties: Property[];
  displayProperty: Property | null;
  auditViewEnabled: boolean;
  cardDensity: 'compact' | 'standard' | 'expanded' | 'full';
  onTranspose: () => void;
  theme: Theme;
}

export function SuperGrid({
  notes,
  xAxisProperties,
  yAxisProperties,
  displayProperty,
  auditViewEnabled,
  cardDensity,
  onTranspose,
  theme,
}: SuperGridProps) {
  // Property value getter - defined before useMemo
  const getPropertyValue = (note: Note, property: Property): string => {
    // Map raw property names to Note object keys
    const propertyMap: Record<string, keyof Note> = {
      'ZTITLE2': 'title',
      'ZFOLDER': 'folder',
      'ZTAGS': 'tags',
      'ZINCEPTIONTIMESTAMP': 'created',
      'ZMODIFICATIONDATE': 'modified',
      'ZPRIORITY': 'priority',
      'ZSTATUS': 'status',
      'ZNOTETYPE': 'noteType',
      'ZSUMMARY': 'summary',
      'ZLOCATIONNAME': 'location',
    };

    const key = propertyMap[property.rawName] || property.rawName;
    const value = note[key as keyof Note];
    
    if (value instanceof Date) {
      return value.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    }
    if (Array.isArray(value)) {
      return value.join(', ');
    }
    return String(value || '');
  };

  // Generate headers and grid structure
  const { xHeaders, yHeaders, gridData } = useMemo(() => {
    // For now, simplified to use first property in each axis
    const xProp = xAxisProperties[0];
    const yProp = yAxisProperties[0];

    if (!xProp || !yProp) {
      return { xHeaders: [], yHeaders: [], gridData: {} };
    }

    // Extract unique values for headers
    const xValues = new Set<string>();
    const yValues = new Set<string>();

    notes.forEach(note => {
      const xVal = getPropertyValue(note, xProp);
      const yVal = getPropertyValue(note, yProp);
      if (xVal) xValues.add(xVal);
      if (yVal) yValues.add(yVal);
    });

    const xHeaders = Array.from(xValues).sort();
    const yHeaders = Array.from(yValues).sort();

    // Build grid data
    const gridData: Record<string, Record<string, Note[]>> = {};
    yHeaders.forEach(yVal => {
      gridData[yVal] = {};
      xHeaders.forEach(xVal => {
        gridData[yVal][xVal] = notes.filter(note => {
          return getPropertyValue(note, xProp) === xVal && getPropertyValue(note, yProp) === yVal;
        });
      });
    });

    return { xHeaders, yHeaders, gridData };
  }, [notes, xAxisProperties, yAxisProperties]);

  const renderCard = (note: Note) => {
    const displayValue = displayProperty 
      ? getPropertyValue(note, displayProperty) 
      : note.title;

    switch (cardDensity) {
      case 'compact':
        return (
          <div className="text-[12px] truncate" style={{ color: theme.colors.text }}>
            {displayValue}
          </div>
        );
      
      case 'standard':
        return (
          <div className="text-[12px]">
            <div className="truncate font-medium" style={{ color: theme.colors.text }}>{displayValue}</div>
            <div className="text-[11px] truncate" style={{ color: theme.colors.textMuted }}>{note.folder}</div>
          </div>
        );
      
      case 'expanded':
        return (
          <div className="text-[12px] space-y-0.5">
            <div className="truncate font-medium" style={{ color: theme.colors.text }}>{displayValue}</div>
            <div className="text-[10px] truncate" style={{ color: theme.colors.textMuted }}>Folder: {note.folder}</div>
            <div className="text-[10px] truncate" style={{ color: theme.colors.textMuted }}>Priority: {note.priority}</div>
            <div className="text-[10px] truncate" style={{ color: theme.colors.textMuted }}>Status: {note.status}</div>
          </div>
        );
      
      case 'full':
        return (
          <div 
            className="text-[11px] space-y-1 p-2"
            style={{
              backgroundColor: theme.colors.background,
              borderRadius: theme.effects.borderRadius,
            }}
          >
            <div className="font-medium" style={{ color: theme.colors.text }}>{displayValue}</div>
            <div className="space-y-0.5">
              <div style={{ color: theme.colors.textMuted }}>
                <span style={{ color: theme.colors.textSecondary }}>Folder:</span> {note.folder}
              </div>
              <div style={{ color: theme.colors.textMuted }}>
                <span style={{ color: theme.colors.textSecondary }}>Tags:</span> {note.tags.join(', ')}
              </div>
              <div style={{ color: theme.colors.textMuted }}>
                <span style={{ color: theme.colors.textSecondary }}>Priority:</span> {note.priority}
              </div>
              <div style={{ color: theme.colors.textMuted }}>
                <span style={{ color: theme.colors.textSecondary }}>Status:</span> {note.status}
              </div>
            </div>
          </div>
        );
    }
  };

  // Empty state
  if (xAxisProperties.length === 0 || yAxisProperties.length === 0) {
    return (
      <div 
        className="flex-1 flex items-center justify-center"
        style={{
          backgroundColor: theme.colors.background,
          color: theme.colors.textMuted,
        }}
      >
        <div className="text-center">
          <div className="text-[13px] mb-1">No axes assigned</div>
          <div className="text-[11px]">Drag properties to X and Y planes to view the grid</div>
        </div>
      </div>
    );
  }

  const cellHeight = cardDensity === 'compact' ? 'h-7' : cardDensity === 'standard' ? 'h-12' : cardDensity === 'expanded' ? 'h-20' : 'h-auto min-h-24';

  return (
    <div className="flex-1 overflow-auto" style={{ backgroundColor: theme.colors.background }}>
      <div className="inline-block min-w-full">
        <table className="border-collapse">
          <thead>
            <tr>
              {/* Corner Cell */}
              <th 
                className="sticky left-0 top-0 z-20 p-2 min-w-32 relative border"
                style={{
                  backgroundColor: theme.colors.surface,
                  borderColor: theme.colors.border,
                  ...(theme.name === 'nextstep' && {
                    boxShadow: theme.effects.shadow,
                    borderStyle: theme.effects.borderStyle,
                  }),
                }}
              >
                <div className="text-[10px] mb-1" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>
                  <div>ROWS: {yAxisProperties[0]?.displayName}</div>
                  <div>COLS: {xAxisProperties[0]?.displayName}</div>
                </div>
                <button
                  onClick={onTranspose}
                  className="absolute bottom-2 right-2 p-1.5 border transition-colors group"
                  style={{
                    backgroundColor: theme.colors.surfaceElevated,
                    borderColor: theme.colors.border,
                    borderRadius: theme.effects.borderRadius,
                    ...(theme.name === 'nextstep' && {
                      boxShadow: theme.effects.shadow,
                    }),
                  }}
                  title="Transpose X and Y axes"
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = theme.colors.hover}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = theme.colors.surfaceElevated}
                >
                  <ArrowLeftRight className="w-3.5 h-3.5" style={{ color: theme.colors.textMuted }} />
                </button>
              </th>
              {/* Column Headers */}
              {xHeaders.map(header => (
                <th
                  key={header}
                  className="sticky top-0 z-10 border px-3 py-2 min-w-40"
                  style={{
                    backgroundColor: theme.colors.surfaceElevated,
                    borderColor: theme.colors.border,
                    ...(theme.name === 'nextstep' && {
                      boxShadow: theme.effects.shadow,
                      borderStyle: theme.effects.borderStyle,
                    }),
                  }}
                >
                  <div className="text-[13px] font-semibold" style={{ color: theme.colors.text }}>
                    {header}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {yHeaders.map(yHeader => (
              <tr key={yHeader}>
                {/* Row Header */}
                <th 
                  className="sticky left-0 z-10 border px-3 py-2 text-left"
                  style={{
                    backgroundColor: theme.colors.surfaceElevated,
                    borderColor: theme.colors.border,
                    ...(theme.name === 'nextstep' && {
                      boxShadow: theme.effects.shadow,
                      borderStyle: theme.effects.borderStyle,
                    }),
                  }}
                >
                  <div className="text-[13px] font-semibold" style={{ color: theme.colors.text }}>
                    {yHeader}
                  </div>
                </th>
                {/* Data Cells */}
                {xHeaders.map(xHeader => {
                  const cellNotes = gridData[yHeader]?.[xHeader] || [];
                  const isEmpty = cellNotes.length === 0;

                  return (
                    <td
                      key={`${yHeader}-${xHeader}`}
                      className={`border p-2 ${cellHeight} align-top`}
                      style={{
                        borderColor: theme.colors.border,
                        backgroundColor: !isEmpty 
                          ? `${theme.colors.primary}${Math.floor(Math.min(cellNotes.length * 0.05, 0.15) * 255).toString(16).padStart(2, '0')}` 
                          : theme.colors.background,
                        ...(theme.name === 'nextstep' && {
                          boxShadow: !isEmpty ? 'inset 1px 1px 2px rgba(0,0,0,0.2)' : 'none',
                        }),
                      }}
                    >
                      {isEmpty ? (
                        <div className="flex items-center justify-center h-full" style={{ color: theme.colors.textMuted }}>
                          <span className="text-xl">·</span>
                        </div>
                      ) : cellNotes.length === 1 ? (
                        renderCard(cellNotes[0])
                      ) : (
                        <div className="space-y-1">
                          {cardDensity === 'compact' && cellNotes.slice(0, 3).map(note => (
                            <div key={note.id}>{renderCard(note)}</div>
                          ))}
                          {cardDensity !== 'compact' && renderCard(cellNotes[0])}
                          {cellNotes.length > (cardDensity === 'compact' ? 3 : 1) && (
                            <div className="text-[11px] cursor-pointer" style={{ color: theme.colors.primary }}>
                              +{cellNotes.length - (cardDensity === 'compact' ? 3 : 1)} more
                            </div>
                          )}
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}