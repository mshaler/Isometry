import { useState, useEffect } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Command, Settings, MapPin, ALargeSmall, Clock, Tag, BarChart3 } from 'lucide-react';
import { PropertiesExplorer } from './components/PropertiesExplorer';
import { ProjectionExplorer } from './components/ProjectionExplorer';
import { SuperGrid } from './components/SuperGrid';
import { TimeExplorer } from './components/TimeExplorer';
import { MapExplorer } from './components/MapExplorer';
import { MenuDropdown } from './components/MenuDropdown';
import { NotebookPane } from './components/NotebookPane';
import { CollapsibleExplorer } from './components/CollapsibleExplorer';
import { PROPERTIES, Property, MOCK_NOTES } from './data/mockData';
import { THEMES, ThemeName, Theme } from './themes';
import appIcon from 'figma:asset/e114b7afa529d3f027cf8b8f18c991be3962ece7.png';

export default function App() {
  const [properties, setProperties] = useState<Property[]>(PROPERTIES);
  const [availableProperties, setAvailableProperties] = useState<Property[]>([]);
  const [xAxisProperties, setXAxisProperties] = useState<Property[]>([]);
  const [yAxisProperties, setYAxisProperties] = useState<Property[]>([]);
  const [zAxisProperties, setZAxisProperties] = useState<Property[]>([]);
  const [displayProperty, setDisplayProperty] = useState<Property | null>(null);
  const [auditViewEnabled, setAuditViewEnabled] = useState(false);
  const [cardDensity, setCardDensity] = useState<'compact' | 'standard' | 'expanded' | 'full'>('standard');
  const [aggregationMode, setAggregationMode] = useState<'count' | 'sum' | 'average' | 'min' | 'max' | 'list'>('count');
  const [densityLevel, setDensityLevel] = useState(2);
  const [themeName, setThemeName] = useState<ThemeName>('modern-dark');

  // Initialize available properties from checked properties
  useEffect(() => {
    const checked = properties.filter(p => p.checked);
    setAvailableProperties(checked);
    
    // Set default display property to first text property
    const firstText = checked.find(p => p.type === 'text');
    if (firstText) setDisplayProperty(firstText);
    
    // Pre-assign default axes for immediate visualization
    const folderProp = checked.find(p => p.rawName === 'ZFOLDER'); // Category axis
    const createdProp = checked.find(p => p.rawName === 'ZINCEPTIONTIMESTAMP'); // Time axis
    const priorityProp = checked.find(p => p.rawName === 'ZPRIORITY'); // Hierarchy axis
    
    if (folderProp && createdProp) {
      // X-plane (Columns) = Time (Created date)
      setXAxisProperties([createdProp]);
      // Y-plane (Rows) = Folder
      setYAxisProperties([folderProp]);
      // Remove from available
      setAvailableProperties(prev => prev.filter(p => p.id !== folderProp.id && p.id !== createdProp.id));
    }
  }, []);

  // Property toggle handler
  const handlePropertyToggle = (propertyId: string) => {
    setProperties(prev => prev.map(p => 
      p.id === propertyId ? { ...p, checked: !p.checked } : p
    ));

    const property = properties.find(p => p.id === propertyId);
    if (!property) return;

    if (property.checked) {
      // Unchecking - remove from all wells
      setAvailableProperties(prev => prev.filter(p => p.id !== propertyId));
      setXAxisProperties(prev => prev.filter(p => p.id !== propertyId));
      setYAxisProperties(prev => prev.filter(p => p.id !== propertyId));
      setZAxisProperties(prev => prev.filter(p => p.id !== propertyId));
    } else {
      // Checking - add to available
      setAvailableProperties(prev => [...prev, property]);
    }
  };

  // Property rename handler
  const handlePropertyRename = (propertyId: string, newName: string) => {
    setProperties(prev => prev.map(p => 
      p.id === propertyId ? { ...p, displayName: newName } : p
    ));
    // Update in all wells
    const updateWell = (props: Property[]) => 
      props.map(p => p.id === propertyId ? { ...p, displayName: newName } : p);
    setAvailableProperties(updateWell);
    setXAxisProperties(updateWell);
    setYAxisProperties(updateWell);
    setZAxisProperties(updateWell);
  };

  // Move property between wells
  const handleMoveProperty = (propertyId: string, fromWell: string, toWell: string) => {
    const property = [...availableProperties, ...xAxisProperties, ...yAxisProperties, ...zAxisProperties]
      .find(p => p.id === propertyId);
    
    if (!property) return;

    // Remove from source well
    const removeFrom = (well: string, setter: React.Dispatch<React.SetStateAction<Property[]>>) => {
      if (fromWell === well) {
        setter(prev => prev.filter(p => p.id !== propertyId));
      }
    };

    removeFrom('available', setAvailableProperties);
    removeFrom('x', setXAxisProperties);
    removeFrom('y', setYAxisProperties);
    removeFrom('z', setZAxisProperties);

    // Add to target well
    const addTo = (well: string, setter: React.Dispatch<React.SetStateAction<Property[]>>) => {
      if (toWell === well) {
        setter(prev => [...prev, property]);
      }
    };

    addTo('available', setAvailableProperties);
    addTo('x', setXAxisProperties);
    addTo('y', setYAxisProperties);
    addTo('z', setZAxisProperties);
  };

  // Reorder properties within a well
  const handleReorderProperty = (well: string, fromIndex: number, toIndex: number) => {
    // Implementation for reordering would go here
  };

  // Transpose X and Y axes
  const handleTranspose = () => {
    const tempX = xAxisProperties;
    setXAxisProperties(yAxisProperties);
    setYAxisProperties(tempX);
  };

  // Display property change
  const handleDisplayPropertyChange = (propertyId: string) => {
    const property = properties.find(p => p.id === propertyId);
    setDisplayProperty(property || null);
  };

  const theme = THEMES[themeName];

  // Menu items for app icon dropdown
  const appMenuItems = [
    {
      label: 'File',
      submenu: [
        { label: 'New Database', shortcut: '⌘N', onClick: () => console.log('New Database') },
        { label: 'Open Database', shortcut: '⌘O', onClick: () => console.log('Open Database') },
        { label: 'Import...', onClick: () => console.log('Import') },
        { divider: true },
        { label: 'Save', shortcut: '⌘S', onClick: () => console.log('Save') },
        { label: 'Save As...', shortcut: '⌘⇧S', onClick: () => console.log('Save As') },
        { divider: true },
        { label: 'Export...', onClick: () => console.log('Export') },
      ],
    },
    {
      label: 'Edit',
      submenu: [
        { label: 'Undo', shortcut: '⌘Z', onClick: () => console.log('Undo') },
        { label: 'Redo', shortcut: '⌘⇧Z', onClick: () => console.log('Redo') },
        { divider: true },
        { label: 'Cut', shortcut: '⌘X', onClick: () => console.log('Cut') },
        { label: 'Copy', shortcut: '⌘C', onClick: () => console.log('Copy') },
        { label: 'Paste', shortcut: '⌘V', onClick: () => console.log('Paste') },
      ],
    },
    {
      label: 'View',
      submenu: [
        { label: 'Properties Explorer', shortcut: '⌘1', onClick: () => console.log('Properties') },
        { label: 'Projection Explorer', shortcut: '⌘2', onClick: () => console.log('Projection') },
        { label: 'Visual Explorer', shortcut: '⌘3', onClick: () => console.log('Visual') },
        { label: 'Time Explorer', shortcut: '⌘4', onClick: () => console.log('Time') },
        { divider: true },
        { label: 'Toggle Audit View', shortcut: '⌘A', onClick: () => setAuditViewEnabled(!auditViewEnabled) },
      ],
    },
    {
      label: 'Database',
      submenu: [
        { label: 'Refresh', shortcut: '⌘R', onClick: () => console.log('Refresh') },
        { label: 'Properties...', onClick: () => console.log('Database Properties') },
        { divider: true },
        { label: 'Connect to Apple Notes', onClick: () => console.log('Connect') },
        { label: 'Disconnect', onClick: () => console.log('Disconnect') },
      ],
    },
    {
      label: 'Help',
      submenu: [
        { label: 'Documentation', onClick: () => console.log('Docs') },
        { label: 'Keyboard Shortcuts', shortcut: '⌘/', onClick: () => console.log('Shortcuts') },
        { divider: true },
        { label: 'About Isometry', onClick: () => console.log('About') },
      ],
    },
  ];

  return (
    <DndProvider backend={HTML5Backend}>
      <div 
        className="h-screen flex flex-col overflow-hidden"
        style={{
          backgroundColor: theme.colors.background,
          color: theme.colors.text,
          fontFamily: theme.fonts.ui,
          ...(theme.effects.blur && {
            backdropFilter: 'blur(40px)',
            WebkitBackdropFilter: 'blur(40px)',
          }),
        }}
      >
        {/* Command Palette - Top */}
        <div 
          className="flex items-center gap-2 px-3 py-2"
          style={{
            backgroundColor: theme.colors.surface,
            borderBottom: `1px solid ${theme.colors.border}`,
            ...(theme.effects.blur && {
              backdropFilter: 'blur(40px)',
              WebkitBackdropFilter: 'blur(40px)',
            }),
          }}
        >
          {/* App Icon with Menu */}
          <MenuDropdown
            trigger={
              <img 
                src={appIcon} 
                alt="Isometry" 
                className="w-6 h-6"
                style={{
                  borderRadius: theme.effects.borderRadius,
                }}
              />
            }
            items={appMenuItems}
            theme={theme}
          />
          
          {/* Command Icon */}
          <Command className="w-4 h-4" style={{ color: theme.colors.textMuted }} />
          
          {/* Command Input */}
          <input
            type="text"
            placeholder="Command palette..."
            className="flex-1 text-[13px] px-3 py-1.5 outline-none"
            style={{
              backgroundColor: theme.colors.surfaceElevated,
              color: theme.colors.text,
              border: `1px solid ${theme.colors.border}`,
              borderRadius: theme.effects.borderRadius,
              fontFamily: theme.fonts.ui,
            }}
          />
          
          {/* Settings Icon */}
          <MenuDropdown
            trigger={
              <Settings className="w-4 h-4" style={{ color: theme.colors.textSecondary }} />
            }
            items={[
              {
                label: 'Theme',
                submenu: [
                  { label: 'Material Dark', onClick: () => setThemeName('material-dark') },
                  { label: 'Material Light', onClick: () => setThemeName('material-light') },
                  { label: 'Modern Dark', onClick: () => setThemeName('modern-dark') },
                  { label: 'Modern Light', onClick: () => setThemeName('modern-light') },
                  { label: 'NeXTSTEP', onClick: () => setThemeName('nextstep') },
                ],
              },
              { divider: true },
              { label: 'Preferences...', shortcut: '⌘,', onClick: () => console.log('Preferences') },
              { label: 'Keyboard Shortcuts', shortcut: '⌘K', onClick: () => console.log('Shortcuts') },
              { divider: true },
              { label: 'Check for Updates', onClick: () => console.log('Updates') },
            ]}
            theme={theme}
          />
        </div>

        {/* Notebook Pane */}
        <CollapsibleExplorer title="Notebook" defaultCollapsed={false} theme={theme}>
          <NotebookPane theme={theme} />
        </CollapsibleExplorer>

        {/* Properties Explorer (formerly LATCH×GRAPH Navigator) */}
        <CollapsibleExplorer title="Properties Explorer" defaultCollapsed={false} theme={theme}>
          <PropertiesExplorer
            properties={properties}
            onPropertyToggle={handlePropertyToggle}
            onPropertyRename={handlePropertyRename}
            theme={theme}
          />
        </CollapsibleExplorer>

        {/* Projection Explorer (formerly PAFV Navigator) */}
        <CollapsibleExplorer title="Projection Explorer" defaultCollapsed={false} theme={theme}>
          <ProjectionExplorer
            availableProperties={availableProperties}
            xAxisProperties={xAxisProperties}
            yAxisProperties={yAxisProperties}
            zAxisProperties={zAxisProperties}
            displayProperty={displayProperty}
            auditViewEnabled={auditViewEnabled}
            cardDensity={cardDensity}
            aggregationMode={aggregationMode}
            onMoveProperty={handleMoveProperty}
            onReorderProperty={handleReorderProperty}
            onDisplayPropertyChange={handleDisplayPropertyChange}
            onAuditViewToggle={() => setAuditViewEnabled(!auditViewEnabled)}
            onCardDensityChange={setCardDensity}
            onAggregationModeChange={setAggregationMode}
            theme={theme}
          />
        </CollapsibleExplorer>

        {/* Visual Explorer (SuperGrid with Zoom Slider) */}
        <CollapsibleExplorer title="Visual Explorer (SuperGrid)" defaultCollapsed={false} theme={theme}>
          <div className="h-96 flex overflow-hidden" style={{ backgroundColor: theme.colors.background }}>
            {/* Zoom Slider - Left Side */}
            <div 
              className="w-12 flex flex-col items-center py-4"
              style={{
                borderRight: `1px solid ${theme.colors.border}`,
                backgroundColor: theme.colors.surface,
                ...(theme.effects.blur && {
                  backdropFilter: 'blur(40px)',
                  WebkitBackdropFilter: 'blur(40px)',
                }),
              }}
            >
              <div 
                className="text-[9px] font-mono mb-2 [writing-mode:vertical-lr] rotate-180"
                style={{ color: theme.colors.textMuted }}
              >
                ZOOM
              </div>
              
              <div className="flex-1 flex items-center justify-center">
                <input
                  type="range"
                  min="0"
                  max="4"
                  step="1"
                  value={densityLevel}
                  onChange={(e) => setDensityLevel(Number(e.target.value))}
                  orient="vertical"
                  className="h-full appearance-none bg-transparent cursor-pointer"
                  style={{
                    writingMode: 'bt-lr',
                    WebkitAppearance: 'slider-vertical',
                    width: '6px',
                  }}
                />
              </div>

              <div 
                className="text-[9px] font-mono mt-2 [writing-mode:vertical-lr] rotate-180"
                style={{ color: theme.colors.textMuted }}
              >
                PAN
              </div>

              <div 
                className="mt-3 text-[10px] font-mono"
                style={{ color: theme.colors.text }}
              >
                {densityLevel}
              </div>
            </div>

            {/* SuperGrid */}
            <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
              <SuperGrid
                notes={MOCK_NOTES}
                xAxisProperties={xAxisProperties}
                yAxisProperties={yAxisProperties}
                displayProperty={displayProperty}
                auditViewEnabled={auditViewEnabled}
                cardDensity={cardDensity}
                onTranspose={handleTranspose}
                theme={theme}
              />
            </div>
          </div>
        </CollapsibleExplorer>

        {/* Time Explorer (formerly LATCH Sliders) */}
        <CollapsibleExplorer 
          title={
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium uppercase tracking-wide" style={{ color: theme.colors.textMuted, fontFamily: theme.fonts.ui }}>
                LATCH Explorers
              </span>
              <div className="flex gap-1">
                <MapPin className="w-3 h-3 text-[#4A90D9]" />
                <ALargeSmall className="w-3 h-3 text-[#7CB342]" />
                <Clock className="w-3 h-3 text-[#FF9800]" />
                <Tag className="w-3 h-3 text-[#9C27B0]" />
                <BarChart3 className="w-3 h-3 text-[#E53935]" />
              </div>
            </div>
          } 
          defaultCollapsed={false} 
          theme={theme}
          fillRemaining={true}
        >
          <TimeExplorer
            onLocationFilter={() => {}}
            onAlphabetFilter={() => {}}
            onTimeFilter={() => {}}
            onCategoryFilter={() => {}}
            onHierarchyFilter={() => {}}
            theme={theme}
          />
        </CollapsibleExplorer>
      </div>
    </DndProvider>
  );
}