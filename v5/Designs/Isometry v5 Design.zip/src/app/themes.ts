export type ThemeName = 'material-dark' | 'material-light' | 'modern-dark' | 'modern-light' | 'nextstep';

export interface Theme {
  name: ThemeName;
  displayName: string;
  colors: {
    background: string;
    surface: string;
    surfaceElevated: string;
    border: string;
    borderSubtle: string;
    text: string;
    textSecondary: string;
    textMuted: string;
    primary: string;
    hover: string;
    focus: string;
  };
  effects: {
    blur: boolean;
    shadow: string;
    borderRadius: string;
    borderStyle: string;
  };
  fonts: {
    mono: string;
    ui: string;
  };
}

export const THEMES: Record<ThemeName, Theme> = {
  'material-dark': {
    name: 'material-dark',
    displayName: 'Material Dark',
    colors: {
      background: '#1E1E1E',
      surface: '#252525',
      surfaceElevated: '#2D2D2D',
      border: '#3A3A3A',
      borderSubtle: '#2A2A2A',
      text: '#E0E0E0',
      textSecondary: '#B0B0B0',
      textMuted: '#999',
      primary: '#4A90D9',
      hover: '#3A3A3A',
      focus: '#4A90D9',
    },
    effects: {
      blur: false,
      shadow: '0 2px 4px rgba(0,0,0,0.2)',
      borderRadius: '4px',
      borderStyle: 'solid',
    },
    fonts: {
      mono: 'ui-monospace, monospace',
      ui: 'system-ui, -apple-system, sans-serif',
    },
  },

  'material-light': {
    name: 'material-light',
    displayName: 'Material Light',
    colors: {
      background: '#FAFAFA',
      surface: '#FFFFFF',
      surfaceElevated: '#F5F5F5',
      border: '#E0E0E0',
      borderSubtle: '#EEEEEE',
      text: '#212121',
      textSecondary: '#616161',
      textMuted: '#9E9E9E',
      primary: '#1976D2',
      hover: '#F5F5F5',
      focus: '#1976D2',
    },
    effects: {
      blur: false,
      shadow: '0 2px 4px rgba(0,0,0,0.1)',
      borderRadius: '4px',
      borderStyle: 'solid',
    },
    fonts: {
      mono: 'ui-monospace, monospace',
      ui: 'system-ui, -apple-system, sans-serif',
    },
  },

  'modern-dark': {
    name: 'modern-dark',
    displayName: 'Modern Dark',
    colors: {
      background: 'rgba(18, 18, 18, 0.7)',
      surface: 'rgba(40, 40, 40, 0.6)',
      surfaceElevated: 'rgba(60, 60, 60, 0.5)',
      border: 'rgba(255, 255, 255, 0.1)',
      borderSubtle: 'rgba(255, 255, 255, 0.05)',
      text: '#FFFFFF',
      textSecondary: 'rgba(255, 255, 255, 0.8)',
      textMuted: 'rgba(255, 255, 255, 0.5)',
      primary: '#007AFF',
      hover: 'rgba(255, 255, 255, 0.1)',
      focus: '#007AFF',
    },
    effects: {
      blur: true,
      shadow: '0 8px 32px rgba(0, 0, 0, 0.3)',
      borderRadius: '12px',
      borderStyle: 'solid',
    },
    fonts: {
      mono: '-apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, sans-serif',
      ui: '-apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, sans-serif',
    },
  },

  'modern-light': {
    name: 'modern-light',
    displayName: 'Modern Light',
    colors: {
      background: 'rgba(245, 245, 247, 0.7)',
      surface: 'rgba(255, 255, 255, 0.6)',
      surfaceElevated: 'rgba(255, 255, 255, 0.8)',
      border: 'rgba(0, 0, 0, 0.1)',
      borderSubtle: 'rgba(0, 0, 0, 0.05)',
      text: '#000000',
      textSecondary: 'rgba(0, 0, 0, 0.7)',
      textMuted: 'rgba(0, 0, 0, 0.4)',
      primary: '#007AFF',
      hover: 'rgba(0, 0, 0, 0.05)',
      focus: '#007AFF',
    },
    effects: {
      blur: true,
      shadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
      borderRadius: '12px',
      borderStyle: 'solid',
    },
    fonts: {
      mono: '-apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, sans-serif',
      ui: '-apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, sans-serif',
    },
  },

  nextstep: {
    name: 'nextstep',
    displayName: 'NeXTSTEP',
    colors: {
      background: '#A0A0A0',
      surface: '#C0C0C0',
      surfaceElevated: '#D0D0D0',
      border: '#808080',
      borderSubtle: '#909090',
      text: '#000000',
      textSecondary: '#202020',
      textMuted: '#505050',
      primary: '#000000',
      hover: '#B8B8B8',
      focus: '#000000',
    },
    effects: {
      blur: false,
      shadow: 'inset 1px 1px 0 rgba(255,255,255,0.8), inset -1px -1px 0 rgba(0,0,0,0.3)',
      borderRadius: '0px',
      borderStyle: 'ridge',
    },
    fonts: {
      mono: 'Courier, "Courier New", monospace',
      ui: 'Courier, "Courier New", monospace',
    },
  },
};